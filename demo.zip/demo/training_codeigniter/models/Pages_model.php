<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Pages_model extends CI_Model{
	function __costruct()
	{
		Parent::__construct();
		$this->load->database();
	}

	public function save($data, $table){
		if(isset($data['id']))
		{
			$this->db->where('id',$data['id'])->update($table, $data);
			return $data['id'];
		}
		else
		{
			$this->db->insert($table, $data);
			return $this->db->insert_id();
		}

	}

	public function get_data($id, $table){  
		return $this->db->where('id', $id)->get($table)->row();
		
	}
	
	public function get_cms($value,$table){ 
		$result = $this->db->where('slug', $value)->where('status',0)->get($table)->row();
		//echo $this->db->last_query();die;
		if(!empty($result)){
			return $result;
		}else{
			return ;
		}
	}

	public function get_pages($total=false, $offset=0, $limit=ADMIN_LIMIT_PER_PAGE, $order_by='id', $order_mode='desc'){

		//$where = "status=1";
		//$this->db->where($where);
		if($total){
			return $this->db->get('pages')->num_rows();
		}
		return $this->db->order_by($order_by, $order_mode)
		->get('pages', $limit, $offset)->result();
	}
	
	public function delete_jobs($id,$tables){
	
		 $this->db->where('id', $id);
   		 $this->db->delete($tables); 
		 return $id;
	}

	
	

}
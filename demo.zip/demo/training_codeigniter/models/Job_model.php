<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Job_model extends CI_Model{
	function __costruct()
	{
		Parent::__construct();
		$this->load->database();
	}

	public function save($data, $table){
		if(isset($data['id']))
		{
			$this->db->where('id',$data['id'])->update($table, $data);
			return $data['id'];
		}
		else
		{
			$this->db->insert($table, $data);
			return $this->db->insert_id();
		}

	}

	function get_jobs($data,$total=false, $offset=0, $limit=ADMIN_LIMIT_PER_PAGE, $order_by='id', $order_mode='desc')
	{
		$this->db->select('users_posting_jobs.*,skills.title as skill,countries.name as country,states.name as state,cities.name as city');
		$this->db->from('users_posting_jobs');
		$this->db->join('countries','users_posting_jobs.country_id=countries.id','LEFT');
		$this->db->join('states','users_posting_jobs.state_id=states.id','LEFT');
		$this->db->join('cities','users_posting_jobs.city_id=cities.id','LEFT');
		$this->db->join('skills','skills.id=users_posting_jobs.skill_id','LEFT');
		if($total){
			return $this->db->get()->num_rows();
		}
		$this->db->order_by('users_posting_jobs.'.$order_by, 'users_posting_jobs.'.$order_mode);
		$this->db->limit($limit,$offset);
		//echo $this->db->last_query();die;
		return $this->db->get()->result();
	}
}
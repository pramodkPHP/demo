<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Login_model extends CI_Model{
	function __costruct()
	{
		Parent::__construct();
		$this->load->database();
	}
	public function login($data){
		$response=$this->db->where('username',$data['username'])
		->where('password',md5($data['password']))
		->get('admin');
		if($response->num_rows()){
			$user=$response->row();
			$session=array(
				'login_admin'=>true,
				'user_id'=>$user->id,
				'email'=>$user->email,
				'last_login'=>$user->last_login,
			);
			$this->session->set_userdata($session);
			$this->load->model('common_model');
			$data=array(
				'id'=>$user->id,
				'last_login'=>date('Y-m-d H:i:s')
			);
			$affected_id=$this->common_model->save($data,'admin');
			return true;
		}
		return false;
	}
	
}
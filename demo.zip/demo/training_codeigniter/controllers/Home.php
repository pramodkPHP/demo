<?php
/***********************************
Default Controller for front end home page
Date:09 Jan 2016
Author:Pramod Kumar
************************************/
defined('BASEPATH') OR exit('No direct script access allowed');
class Home extends Front_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model(array('Common_model','Supplier_model'));	
	}
	public function index()
	{	
		$data['CI']  		=	$this;
		$data['country']	= 	$this->Common_model->get_AllCountry();
		$data['skills'] 	= 	$this->Common_model->get_skills();
		$data['questions']	=	$this->Common_model->get_questions();
		$data['functional']	=	$this->Common_model->get_functional_areas();
		//print_r($data['functional']);
		$this->view('home',$data);
	}
	/***********global expert*******************/
	public function global_expert(){
		
		$data['country']	= $this->Common_model->get_AllCountry();
		$data['skills'] 	= $this->Common_model->get_skills();
		$data['functional']	= $this->Common_model->get_functional_areas();
		$this->view('global_expert',$data);
	}
	
	/**********************send inquery form*********************/
	public function send_inquiry(){
		
		if(!$_POST){
			echo ERROR;
		}else{
				$email 				= $this->input->post('email');
				$title 				= $this->input->post('title');
				$skill_id 			= $this->input->post('skill_id');
				$industry_expertise_id 	= $this->input->post('industry_expertise_id');
				$job_country_id 	= $this->input->post('job_country_id');
				$job_state_id 		= $this->input->post('job_state_id');
				$job_city_id 		= $this->input->post('job_city_id');
				$start_date 		= $this->input->post('job_start_date');
				$end_date 			= $this->input->post('job_end_date');
				$description 		= $this->input->post('description');
				
				//print_r($startDate);die;
				$save=array(
					'email'=>$email,
					'title'=>$title,
					'skill_id'=>$skill_id,
					'industry_expertise_id'=>$industry_expertise_id,
					'country_id'=>$job_country_id,
					'state_id'=>$job_state_id,
					'city_id'=>$job_city_id,
					'job_start_date'=>$start_date,
					'job_end_date'=>$end_date,
					'description'=>$description
				);
				//print_r($save);die;
				$insertId = $this->Common_model->save_enquiry($save);
				if($insertId>0){			
					$this->send_enquiry_email($insertId,$skill_id);	
					echo 'Success';die;
				}else{
					echo ERROR;die;
				}	
		}
	}
	
	/************send mail***********************/
	function send_enquiry_email($insertId,$skill){
		
		$result = $this->Common_model->get_inquiry_details($insertId);
		//echo "<pre>";print_r($result);"</pre>";die;
		$this->load->library('email');
		$config['protocol']     = 'mail';
		$config['mailpath']     = "/usr/bin/sendmail"; 
		$config['smtp_host']    = 'localhost';
		$config['smtp_port']    = '465';
		$config['smtp_timeout'] = '7';
		$config['smtp_user']    = 'pantaron.education@gmail.com';
		$config['smtp_pass']    = 'Pantaron@1234';
		$config['charset']    	= 'utf-8';
		$config['newline']    	= "\r\n";
		$config['mailtype'] 	= 'html'; // or html
		$config['validation'] = TRUE; // bool whether to validate email or not      
		$this->email->initialize($config);
		$this->email->from('donotreply@infutive.com',SITE_NAME);
		$this->email->to(ADMIN_EMAIL);
		$skill	=	isset($result[0]['skill']) ? $result[0]['skill']:'N/A';
		//$this->email->cc($admin['email']);
		$this->email->subject('Training Enquiry');
		$message = "Enquiry from ".SITE_NAME."! <br><br> Details are following below: <br> User Inquiry Email: ".$result[0]['email'];
		$message .= '<br>'."Requirement title: ".$result[0]['title'].'<br>';
		$message .= " Skill: ".$skill."<br>";
		$message .= " Functional Area: ".$result[0]['functional_area']."<br>";
		$message .= " Country: ".$result[0]['country'].','." State: ".$result[0]['state'].','." City: ".$result[0]['city'].'<br>';
		$message .= " Required Training Start From: ".$result[0]['job_start_date']."-".$result[0]['job_end_date'].'<br>';
		$message .= " Requirement: ".$result[0]['description'].'<br>';
		$message .= "<br />Thanks for joining ".SITE_NAME."!<br /><br />Sincerely,<br />".SITE_NAME;
		$this->email->message($message);
		//$this->email->clear();
		if($this->email->send()){
			return true;
			//echo $this->email->print_debugger();
		}else{
			echo $this->email->print_debugger();
		}
		
	}
	
}

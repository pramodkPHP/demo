<?php
/***********************************
Default Controller for front end home page
Date:09 Jan 2016
Author:Pramod Kumar
************************************/
defined('BASEPATH') OR exit('No direct script access allowed');
class Job extends Front_Controller {
	public function __construct(){
		parent::__construct();
		$this->load->library('pagination');
		$this->load->model(array('Users_model','Common_model','Supplier_model'));	
	}
	public function job_expires(){
		
		if($this->input->is_ajax_request()){
			$data	=	array(
							'id'=>$this->input->post('job_id'),
							'status'=>'1'
						);
			$result = $this->Common_model->save($data,'users_posting_jobs');
			if($result>0){
				echo 'SUCCESS';die;
			}else{
				echo ERROR;die;
			}
		}
	}
/*********************************** End of function *********************/	
}

<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Secure extends Secure_Controller
{
	function __construct()
	{
		parent::__construct();
		/* Check if admin already logged in */
	}
	public function index(){
		redirect(base_url().'admin/secure/login');
	}
	public function login()
	{
		if($this->login)
			redirect(base_url().'admin/dashboard');
		$this->form_validation->set_rules('username', 'Username', 'required');
		$this->form_validation->set_rules('password', 'Password', 'required');
		if($this->form_validation->run() == FALSE)
		{
			$data['ajax']=$this->ajax;
			$data['username']=$this->input->post('username');
			$data['password']='';
			if($this->input->post('ajax')){
				$fields=array(
					'username'=>true,
					'password'=>true,
				);
				foreach($fields as $key=>$val){
					if(form_error($key))
					{
						$fields[$key]=form_error($key);
					}
				}
				$response=array(
					'error'=>true,
					'message'=>'',
					'fields'=>$fields,
					'validation_error'=>true,
				);
				echo json_encode($response);
			}
			else	
				$this->view('secure/admin_login',$data);
		}
		else{   
		
			/* After post */
			$data=array(
				'username'=>$this->input->post('username'),
				'password'=>$this->input->post('password')
			);
			
			if($this->login_model->login($data))
			{
				if($this->input->post('ajax')){
					$response=array(
						'error'=>false,
						'message'=>'Login successfully',
						'validation_error'=>false,
					);
				}
				else
				{
					redirect(base_url().'admin/dashboad');
				}
			}
			else
			{
				$msg='Please enter correct login details';
				if($this->input->post('ajax')){
					$response=array(
						'error'=>true,
						'message'=>$msg,
						'validation_error'=>false,
					);
				}
				else{
					$this->session->set_flashdata('error',$msg);
					redirect(base_url().'admin/secure/login');
				}
			}
			echo json_encode($response);
		}
	}
	public function logout()
	{
		$this->session->sess_destroy();
		redirect(base_url().'admin/secure/login');
	}
	
}
<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Suppliers extends Admin_Controller
{
	function __construct()
	{
		parent::__construct();
		$this->current_date=date('Y-m-d H:i:s');
		$this->load->library('pagination');
		$this->load->library('session');
		$this->load->model(array('Users_model','Common_model','Supplier_model', 'Events_model'));	
	}
	
	public function index($offset=0){ 
		$data['CI'] 			=	$this;
		$data['user_type']		=	1;
		$data['firm_type']		=	0;
		$data['total_rows']		= $this->Users_model->admin_get_users($data,true);
		//echo $data['total_rows'];die;
		$data['base_url']		= base_url().'admin/suppliers/index';
		$data['per_page']		= $this->perpage;
		$data['num_links'] 		= $this->num_pages;
		$data['cur_tag_open'] 	= $this->cur_tag_open;
		$data['cur_tag_close']	= $this->cur_tag_close;
		$data['next_link'] 		= $this->next_link;
		$data['prev_link'] 		= $this->prev_link;
		$this->pagination->initialize($data);
		$data['links']			= $this->pagination->create_links();
		$data['rows']			= $this->Users_model->admin_get_users($data,false, $offset, $this->perpage);
		$data['offset']			= $offset;
		$data['users']			= 'Supplier Individual';
		//echo "<pre>";print_r($data['rows']);echo "</pre>";
		$this->view('admin/suppliers/index', $data);
	
	}
	
	public function organization($offset=0){ 
		$data['CI'] 			=	$this;
		$data['user_type']		=	1;
		$data['firm_type']		=	1;
		$data['total_rows']		= $this->Users_model->admin_get_users($data,true);
		//echo $data['total_rows'];die;
		$data['base_url']		= base_url().'admin/suppliers/organization';
		$data['per_page']		= $this->perpage;
		$data['num_links'] 		= $this->num_pages;
		$data['cur_tag_open'] 	= $this->cur_tag_open;
		$data['cur_tag_close']	= $this->cur_tag_close;
		$data['next_link'] 		= $this->next_link;
		$data['prev_link'] 		= $this->prev_link;
		$this->pagination->initialize($data);
		$data['links']			= $this->pagination->create_links();
		$data['rows']			= $this->Users_model->admin_get_users($data,false, $offset, $this->perpage);
		$data['offset']			= $offset;
		$data['users']			= 'Supplier Organization';
		//echo "<pre>";print_r($data['rows']);echo "</pre>";
		$this->view('admin/suppliers/index', $data);
	
	}
	
	
	public function new_supplier($offset=0){ 
		$data['CI'] 			=	$this;
		$data['user_type']		=	1;
		$data['firm_type']		=	0;
		$data['modified_date']	=	true;	
		$data['total_rows']		= 	$this->Users_model->admin_get_users($data,true);
		//echo $data['total_rows'];die;
		$data['base_url']		= base_url().'admin/suppliers/index';
		$data['per_page']		= $this->perpage;
		$data['num_links'] 		= $this->num_pages;
		$data['cur_tag_open'] 	= $this->cur_tag_open;
		$data['cur_tag_close']	= $this->cur_tag_close;
		$data['next_link'] 		= $this->next_link;
		$data['prev_link'] 		= $this->prev_link;
		$this->pagination->initialize($data);
		$data['links']			= $this->pagination->create_links();
		$data['rows']			= $this->Users_model->admin_get_users($data,false, $offset, $this->perpage);
		$data['offset']			= $offset;
		$data['users']			= 'Supplier Individual';
		//echo "<pre>";print_r($data['rows']);echo "</pre>";
		$this->view('admin/suppliers/index', $data);
	
	}
	
	public function new_org($offset=0){ 
		$data['CI'] 			=	$this;
		$data['user_type']		=	1;
		$data['firm_type']		=	1;
		$data['modified_date']	=	true;	
		$data['total_rows']		= $this->Users_model->admin_get_users($data,true);
		//echo $data['total_rows'];die;
		$data['base_url']		= base_url().'admin/suppliers/organization';
		$data['per_page']		= $this->perpage;
		$data['num_links'] 		= $this->num_pages;
		$data['cur_tag_open'] 	= $this->cur_tag_open;
		$data['cur_tag_close']	= $this->cur_tag_close;
		$data['next_link'] 		= $this->next_link;
		$data['prev_link'] 		= $this->prev_link;
		$this->pagination->initialize($data);
		$data['links']			= $this->pagination->create_links();
		$data['rows']			= $this->Users_model->admin_get_users($data,false, $offset, $this->perpage);
		$data['offset']			= $offset;
		$data['users']			= 'Supplier Organization';
		//echo "<pre>";print_r($data['rows']);echo "</pre>";
		$this->view('admin/suppliers/index', $data);
	
	}
	
	/***************status change********************/
	public function admin_users_status_change(){
		
		if($this->input->is_ajax_request()){
			$job_id = $this->input->post('jobId');
			$status = $this->input->post('status');
			$status_id 	= ($status == '0') ? '1' : '0';
			$data	=	array(
							'id'=>$job_id,
							'status'=>$status_id
						);
			//print_r($data);die;
			$result = $this->Common_model->save($data,'users');
			if($result>0){
				$status_id 				= ($status == '0') ? '1' : '0';
           		$this->data['status'] 	= $status_id;
				$this->data['id'] 		= $job_id;
                $this->partial('admin/general_status',$this->data);
			}else{
				echo ERROR;die;
			}
		}
	}
	
	/*************delete particular job***************/
	public function admin_users_delete(){
		
		if($this->input->is_ajax_request()){
			$job_id = $this->input->post('jobId');
			$result = $this->Users_model->admin_delete_users($job_id,'users');
			if($result>0){
           		echo 'Success';die;
			}else{
				echo ERROR;die;
			}
		}
	
	}
	
	public function pricing_plan($type=0){
	
		$data			=	array();
		$data['result']	=	$this->Supplier_model->admin_get_pricing_plan($type);
		$this->view('admin/suppliers/pricing_plan', $data);
	
	}
	
	public function update_plan($id = NULL){
	
		if($id!=NULL)
		{
			$data	=	$this->Common_model->get_data($id, 'supplier_pricing_plans');
			//print_r($data);die;
			if(!empty($_POST)){  //print_r($_POST);die;
				$this->form_validation->set_rules('services_fee', 'Service Fee', 'trim|required|xss_clean');
				$this->form_validation->set_rules('project_fee', 'Project Fee', 'trim|required|xss_clean');
				$this->form_validation->set_rules('cash_back', 'Cash Back', 'trim|required|xss_clean');
				$this->form_validation->set_rules('functional_area_listing', 'Functional Limit', 'trim|required|xss_clean');
				$this->form_validation->set_rules('skills_listing', 'Skill Limit', 'trim|required|xss_clean');
				$this->form_validation->set_rules('annual_discount', 'Annual Discount', 'trim|required|xss_clean');
				
				if($this->form_validation->run() == FALSE)
				{
					$data->error=	validation_errors();
					//print_r($data);die;
					$this->view('admin/suppliers/update_plan', $data);
				}else{
					
					$data	=	array(
									'id'=>$this->input->post('id'),
									'services_fee'=>$this->input->post('services_fee'),
									'project_fee'=>$this->input->post('project_fee'),
									'cash_back'=>$this->input->post('cash_back'),
									'functional_area_listing'=>$this->input->post('functional_area_listing'),
									'skills_listing'=>$this->input->post('skills_listing'),
									'youtube_limit_check'=>$this->input->post('youtube_limit_check'),
									'annual_discount'=>$this->input->post('annual_discount')
							);
					$this->Common_model->save($data,'supplier_pricing_plans');
					redirect('admin/suppliers/pricing_plan');
					
				}
			}
			$this->view('admin/suppliers/update_plan', $data);
		}
		else{
			redirect('admin/suppliers/pricing_plan');
		}
	
	}
	
	
	public function individual_premium($offset=0){
	
		$data['CI'] 			=	$this;
		$data['firm_type']		=	0;
		$data['total_rows']		= $this->Supplier_model->admin_get_suppliers_premium($data,true);
		//echo $data['total_rows'];die;
		$data['base_url']		= base_url().'admin/suppliers/individual_premium';
		$data['per_page']		= $this->perpage;
		$data['num_links'] 		= $this->num_pages;
		$data['cur_tag_open'] 	= $this->cur_tag_open;
		$data['cur_tag_close']	= $this->cur_tag_close;
		$data['next_link'] 		= $this->next_link;
		$data['prev_link'] 		= $this->prev_link;
		$this->pagination->initialize($data);
		$data['links']			= $this->pagination->create_links();
		$data['rows']			= $this->Supplier_model->admin_get_suppliers_premium($data,false, $offset, $this->perpage);
		$data['offset']			= $offset;
		$data['users']			= 'Supplier Individual Premium';
		//echo "<pre>";print_r($data['rows']);echo "</pre>";
		$this->view('admin/suppliers/individual_premium', $data);
	}
	
	
	public function organization_premium($offset=0){
	
		$data['CI'] 			=	$this;
		$data['firm_type']		=	1;
		$data['total_rows']		= $this->Supplier_model->admin_get_suppliers_premium($data,true);
		//echo $data['total_rows'];die;
		$data['base_url']		= base_url().'admin/suppliers/organization_premium';
		$data['per_page']		= $this->perpage;
		$data['num_links'] 		= $this->num_pages;
		$data['cur_tag_open'] 	= $this->cur_tag_open;
		$data['cur_tag_close']	= $this->cur_tag_close;
		$data['next_link'] 		= $this->next_link;
		$data['prev_link'] 		= $this->prev_link;
		$this->pagination->initialize($data);
		$data['links']			= $this->pagination->create_links();
		$data['rows']			= $this->Supplier_model->admin_get_suppliers_premium($data,false, $offset, $this->perpage);
		$data['offset']			= $offset;
		$data['users']			= 'Supplier Organization Premium';
		//echo "<pre>";print_r($data['rows']);echo "</pre>";
		$this->view('admin/suppliers/individual_premium', $data);
	}
	
	
}
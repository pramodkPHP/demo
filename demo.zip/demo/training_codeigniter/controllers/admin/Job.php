<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Job extends Admin_Controller
{
	function __construct()
	{
		parent::__construct();
		$this->current_date=date('Y-m-d H:i:s');
		$this->load->library('pagination');
		$this->load->library('session');
		$this->load->model(array('Job_model','Users_model','Common_model'));	
	}
	
	public function index($offset=0){ 

		$data['CI'] 			= $this;
		//echo $offset;die;
		$data['total_rows']		= $this->Job_model->get_jobs($data,true);
		$data['per_page']		= LIMIT_PER_PAGE;
		//echo $data['total_rows'];die;
		$data['base_url']		= base_url().'admin/job/index';
		$data['per_page']		= LIMIT_PER_PAGE;
		$data['num_links'] 		= $this->num_pages;
		$data['cur_tag_open'] 	= $this->cur_tag_open;
		$data['cur_tag_close']	= $this->cur_tag_close;
		$data['next_link'] 		= $this->next_link;
		$data['prev_link'] 		= $this->prev_link;
		$this->pagination->initialize($data);
		$data['links']			= $this->pagination->create_links();
		$data['rows']			= $this->Job_model->get_jobs($data,false, $offset, $this->perpage);
		$data['offset']			= $offset;
		//echo "<pre>";print_r($data['rows']);echo "</pre>";
		$this->view('admin/jobs/index', $data);
	
	}
	
	
	/***************status change********************/
	public function admin_status_change(){
		
		if($this->input->is_ajax_request()){
			$job_id = $this->input->post('jobId');
			$status = $this->input->post('status');
			$status_id 	= ($status == '0') ? '1' : '0';
			$data	=	array(
							'id'=>$job_id,
							'status'=>$status_id
						);
			//print_r($data);die;
			$result = $this->Common_model->save($data,'users_posting_jobs');
			if($result>0){
				$status_id 				= ($status == '0') ? '1' : '0';
           		$this->data['status'] 	= $status_id;
				$this->data['id'] 		= $job_id;
                $this->partial('admin/general_status',$this->data);
			}else{
				echo ERROR;die;
			}
		}
	}
	
	/*************delete particular job***************/
	public function admin_jobs_delete(){
		
		if($this->input->is_ajax_request()){
			$job_id = $this->input->post('jobId');
			$result = $this->Users_model->admin_delete_users($job_id,'users_posting_jobs');
			if($result>0){
           		echo 'Success';die;
			}else{
				echo ERROR;die;
			}
		}
	
	}
	
	
}
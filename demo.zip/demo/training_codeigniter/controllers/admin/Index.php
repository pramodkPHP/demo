<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Index extends Admin_Controller
{
	function __construct()
	{
		parent::__construct();
		$this->load->model(array('common_model','Common_model'));
		$this->table='industry_expertises';
		$this->redirect=base_url().'admin/index/industry_expertises';
	}
	public function industry_expertises($offset=0){
		$this->load->library('pagination');
		$data=array();
		
		$config['total_rows'] = $this->common_model->get_industry_expertises(true);
		$config['base_url'] = base_url().'admin/index/industry_expertises/';
		$config['per_page'] = $this->perpage;
		$config['anchor_class'] = 'page';
		
		
		$this->pagination->initialize($config);
		$data['links']=$this->pagination->create_links();
		$data['rows']=$this->common_model->get_industry_expertises(false, true, $offset, $config['per_page']);
		$data['per_page'] = $config['per_page'];
		$data['offset'] =$offset;
		$this->view('admin/industry_expertises', $data);
	}
	public function industry_expertise_form($id=NULL){
		$data=array();
		$data['name']='';
		$data['description']='';
		$data['button_value']='Add New';
		if($id!=NULL)
		{
			$result=$this->common_model->get_data($id, 'industry_expertises');
			if($result)
			{
				$data['name']=$result->name;
				$data['description']=$result->description;
				$this->action='industry_expertise_form/'.$result->id;
				$data['button_value']='Update';
			}
			else
				show_404();
			
			$this->form_validation->set_rules('name', 'Name', 'required|max_length[100]');
		}
		else
			$this->form_validation->set_rules('name', 'Name', 'required|max_length[100]|is_unique[industry_expertises.name]');
		
		if($this->form_validation->run() == FALSE)
		{
			$data['action']='industry_expertise_form/'.$id;
			$data['heading']='Industry Expertise';
			$data['ckeditor'] = $this->ckeditor();
			$this->view('admin/industry_expertise_form', $data);
		}
		else
		{
			$save=array(
				'name'=>ucfirst($this->input->post('name')),
				'description'=>$this->input->post('description'),
			);
			if($id!=NULL)
				$save['id']=$id;
			else
				$save['created_at']=$this->current_date;
			
			$affected_id=$this->common_model->save($save, 'industry_expertises');
			redirect(base_url().'admin/index/industry_expertises');
		}
	}
	public function change_password(){
		$this->redirect=
		$this->form_validation->set_rules('password', 'Password', 'required');
		$this->form_validation->set_rules('conf_password', 'Confirm Password', 'required|matches[password]');
		if($this->form_validation->run() == FALSE)
		{
			$this->view('admin/change-password');
		}
		else
		{
			$save=array(
				'id'=>$this->session->userdata('user_id'),
				'password'=>md5($this->input->post('password')),
				'last_password_change'=>$this->current_date,
			);
			$affected_id=$this->common_model->save($save, 'admin');
			$this->session->set_flashdata('message','Your password has been successfully changed.');
			redirect(base_url().'admin/index/change_password');
		}
		
	}
	public function test(){
		$this->load->library('email');

		$this->email->from('your@example.com', 'Your Name');
		$this->email->to('justdeepoo@gmail.com');
		$this->email->subject('Email Test');
		$this->email->message('Testing the email class.');

		$this->email->send();

		echo $this->email->print_debugger();
	}
	
	/***************status change********************/
	public function admin_status_change(){
		
		if($this->input->is_ajax_request()){
			$job_id = $this->input->post('jobId');
			$status = $this->input->post('status');
			$table = $this->input->post('table');
			$status_id 	= ($status == '0') ? '1' : '0';
			$data	=	array(
							'id'=>$job_id,
							'is_active'=>$status_id
						);
			//print_r($data);die;
			$result = $this->Common_model->save($data,$table);
			if($result>0){
				$status_id 				= ($status == '0') ? '1' : '0';
           		$this->data['is_active'] = $status_id;
				$this->data['id'] 		= $job_id;
                $this->partial('admin/general_status',$this->data);
			}else{
				echo ERROR;die;
			}
		}
	}
}
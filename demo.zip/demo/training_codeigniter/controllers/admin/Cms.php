<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Cms extends Admin_Controller
{
	function __construct()
	{
		parent::__construct();
		/* Check if admin already logged in */
		$this->load->model('Pages_model');
		$this->current_date=date('Y-m-d H:i:s');
		$this->redirect=base_url().'admin/cms';
	}
	public function index($offset=0){

		$config['total_rows']	= $this->Pages_model->get_pages(true);

		$config['base_url']		= base_url().'admin/cms/index';

		$config['per_page']		= $this->perpage;

		$this->pagination->initialize($config);

		$data['links']			= $this->pagination->create_links();

		$data['rows']			= $this->Pages_model->get_pages(false, $offset, $this->perpage);

		$data['per_page']		= $config['per_page'];

		$data['offset']			= $offset;
		//print_r($data['rows']);
		$this->view('admin/pages/index', $data);

	}

	public function add_pages($id=NULL){ 
		$data=array();
		$data['title']='';
		$data['description']='';
		$data['meta_keywords']='';
		$data['meta_description']='';
		$data['slug']='';
		$data['button_value']='Add New';
		//$path = base_url().'public/js/ckfinder/';
		$width = '700px';
		//$this->editor($path, $width);
		if($id!=NULL)
		{
			$result=$this->Pages_model->get_data($id, 'pages');
			if($result)
			{
				$data['title']				=	$result->title;
				$data['meta_keywords']		=	$result->meta_keywords;
				$data['meta_description']	=	$result->meta_description;
				$data['slug']				=	strtolower($result->slug);
				$data['description']		=	$result->description;
				$this->action='add_pages/'.$result->id;
				$data['button_value']='Update';
				//$data['ckeditor'] = $this->ckeditor();
			}
			else
				show_404();
			$this->form_validation->set_rules('title', 'Tile', 'required');
		}
		else
			$this->form_validation->set_rules('title', 'Title', 'required');
		
		if($this->form_validation->run() == FALSE)
		{
			$data['action']='add_pages/'.$id;
			$data['heading']='Pages';
			//$data['ckeditor'] = $this->ckeditor();
			$this->view('admin/pages/add_pages', $data);
		}
		else
		{
			$save=array(
				'title'=>ucfirst($this->input->post('title')),
				'meta_keywords'=>$this->input->post('meta_keywords'),
				'meta_description'=>$this->input->post('meta_description'),
				'slug'=>strtolower($this->input->post('slug')),
				'description'=>$this->input->post('description'),
			);
			if($id!=NULL)
				$save['id']=$id;
			else
				$save['created']=$this->current_date;
			//print_r($save);die;
			$affected_id=$this->Pages_model->save($save, 'pages');
			redirect(base_url().'admin/cms/index');
		}
	}
	
	/***************status change********************/
	public function status_change(){
		
		if($this->input->is_ajax_request()){
			$page_id = $this->input->post('pageId');
			$status = $this->input->post('status');
			$status_id 	= ($status == '0') ? '1' : '0';
			$data	=	array(
							'id'=>$page_id,
							'status'=>$status_id
						);
			//print_r($data);die;
			$result = $this->Pages_model->save($data,'pages');
			if($result>0){
				$status_id 				= ($status == '0') ? '1' : '0';
           		$this->data['status'] 	= $status_id;
				$this->data['id'] 		= $page_id;
                $this->partial('admin/general_status',$this->data);
			}else{
				echo ERROR;die;
			}
		}
	}
	
	/*************delete particular job***************/
	public function pages_delete(){
		
		if($this->input->is_ajax_request()){
			$job_id = $this->input->post('jobId');
			$result = $this->Skills_model->delete_jobs($job_id,'skills');
			if($result>0){
           		echo 'Success';die;
			}else{
				echo ERROR;die;
			}
		}
	
	}
	
	 function editor($path,$width) {
		//Loading Library For Ckeditor
		$this->load->library('ckeditor');
		$this->load->library('ckfinder');
		//configure base path of ckeditor folder 
		$this->ckeditor->basePath = base_url().'public/js/ckeditor/';
		$this->ckeditor-> config['toolbar'] = 'Full';
		$this->ckeditor->config['language'] = 'en';
		$this->ckeditor-> config['width'] = $width;
		$ckeditor = new ckeditor();
		$ckeditor->editor($this->ckeditor, $path);
		//configure ckfinder with ckeditor config 
		//$this->ckfinder->SetupCKEditor($this->ckeditor,$path); 
	}
}
<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Skills extends Admin_Controller
{
	function __construct()
	{
		parent::__construct();
		/* Check if admin already logged in */
		$this->load->model('Skills_model');
		$this->current_date=date('Y-m-d H:i:s');
		$this->redirect=base_url().'admin/skills';
	}
	public function index($offset=0){

		$config['total_rows']	= $this->Skills_model->get_skills(true);

		$config['base_url']		= base_url().'admin/skills/index';

		$config['per_page']		= $this->perpage;

		$this->pagination->initialize($config);

		$data['links']			= $this->pagination->create_links();

		$data['rows']			= $this->Skills_model->get_skills(false, $offset, $this->perpage);

		$data['per_page']		= $config['per_page'];

		$data['offset']			= $offset;

		$this->view('admin/skills/index', $data);

	}

	public function add_skills($id=NULL){
		$data=array();
		$data['title']='';
		$data['description']='';
		$data['button_value']='Add New';
		if($id!=NULL)
		{
			$result=$this->Skills_model->get_data($id, 'skills');
			if($result)
			{
				$data['title']		=$result->title;
				$data['description']=$result->description;
				$this->action='add_skills/'.$result->id;
				$data['button_value']='Update';
			}
			else
				show_404();
			$this->form_validation->set_rules('title', 'Skill', 'required|max_length[100]');
		}
		else
			$this->form_validation->set_rules('title', 'Skill', 'required|is_unique[skills.title]');
		
		if($this->form_validation->run() == FALSE)
		{
			$data['action']='add_skills/'.$id;
			$data['heading']='Skills';
			//$data['ckeditor'] = $this->ckeditor();
			$this->view('admin/skills/add_skills', $data);
		}
		else
		{
			$save=array(
				'title'=>ucfirst($this->input->post('title')),
				'description'=>$this->input->post('description'),
			);
			if($id!=NULL)
				$save['id']=$id;
			else
				$save['created_at']=$this->current_date;
			//print_r($save);die;
			$affected_id=$this->Skills_model->save($save, 'skills');
			redirect(base_url().'admin/skills');
		}
	}
	
	/***************status change********************/
	public function status_change(){
		
		if($this->input->is_ajax_request()){
			$job_id = $this->input->post('jobId');
			$status = $this->input->post('status');
			$status_id 	= ($status == '0') ? '1' : '0';
			$data	=	array(
							'id'=>$job_id,
							'status'=>$status_id
						);
			//print_r($data);die;
			$result = $this->Skills_model->save($data,'skills');
			if($result>0){
				$status_id 				= ($status == '0') ? '1' : '0';
           		$this->data['status'] 	= $status_id;
				$this->data['id'] 		= $job_id;
                $this->partial('admin/general_status',$this->data);
			}else{
				echo ERROR;die;
			}
		}
	}
	
	/*************delete particular job***************/
	public function skills_delete(){
		
		if($this->input->is_ajax_request()){
			$job_id = $this->input->post('jobId');
			$result = $this->Skills_model->delete_jobs($job_id,'skills');
			if($result>0){
           		echo 'Success';die;
			}else{
				echo ERROR;die;
			}
		}
	
	}

}
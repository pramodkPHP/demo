<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Users extends Admin_Controller
{
	function __construct()
	{
		parent::__construct();
		$this->current_date=date('Y-m-d H:i:s');
		$this->load->library('pagination');
		$this->load->library('session');
		$this->load->model(array('Users_model','Common_model','Supplier_model', 'Events_model'));	
		
	}
	
	public function index($offset=0){ 
		$data['CI'] 			=	$this;
		$data['user_type']		=	0;
		$data['modified_date']	=	false;	
		$data['total_rows']		= $this->Users_model->admin_get_users($data,true);
		//echo $data['total_rows'];die;
		$data['base_url']		= base_url().'admin/users/index';
		$data['per_page']		= $this->perpage;
		$data['num_links'] 		= $this->num_pages;
		$data['cur_tag_open'] 	= $this->cur_tag_open;
		$data['cur_tag_close']	= $this->cur_tag_close;
		$data['next_link'] 		= $this->next_link;
		$data['prev_link'] 		= $this->prev_link;
		$this->pagination->initialize($data);
		$data['links']			= $this->pagination->create_links();
		$data['rows']			= $this->Users_model->admin_get_users($data,false, $offset, $this->perpage);
		$data['offset']			= $offset;
		//echo "<pre>";print_r($data['rows']);echo "</pre>";
		
		$this->view('admin/users/index', $data);
	
	}
	
	
	public function new_user($offset=0){ 
		$data['CI'] 			=	$this;
		$data['user_type']		=	0;
		$data['modified_date']	=	true;	
		$data['total_rows']		= $this->Users_model->admin_get_users($data,true);
		//echo $data['total_rows'];die;
		$data['base_url']		= base_url().'admin/users/new_user';
		$data['per_page']		= $this->perpage;
		$data['num_links'] 		= $this->num_pages;
		$data['cur_tag_open'] 	= $this->cur_tag_open;
		$data['cur_tag_close']	= $this->cur_tag_close;
		$data['next_link'] 		= $this->next_link;
		$data['prev_link'] 		= $this->prev_link;
		$this->pagination->initialize($data);
		$data['links']			= $this->pagination->create_links();
		$data['rows']			= $this->Users_model->admin_get_users($data,false, $offset, $this->perpage);
		$data['offset']			= $offset;
		//echo "<pre>";print_r($data['rows']);echo "</pre>";
		
		$this->view('admin/users/index', $data);
	
	}
	
	/***************status change********************/
	public function admin_users_status_change(){
		
		if($this->input->is_ajax_request()){
			$job_id = $this->input->post('jobId');
			$status = $this->input->post('status');
			$status_id 	= ($status == '0') ? '1' : '0';
			$data	=	array(
							'id'=>$job_id,
							'status'=>$status_id
						);
			//print_r($data);die;
			$result = $this->Common_model->save($data,'users');
			if($result>0){
				$status_id 				= ($status == '0') ? '1' : '0';
           		$this->data['status'] 	= $status_id;
				$this->data['id'] 		= $job_id;
                $this->partial('admin/general_status',$this->data);
			}else{
				echo ERROR;die;
			}
		}
	}
	
	/*************delete particular job***************/
	public function admin_users_delete(){
		
		if($this->input->is_ajax_request()){
			$job_id = $this->input->post('jobId');
			$result = $this->Users_model->admin_delete_users($job_id,'users');
			if($result>0){
           		echo 'Success';die;
			}else{
				echo ERROR;die;
			}
		}
	
	}
	
}
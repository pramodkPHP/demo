<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Experts extends Admin_Controller
{
	function __construct()
	{
		parent::__construct();
		/* Check if admin already logged in */
		$this->load->model('common_model');
		$this->current_date=date('Y-m-d H:i:s');
		$this->option='Experts';
		$this->action=base_url().'admin/experts/form';
		$this->table='expert_resources_roles';
		$this->redirect=base_url().'admin/'.strtolower($this->option).'/types';
	}
	public function index($offset=0){
		$config['total_rows'] = $this->common_model->get_experts(true);
		$config['base_url'] = base_url().'admin/experts/index/';
		$config['per_page'] = $this->perpage;
		$this->pagination->initialize($config);
		$data['links']=$this->pagination->create_links();
		$data['rows']=$this->common_model->get_experts(false, $offset, $this->perpage);
		$data['per_page'] = $config['per_page'];
		$data['offset'] =$offset;
		$this->view('admin/experts-resources', $data);
	}
}
<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Roles extends Admin_Controller
{

	function __construct()
	{
		parent::__construct();
		/* Check if admin already logged in */
		$this->load->model('common_model');
		$this->current_date=date('Y-m-d H:i:s');
		$this->option='Roles';
		$this->action=base_url().'admin/roles/form';
		$this->table='expert_resources_roles';
		$this->redirect=base_url().'admin/'.strtolower($this->option).'/types';
	}
}
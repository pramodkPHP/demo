<?php
/***********************************
Default Controller for front end home page
Date:09 Jan 2016
Author:Pramod Kumar
************************************/
defined('BASEPATH') OR exit('No direct script access allowed');
class Events extends Front_Controller {
	public function __construct(){
		parent::__construct();
		$this->load->model(array('Events_model','Common_model'));	
	}
	public function add_event()
	{	
		$session_data	= $this->session->userdata('Users');
		if(!isset($session_data) || $session_data['user_type'] ==0){
			redirect('/'); 
		}	
		if(!$_POST) {
			$this->data['training']=$this->Events_model->get_training_event();
			$this->view('events/add_event',$this->data);
		} else {
			//print_r($_FILES); die;
			
			$this->data['training']=$this->Events_model->get_training_event();
			$this->load->library('form_validation');
			$this->form_validation->set_error_delimiters( '', '<br>' );
			$this->form_validation->set_rules('code', '<strong>Institute Code</strong>', 'trim|required');
			$this->form_validation->set_rules('orgnization', '<strong>Orgnization</strong>', 'trim|required');
			$this->form_validation->set_rules('email', '<strong>Email</strong>', 'trim|required|valid_email');
			$this->form_validation->set_rules('location', '<strong>Location</strong>', 'trim|required');
			$this->form_validation->set_rules('expert_resources_id', '<strong>Training Category</strong>', 'trim|required');
			$this->form_validation->set_rules('contact_no', '<strong>Contact Number</strong>', 'trim|required');
			//$this->form_validation->set_rules('file', '<strong>Xls File/CSV</strong>', 'trim|required');
			if($this->form_validation->run() == FALSE){
				$error = $this->data['error']=validation_errors();
				//print_r($this->data['error']);die;
				$this->view('events/add_event',$this->data);
			} 
			else {
				  /***************upload xls file*********************/
				   //print_r($_POST);
					$config['upload_path'] 		= dirname($_SERVER["SCRIPT_FILENAME"]).'/public/uploads/';
					$config['allowed_types'] 	= 'csv';
					$this->load->library('upload', $config);
					//print_r($this->upload->do_upload());die;
					//$file = $_FILES['training_file']['name'];
					if ( ! $this->upload->do_upload('training_file'))
					{
						$error = array('error' => $this->upload->display_errors());
						//print_r($error);die;
						$this->view('events/add_event',$error);
					}
					else
					{
						$data = array('upload_data' => $this->upload->data());
						$session_data	= $this->session->userdata('Users');
						//print_r($data);die;
						$save=array(
							'code'=>$this->input->post('code'),
							'user_id'=>$session_data['id'],
							'orgnization'=>$this->input->post('orgnization'),
							'email'=>$this->input->post('email'),
							'location'=>$this->input->post('location'),
							'expert_resources_id'=>$this->input->post('expert_resources_id'),
							'contact_no'=>$this->input->post('contact_no'),
							'file'		=>$data['upload_data']['file_name']
					   );
					    $insertId = $this->Events_model->save_events($save);
						if($insertId>0){
							/***********import data from excel sheet*************/
							define('CSV_PATH',dirname($_SERVER["SCRIPT_FILENAME"]).'/public/uploads/');
							$csv_file = CSV_PATH . $data['upload_data']['file_name']; // Name of your CSV file
							$csv = array_map('str_getcsv', file($csv_file));
							//echo "<pre>";print_r($csv);echo "</pre>";
							$count = 0;
							$result = array();
							$c = 0;
							$header = 1;
							if(is_array($csv) && count($csv)>0){
									foreach($csv[0] as $key=>$value){
										if($header>17){
											if($count%16 == 0){
												$c++;
												$result[$c][]	=	$value;
											}else{
												$result[$c][] = $value;
											}
											$count++;
										}
										$header++;
									}
									for($i=1;$i<=count($result);$i++){ 
											$data=array(
														'event_id'=>$insertId,
														'icompany'=>$result[$i][0],
														'program_code'=>$result[$i][1],
														'program_title'=>$result[$i][2],
														'type_of_program'=>$result[$i][3],
														'functional_area'=>$result[$i][4],
														'investment'	=>$result[$i][5],
														'participants_level'=>$result[$i][6],
														'participants_number'=>$result[$i][7],
														'state'=>$result[$i][8],
														'city'=>$result[$i][9],
														'country'=>$result[$i][10],
														'start_date'=>$result[$i][11],
														'end_date'=>$result[$i][12],
														'start_work_week'=>$result[$i][13],
														'faculty'=>$result[$i][14],
														'hyperlink'	=>$result[$i][15]
														//'institute_code'=>$extract[1]
												   );
									//echo "<pre>";print_r($data);echo "</pre>";die;
									$this->Events_model->save_events_details($data); 
									}
							}
							/*****************End********************************/					
							$this->session->set_flashdata('success', 'Congratulations! Your Training Program successfully created in system.');
							redirect('events/add_event','refresh');
						}else{
							$this->session->set_flashdata('error', 'there is an error');
							redirect('events/add_event','refresh');
						}	
					}			
					/******************End upload xls file*****************/
				}						
		  }	
	}
	
	/*******************showing details**************/
	public function upcoming_events($value=NULL){
		//if (isset($id)){
			$this->data['data'] = $this->Events_model->get_experts_resources('Events',$value);
			$this->data['country']	= $this->Common_model->get_AllCountry();
			$this->data['skills'] 	= $this->Common_model->get_skills();
			//$this->data['data']=$this->Events_model->get_events();
			$this->view('events/upcoming_events',$this->data);
		//}else{
			//redirect('events/add_event','refresh');
		//}
	}

	/**************add institute*****************/
	public function add_institute(){
		
		if(!$_POST) {
			$error = "Please provide input";
			return $error;die;
		} else {
			$this->load->library('form_validation');
			$this->form_validation->set_error_delimiters('', '<br>' );
			$this->form_validation->set_rules('institute', '<strong>Name</strong>', 'trim|required|xss_clean');
			$this->form_validation->set_rules('website_url', '<strong>Website Url</strong>', 'trim|required|xss_clean');
			$this->form_validation->set_rules('email', '<strong>Email</strong>', 'trim|required|valid_email|xss_clean');
			//print_r(validation_errors()); die;	
			//$this->form_validation->set_rules('file', '<strong>Xls File/CSV</strong>', 'trim|required');
			if($this->form_validation->run() == FALSE){
				$error = $this->data['error']=validation_errors();
				echo $error;die;
				//$this->view('events/add_event',$this->data['error']);
			} 
			else { 
				  /***************upload xls file*********************/
					$name 			= $this->input->post('institute');
					$website_url 	= $this->input->post('website_url');
					$email 			= $this->input->post('email');
					$activationId	= base64_encode(time());
					$session_data	= $this->session->userdata('Users');
					
					if($this->Events_model->check_existUrl($website_url) != false){
						$email = $this->Events_model->check_existUrl($website_url);
						echo $email;die;
					}
					$save=array(
						'institute'=>$name,
						'website_url'=>$website_url,
						'email'=>$email,
						'user_id'=>$session_data['id'],
						'activation_code'=>$activationId,
				   );
					//print_r($save);die;
					$insertId = $this->Events_model->save_institutes($save);
					if($insertId>0){
						/*****************End********************************/	
						$this->send_email($insertId);				
						echo 'Success';die;
						//redirect('events/add_event','refresh');
					}else{
						echo ERROR;die;
					}	
				}			
				/******************End upload xls file*****************/						
		   }		

	}

	public function get_institutes($code){
		
		$code				=		$this->input->post('whereId');
		//echo $code		=		base64_decode($code);die;
		$institutes = $this->Events_model->get_institutes($code);
		echo $institutes;die;
	}


	/**************send email to add event **********************/
	  /************send mail***********************/
	  function send_email($institutesId){
	  
			//$admin = $this->admin_model->getinfo(); 
			$user = $this->Events_model->get_details($institutesId);
			//print_r($user);die;
			$this->load->library('email');
            $config['protocol']     = 'mail';
			$config['mailpath']     = "/usr/bin/sendmail"; 
            $config['smtp_host']    = 'localhost';
            $config['smtp_port']    = '465';
            $config['smtp_timeout'] = '7';
            $config['smtp_user']    = 'pantaron.education@gmail.com';
            $config['smtp_pass']    = 'Pantaron@1234';
            $config['charset']    	= 'utf-8';
            $config['newline']    	= "\r\n";
            $config['mailtype'] 	= 'text'; // or html
            $config['validation'] = TRUE; // bool whether to validate email or not      
            $this->email->initialize($config);
			$this->email->from('donotreply@infutive.com',SITE_NAME);
			$this->email->to($user['email']);
			//$this->email->cc($admin['email']);
			$this->email->subject('Add Event Secret Code');
			$message = "Welcome to ".SITE_NAME."! \n \n To add institution , Please use secret code to use in add event
			\n To continue, You can use secret code in adding add event:
			\n".$user['activation_code']."\n \n Thanks for joining ".SITE_NAME."!\n \n Sincerely, \n".SITE_NAME;
			$this->email->message($message);
			//$this->email->clear();
			if($this->email->send()){
				return true;
				//echo $this->email->print_debugger();
			}else{
				//echo $this->email->print_debugger();
			}
			
	  }
	  
	  
	  /****************************job details****************************/
	public function event_details($id = NULL){
		if($this->input->is_ajax_request()){
     		//Execute Your Code
			//echo $id					  = $this->input->post('id');die;
			$this->data['result'] = $this->Common_model->get_data($id,'training_calender');
			//print_r($this->data['result']);
			$this->partial('elements/jobs/event_details',$this->data);	
 		}
	}	
}

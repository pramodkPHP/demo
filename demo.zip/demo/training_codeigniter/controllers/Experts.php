<?php
/***********************************
Default Controller for front end home page
Date:31 Jan 2016
Author:Pramod Kumar
************************************/
defined('BASEPATH') OR exit('No direct script access allowed');
class Experts extends Front_Controller {
	
	public function __construct(){
		parent::__construct();
		$this->load->model(array('Experts_model','Common_model','Supplier_model'));	
	}
	/***************expert index page***************/
	public function index(){
		$this->data['CI'] 	= $this;	
		$data['experts']  	= $this->Supplier_model->get_experts_resources('Experts');
		$data['country']	= $this->Common_model->get_AllCountry();
		$data['skills'] 	= $this->Common_model->get_skills();
		$data['session'] 	= $this->session->userdata('Users');

		//print_r($data['experts']);
		$this->view('experts/experts',$data);
	}
/*********************************** End of function *********************/	
}

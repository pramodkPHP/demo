<?php

defined('BASEPATH') OR exit('No direct script access allowed');
class Pages extends Front_Controller {
	public function __construct(){
		parent::__construct();
		$this->load->library('form_validation');
	}
	
	public function index(){
		 $this->load->model('Pages_model');
		 $slug				=   strtolower($this->uri->segment(1));
		 $value				=	str_replace('-', '_', $slug);
		 $data['result']	=	$this->Pages_model->get_cms($value, 'pages');
		 //print_r($data);die;
		 if(empty($data['result'])){
		 	show_404();
		 }
		// print_r($data);die;
		 $this->view('pages/page', $data);
	}
	
	public function contact_us(){
		$this->load->model('Common_model');
		$this->form_validation->set_rules('name', 'Name', 'required|max_length[25]');
		$this->form_validation->set_rules('email', 'Email Address', 'required|max_length[50]');
		$this->form_validation->set_rules('inquiry_type', 'Inquiry About', 'required');
		$this->form_validation->set_rules('message', 'Message', 'required|max_length[500]');
		if($this->form_validation->run() == FALSE)
		{
			$data['inquiry_about']=$this->common_model->getOptions('All', false);
			$data['name']=$this->input->post('name');
			$data['email']=$this->input->post('email');
			$data['inquiry_type']=$this->input->post('inquiry_type');
			$data['message']=$this->input->post('message');
			$this->view('pages/contact-us', $data);
		}
		else
		{
			$save=array(
				'name'=>$this->input->post('name'),
				'email'=>$this->input->post('email'),
				'inquiry_type'=>$this->input->post('inquiry_type'),
				'message'=>$this->input->post('message'),
				'created_at'=>$this->current_date,
			);
			$this->common_model->save($save, 'user_contacts');
			$this->session->set_flashdata('message',true);
			
			/*
			Send mail to admin 
			*/
			$this->load->library('email');
			$config['mailtype'] = 'html';
			$this->email->initialize($config);
			$this->email->from(support_email, 'Contact Us Page');
			$this->email->to(ADMIN_EMAIL);
			$this->email->subject('New contact request');
			$this->email->message('Hi, </br>
				The details are- </br>
				Name - '.$this->input->post('name').'<br>
				Email Address - '.$this->input->post('email').'<br>
				Enquiry About - '.$this->input->post('inquiry_type').'<br>
				Message - '.$this->input->post('message').'<br><br> Thanks<br>'.SITE_NAME
			);
			$this->email->send();
			redirect(base_url().'pages/contact_us');
		}
	}
	
	/************pages sitemap***************/
	public function sitemap()
	{
		$data = "";//select urls from DB to Array
        header("Content-Type: text/xml;charset=iso-8859-1");
        $this->load->view("sitemap",$data);
	}
	

}

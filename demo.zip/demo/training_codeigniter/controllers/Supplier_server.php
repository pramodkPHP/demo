<?php
/***********************************
Default Controller for front end home page
Date:09 Jan 2016
Author:Pramod Kumar
************************************/
defined('BASEPATH') OR exit('No direct script access allowed');
class Supplier extends Front_Controller {
	public function __construct(){
		parent::__construct();
		$this->load->model(array('Users_model','Common_model','Experts_model','Supplier_model'));	
	}
	
	/******************remember me function ***************************/
	public function profile($id = NULL){
		$userData = $this->Users_model->get_details($id);
		$this->data['profile'] = $userData;
		//print_r($userData);die;
		if($userData['user_type']=='1'){
			$this->view('supplier/profile',$this->data);
		}else{
			redirect('/404');
		}
	}	
	/*********************upload profile using ajax********************/
	public function upload_profile_picture(){
		
		if($_FILES){ 
			//print_r($_FILES);die;
			$userData					= $this->session->userdata('Users');
			$config['upload_path'] 		= dirname($_SERVER["SCRIPT_FILENAME"]).'/public/users/';
			$config['allowed_types'] 	= 'png|jpg|jpeg|gif';
			$this->load->library('upload', $config);
			if (file_exists(DOCUMENT_PATH.$_FILES['file-input']['name'])) {
				//delete_files(DOCUMENT_PATH.$_FILES['picture']['name'], TRUE);
				 unlink('./public/users/' . $_FILES['file-input']['name']);
			}
			if ( ! $this->upload->do_upload('file-input'))
			{
				$picture = $this->input->post('file-input');
			}else{
				$data = array('upload_data' => $this->upload->data());
				$picture = $data['upload_data']['file_name'];
			}
			$save=array(
				'id'=>$userData['id'],
				'picture'=>$picture
			);
			$insertId 			= $this->Users_model->save_users($save);
			$image				= base_url('public/users/' . $picture);
			if($insertId>0){
				echo "<img src='".$image."' class='img-thumbnail img-circle' style='margin-bottom:10px;'>";
				die;
			}else{
				echo ERROR;die;
			}	
		}	
	}


	/*
		Date - 		31-01-2016
		Code by - 	Deepoo Gupta
		Code For -  Filter suppliers
	*/
	public function advance_search(){
		$data['CI']=$this;
		$data['heading']='Advance search';
		$data['search']=array(
			'advance-search'=>true,
			'experts'=>true,
			'resources'=>true
		);
		$data['suppliers']	= $this->Supplier_model->get_experts_resources();
		$data['skills'] 	= $this->Common_model->get_skills();
		$data['country']	= $this->Common_model->get_AllCountry();
		//$this->data['city']		=	$this->Common_model->get_AllCity(isset($this->data['supplier'][0]['state_id']) ? $this->data['supplier'][0]['state_id']:'');
		//echo "<pre>";print_r($data['suppliers']);echo "</pre>";die;
		$this->view('supplier/suppliers', $data);
	}
	public function expert($value){
		$value		=	urldecode($value);
		$data['CI'] =   $this;
		$heading	=	explode('+',$value);
		$data['heading']=ucwords(implode(' ',$heading));
		$data['search']=array(
			'advance-search'=>true,
			'experts'=>true,
			'resources'=>false
		);
		$data['suppliers']  = $this->Supplier_model->get_experts_resources('Experts',$value);
		$data['skills'] 	= $this->Common_model->get_skills();
		$data['country']	= $this->Common_model->get_AllCountry();
		//$data['count'] 		= $this->Experts_model->find_users_experties($expertId);
		$this->view('supplier/suppliers', $data);
	}
	public function resource($type){
		$value			=	urldecode($type);
		$data['CI']		=	$this;
		$heading		=	explode('+',$type);
		$data['heading']=	ucwords(implode(' ',$heading));
		$data['search']=array(
			'advance-search'=>true,
			'experts'=>false,
			'resources'=>true
		);
		$data['suppliers'] = $this->Supplier_model->get_experts_resources('Resources',$value);
		$data['skills'] 	= $this->Common_model->get_skills();
		$data['country']	= $this->Common_model->get_AllCountry();
		$this->view('supplier/suppliers', $data);
	}
	/*************get state from country id************/
	public function get_state(){
			$country_id		=	$this->input->post('whereId');
			$table			=	$this->input->post('table');
			$data 			=   $this->Common_model->get_state($country_id,$table);
			echo $data;die;
	}
	/*************get city from state id************/
	public function get_city($state_id){
			$states_id		=	$this->input->post('whereId');
			$table			=	$this->input->post('modelName');
			$data 			=   $this->Common_model->get_city($states_id,$table);
			echo $data;die;
	}
	
	public function individual($id = NULL){
		
	
		$session =	$this->session->userdata('Users');
		if(isset($session) && !empty($session) && empty($id)){
			$id		 =  $session['id'];
		}
		$this->data['session'] = $session;
		$this->data['CI'] 		=   $this;
		$this->data['supplier'] = 	$this->Users_model->details($id);
		if(empty($this->data['supplier'])){
			redirect('/');
		}
		$this->data['country']		= 	$this->Common_model->get_AllCountry();
		$this->data['skills'] 		= 	$this->Supplier_model->find_skills($id);
		
		$this->data['experience']	=	$this->Supplier_model->get_experience_areas($id);
		$this->data['certificate']	=	$this->Supplier_model->get_certificate_areas($id);
		$this->data['education']	=	$this->Supplier_model->get_education_areas($id);
		$this->view('supplier/individual',$this->data);
	}
	/*******************edit profile*******************/
	public function edit_profile(){
		
		$session 				=	$this->session->userdata('Users');
		$this->data['CI'] 		=   $this;	
		$this->data['supplier'] = 	$this->Users_model->details($session['id']);
		$this->data['roles']	=	$this->Experts_model->find_all_experties('Experts');
		$this->data['resources']=	$this->Experts_model->find_all_experties('Resources');
		$this->data['country']	=	$this->Common_model->get_AllCountry();
		$this->data['state']	=	$this->Common_model->get_AllState(isset($this->data['supplier'][0]['country_id']) ? $this->data['supplier'][0]['country_id']:'');
		$this->data['city']		=	$this->Common_model->get_AllCity(isset($this->data['supplier'][0]['state_id']) ? $this->data['supplier'][0]['state_id']:'');
		$this->data['functional']	=	$this->Common_model->get_functional_areas();
		
		$this->data['experience']	=	$this->Supplier_model->get_experience_areas($session['id']);
		$this->data['certificate']	=	$this->Supplier_model->get_certificate_areas($session['id']);
		$this->data['education']	=	$this->Supplier_model->get_education_areas($session['id']);
		$this->data['skills']		=	$this->Supplier_model->find_skills($session['id']);
		$this->data['session'] 		=	$this->session->userdata('Users');
		
		if(empty($this->data['supplier'])){
			redirect('/');
		}
		//echo "<pre>";print_r($this->data['education']);echo "</pre>";
		$this->view('supplier/update_profile',$this->data);
	}
	
	public function organization($id = NULL){
		if(!isset($id) || empty($id)){
			$session =	$this->session->userdata('Users');
			$id		 =   $session['id'];
			$this->data['session'] = $session;
		}
		$this->data['CI'] =   $this;
		$this->data['supplier'] = $this->Users_model->details($id);
		if(empty($this->data['supplier'])){
			redirect('/');
		}
		//echo "<pre>";print_r($this->data);echo "</pre>";
		$this->view('supplier/organization',$this->data);
		//$this->view('supplier/organization',$this->data);
	}
	
	/************add/update experties*********************/
	public function add_business_info(){
		
		if(!$_POST){
			return ERROR;
		}else{
				$session 		=	$this->session->userdata('Users');
				$about_us  		= 	$this->input->post('about_us');
				$experties[] 	=  	$this->input->post('experties');
				$resources[] 	=  	$this->input->post('resources');
				$countries[] 	=  	$this->input->post('user_country_id');
				$users_info=array(
						'id'=>$session['id'],
						'about_us'=>$about_us,
				   );
				$resultId = $this->Users_model->save_users($users_info);
				if($resultId>0){
					if(is_array($experties) && !empty($experties)){
						$experties_info=array(
							'user_id'=>$session['id'],
							'expert_id'=>$experties,
				   		);
						 $this->Supplier_model->save_experties($experties_info);
					}if(is_array($resources) && !empty($resources)){
							$resources_info=array(
							'user_id'=>$session['id'],
							'resources_id'=>$resources,
				   		);
						 $this->Supplier_model->save_resources($resources_info);
					}if(is_array($countries) && !empty($countries)){
							$countries_info=array(
							'user_id'=>$session['id'],
							'countries'=>$countries,
				   		);
						 $this->Supplier_model->save_user_countries($countries_info);
					}

				}	
				echo 'Success';die;	
		}	
	}
	/**************find experties*********************/
	public function find_experties($userId=null){

		$experties = $this->Experts_model->find_experties($userId);
		if(isset($experties)){
			$result = array();
			foreach($experties as $key=>$value){
				$result[] = $value['type'];
			}
		}
		return $result;
		
	}
	/**************find experties*********************/
	public function find_serving_location($userId=null){

		$experties = $this->Experts_model->find_serving_location($userId);
		if(isset($experties)){
			$result = array();
			foreach($experties as $key=>$value){
				$result[] = $value['country_name'];
			}
		}
		return $result;
		
	}
	/***************find resources***************************/
	public function find_resources($userId=null){

		$experties = $this->Experts_model->find_resources($userId);
		if(isset($experties)){
			$result = array();
			foreach($experties as $key=>$value){
				$result[] = $value['type'];
			}
		}
		return $result;
		
	}
	/***************find resources***************************/
	public function find_skills($userId=null){

		$experties = $this->Supplier_model->find_skills($userId);
		if(isset($experties)){
			$result = array();
			foreach($experties as $key=>$value){
				$result[] = $value['title'];
			}
		}
		return $result;
		
	}
	/***************find resources***************************/
	public function find_functional_area($userId=null){

		$experties = $this->Supplier_model->find_functional_area($userId);
		if(isset($experties)){
			$result = array();
			foreach($experties as $key=>$value){
				$result[] = $value['name'];
			}
		}
		return $result;
		
	}
	
	/***************find resources***************************/
	public function find_service_location($userId=null){

		$experties = $this->Supplier_model->find_service_location($userId);
		if(isset($experties)){
			$result = array();
			foreach($experties as $key=>$value){
				$result[] = $value['name'];
			}
		}
		return $result;
		
	}
	/************add/update experties*********************/
	public function add_personal_info(){
		
		if(!$_POST){
			return ERROR;
		}else{
				$session 		=	$this->session->userdata('Users');
				$address  		= 	$this->input->post('address');
				$phone 			=  	$this->input->post('phone');
				$country_id 	=  	$this->input->post('country_id');
				$state_id 		=  	$this->input->post('state_id');
				$city_id 		=  	$this->input->post('city_id');
				$website_link 	=  	$this->input->post('website_link');
				$gender 		=  	$this->input->post('gender');
				$experience 	=  	$this->input->post('experience');
				$language[] 	=  	$this->input->post('language');
				$languages 		=	implode(",",$language[0]);
				//echo $languages;die;
				$users_info=array(
						'id'=>$session['id'],
						'address'=>$address,
						'phone'=>$phone,
						'country_id'=>$country_id,
						'state_id'=>$state_id,
						'city_id'=>$city_id,
						'website_link'=>$website_link,
						'gender'=>$gender,
						'experience'=>$experience,
						'language'=>$languages
				);
				$resultId = $this->Users_model->save_users($users_info);
				if($resultId>0){
					echo 'Success';die;		
				}	
				else{
					echo ERROR;
				}
		 }	
	}
	/******************add skill info***************************************/
	public function add_skill_info(){
		//print_r($_POST);die;
			if(!$_POST){
			return ERROR;
		}else{
				$session 					=	$this->session->userdata('Users');
				$skills  					= 	$this->input->post('skill');
				$functional_resourcesId[] 	=	$this->input->post('functional_resource_id');
				
				$skill_info=array(
						'user_id'=>$session['id'],
						'skill'=>$skills,
				);
				$functional_info=array(
						'user_id'=>$session['id'],
						'functional_resources_id'=>$functional_resourcesId,
				);
				$users_info	=	array(
									'id'=>$session['id'],
									'training_type'=>$this->input->post('training_type'),
									'travel_mode'=>$this->input->post('travel_mode')
								);
				$this->Supplier_model->save_skill($skill_info);
				$this->Supplier_model->save_functional($functional_info);
				$this->Users_model->save_users($users_info);
				echo 'Success';die;		
		 }	
	
	}
	
	/******************add skill info***************************************/
	public function add_work_experience_info(){
		//print_r($_POST);die;
			if(!$_POST){
			return ERROR;
		}else{
				$session 			=	$this->session->userdata('Users');
				$start_year 		= 	$this->input->post('start_date');
				$end_year 			=	$this->input->post('end_date');
				$title 				=	$this->input->post('title');
				$description 		=	$this->input->post('description');
				
				$experience_info=array(
						'user_id'=>$session['id'],
						'title'=>$title,
						'start_date'=>$start_year,
						'end_date'=>$end_year,
						'description'=>$description
				);
				$experience = $this->Supplier_model->save_experience($experience_info);
				if($experience>0){
					echo 'Success';die;
				}else{
					echo ERROR;
				}		
		 }	
	}
/*****************add/certificate**************************************/
public function add_certificate_info($data){
//print_r($_POST);die;
	if(!$_POST){
		return ERROR;
	}else{
			$session 			=	$this->session->userdata('Users');
			$start_year 		= 	$this->input->post('start_date');
			$end_year 			=	$this->input->post('end_date');
			$title 				=	$this->input->post('title');
			$description 		=	$this->input->post('description');
			$type 				=	$this->input->post('type');
			$experience_info=array(
				'user_id'=>$session['id'],
				'title'=>$title,
				'start_date'=>$start_year,
				'end_date'=>$end_year,
				'description'=>$description,
				'type'=>$type
			);
			$experience = $this->Supplier_model->save_certificate($experience_info);
			if($experience>0){
				echo 'Success';die;
			}else{
				echo ERROR;
			}		
	 }
}
/*****************************Add Education/Update************************/
/*****************add/certificate**************************************/
public function add_education_info($data){
	if(!$_POST){
		return ERROR;
	}else{
			$session 		=	$this->session->userdata('Users');
			$title 			= 	$this->input->post('degree');
			$institute 		=	$this->input->post('institute');
			$country_id 	=	$this->input->post('education_country_id');
			$state_id 		=	$this->input->post('education_state_id');
			$city_id 		=	$this->input->post('education_city_id');
			$start_year 	=	$this->input->post('start_year');
			$end_year 		=	$this->input->post('end_year');
			$description	=	$this->input->post('description');
			$qualification_id=	$this->input->post('qualification_id');
			
			$experience_info=array(
				'user_id'=>$session['id'],
				'title'=>$title,
				'start_year'=>$start_year,
				'end_year'=>$end_year,
				'description'=>$description,
				'country_id'=>$country_id,
				'state_id'=>$state_id,
				'city_id'=>$city_id,
				'institute'=>$institute,
				'qualification_id'=>$qualification_id
			);
			$experience = $this->Supplier_model->save_education($experience_info);
			if($experience>0){
				echo 'Success';die;
			}else{
				echo ERROR;
			}		
	 }
}
/****************delete suppliers info********************/
public function delete_info(){
	 
	 	if(!$_POST){
			return ERROR;
		}else{
				
			
			$type 		= 	$this->input->post('type');
			$id 		=	$this->input->post('whereId');
			$delete_info=array(
				'id'=>$id,
				'type'=>$type
			);
	 		$result		=	$this->Supplier_model->delete_experience_info($delete_info);
			if($result==TRUE){
				echo 'Success';
			}else{
				echo ERROR;
			}
	 	}
	 
	}	
/******************advance search via ajax**************************/
	public function suppliers_search(){
		if($_POST){
			//print_r($_POST);die;
			$expert_name	=	$this->input->post('expert_id');
			$type			=	$this->input->post('expert_type');
			
			$search_item = array(
								'skill_id'=>$this->input->post('skills'),
								'firm_type'=>$this->input->post('firm_type'),
								'qualification'=>$this->input->post('qualification'),
								'experience'=>$this->input->post('experience'),
								'language'=>$this->input->post('language'),
								'gender'=>$this->input->post('gender'),
								'country_id'=>$this->input->post('country_id'),
								'state_id'=>$this->input->post('state_id'),
								'city_id'=>$this->input->post('city_id'),
								'training_type'=>$this->input->post('training_type'),
								'rating'=>$this->input->post('rating'),
								'travel_mode'=>$this->input->post('travel_mode'),
								'expert_id'=>$this->input->post('expert_id'),
								'expert_type'=>$this->input->post('expert_type')
								
						);
			if(isset($type) && ($type == 'experts')){
				$data['experts']	= $this->Supplier_model->get_experts_resources('Experts',$expert_name,$search_item);
				$this->partial('experts/experts_element',$data);
			}else if(isset($type) && ($type == 'resources')){
				$data['resources']	= $this->Supplier_model->get_experts_resources('Resources',$expert_name,$search_item);
				$this->partial('resources/resources_element',$data);
			}else{
				$data['suppliers']	= $this->Supplier_model->get_experts_resources('','',$search_item);
				$this->partial('supplier/suppliers_search',$data);
			}
		}
	}	
	
	public function find_users_experties($expertId,$type){
		return $this->Experts_model->find_users_experties_resources($expertId,$type);		
	}
	/***********view profile for supplier****************/
	public function view_profile(){
		
		$session =	$this->session->userdata('Users');
		if(!empty($session)){
			$this->data['CI'] 		=   $this;
			$this->data['supplier'] = 	$this->Users_model->details($session['id']);
			$this->data['session'] 	= $session;
			//echo "<pre>";print_r($this->data);echo "</pre>";
			$this->data['country']	= $this->Common_model->get_AllCountry();
			$this->data['skills'] 	= $this->Common_model->get_skills();
			$this->data['experience']	=	$this->Supplier_model->get_experience_areas($session['id']);
			$this->data['certificate']	=	$this->Supplier_model->get_certificate_areas($session['id']);
			$this->data['education']	=	$this->Supplier_model->get_education_areas($session['id']);
			$this->view('supplier/view_profile',$this->data);
		}else{
			redirect('/');
		}
	}
	
	/******************completed supplier individual registration***********************/
	public function supplier_individual(){
		$session	=	$this->session->userdata('Users');
		if(!$_POST || empty($session)){
			echo ERROR;die;
		}else{
			$session	=	$this->session->userdata('Users');
			$config['upload_path'] 		= dirname($_SERVER["SCRIPT_FILENAME"]).'/public/users/';
			$config['allowed_types'] 	= 'png|jpg|jpeg|gif';
			$this->load->library('upload', $config);
			if (file_exists(DOCUMENT_PATH.$_FILES['picture']['name'])) {
				//delete_files(DOCUMENT_PATH.$_FILES['picture']['name'], TRUE);
				 unlink('./public/users/' . $_FILES['picture']['name']);
			}
			if ( ! $this->upload->do_upload('picture'))
			{
				$picture = $this->input->post('picture');
			}else{
				$data = array('upload_data' => $this->upload->data());
				$picture = $data['upload_data']['file_name'];
			}
			
			$users = array(
						'id'	=>$session['id'],
						'address'=>$this->input->post('address'),
						'country_id'=>$this->input->post('users_country_id'),
						'state_id'=>$this->input->post('users_state_id'),
						'city_id'=>$this->input->post('users_city_id'),
						'phone'=>$this->input->post('phone'),
						'picture'=>$picture
			);
			$details	=	array(
								'user_id'=>$session['id'],
								'job_title'=>$this->input->post('job_title'),
								'pan_number'=>$this->input->post('pan_number'),
								'cin_number'=>$this->input->post('cin_number'),
								'vat_number'=>$this->input->post('vat_number'),
								'service_tax_number'=>$this->input->post('service_tax_number')
							);
			$service_countries[] = 		$this->input->post('serving_country_id');
			if(!empty($details) && !empty($users)){
				$successId	= $this->Users_model->save_user_details($users,$details,$service_countries);
				if($successId>0){
					$data = array(
							'id'=>$session['id'],
							'registration_check'=>0
					);
					$this->Users_model->save_users($data);
					echo 'Success';die;
				}else{
					echo ERROR;die;
				}
			}else {
				echo ERROR;die;
			}
		}
	}	
	
	
	/****************************job details****************************/
	public function job_details($id){
		if($this->input->is_ajax_request()){
     		//Execute Your Code
			$this->data['result'] = $this->Users_model->job_details($id);
			$this->data['users']  = $this->session->userdata('Users');
			//print_r($this->data['users']);
			$this->partial('elements/jobs/job_details',$this->data);	
 		}
	}	
	
	/*****************get skill****************/
	public function get_skill(){
		$skill		=	$_GET['term'];
		$result 	= 	$this->Supplier_model->get_skills($skill,'skills');
		$data		=	array();
		if(isset($result) && !empty($result)){
			foreach($result as $key=>$value){
				$data[$key]['id']		=	$value['id'];
				$data[$key]['title']	=	$value['title'];
			}
			//print_r($data);die;
			echo json_encode($data);die;
		}
	}
	
	/******************update skill********************/
	public function update_skills(){
		$session			=	$this->session->userdata('Users');
		$user_id			=	$session['id'];
		$expert_id			=	$this->input->post('expert_id');
		$experts_info		=	array(
									'user_id' =>$user_id,
									'expert_id' =>$expert_id
								);
		$experts 	=   $this->Supplier_model->update_skills($experts_info);
		if($experts>0){
			echo 'Success';die;
		}else{
			echo ERROR;
		}		
	}
	
	/*******************edit profile*******************/
	public function orgnization_profile(){
		
		$session 				=	$this->session->userdata('Users');
		$this->data['CI'] 		=   $this;	
		$this->data['supplier'] = 	$this->Users_model->details($session['id']);
		$this->data['roles']	=	$this->Experts_model->find_all_experties('Experts');
		$this->data['resources']=	$this->Experts_model->find_all_experties('Resources');
		$this->data['country']	=	$this->Common_model->get_AllCountry();
		$this->data['state']	=	$this->Common_model->get_AllState(isset($this->data['supplier'][0]['country_id']) ? $this->data['supplier'][0]['country_id']:'');
		$this->data['city']		=	$this->Common_model->get_AllCity(isset($this->data['supplier'][0]['state_id']) ? $this->data['supplier'][0]['state_id']:'');
		$this->data['functional']	=	$this->Common_model->get_functional_areas();
		
		$this->data['experience']	=	$this->Supplier_model->get_experience_areas($session['id']);
		$this->data['certificate']	=	$this->Supplier_model->get_certificate_areas($session['id']);
		$this->data['education']	=	$this->Supplier_model->get_education_areas($session['id']);
		$this->data['skills']		=	$this->Supplier_model->find_skills($session['id']);
		$this->data['session'] 		=	$this->session->userdata('Users');
		
		if(empty($this->data['supplier'])){
			redirect('/');
		}
		//echo "<pre>";print_r($this->data['education']);echo "</pre>";
		$this->view('supplier/orgnization_profile',$this->data);
	}
	/*******************orgnization edit profile*******************/
	public function orgnization_update(){
		
		$session 				=	$this->session->userdata('Users');
		$this->data['CI'] 		=   $this;	
		$this->data['supplier'] = 	$this->Users_model->details($session['id']);
		$this->data['roles']	=	$this->Experts_model->find_all_experties('Experts');
		$this->data['resources']=	$this->Experts_model->find_all_experties('Resources');
		$this->data['country']	=	$this->Common_model->get_AllCountry();
		$this->data['state']	=	$this->Common_model->get_AllState(isset($this->data['supplier'][0]['country_id']) ? $this->data['supplier'][0]['country_id']:'');
		$this->data['city']		=	$this->Common_model->get_AllCity(isset($this->data['supplier'][0]['state_id']) ? $this->data['supplier'][0]['state_id']:'');
		$this->data['functional']	=	$this->Common_model->get_functional_areas();
		
		$this->data['experience']	=	$this->Supplier_model->get_experience_areas($session['id']);
		$this->data['certificate']	=	$this->Supplier_model->get_certificate_areas($session['id']);
		$this->data['education']	=	$this->Supplier_model->get_education_areas($session['id']);
		$this->data['skills']		=	$this->Supplier_model->find_skills($session['id']);
		$this->data['session'] 		=	$this->session->userdata('Users');
		
		if(empty($this->data['supplier'])){
			redirect('/');
		}
		//echo "<pre>";print_r($this->data['education']);echo "</pre>";
		$this->view('supplier/orgnization_update',$this->data);
	}
	/********************end****************************/

/*********************************** End of function *********************/	
}

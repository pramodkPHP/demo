<?php
/***********************************
Default Controller for front end home page
Date:09 Jan 2016
Author:Pramod Kumar
************************************/
defined('BASEPATH') OR exit('No direct script access allowed');
class Supplier extends Front_Controller {
	public function __construct(){
		parent::__construct();
		$this->load->model(array('Users_model','Common_model','Experts_model','Supplier_model','Events_model','Resources_model'));	
		$this->load->helper('number');
	}
	
	/******************remember me function ***************************/
	public function profile($id = NULL){
		$userData = $this->Users_model->get_details($id);
		$this->data['profile'] = $userData;
		//print_r($userData);die;
		if($userData['user_type']=='1'){
			$this->view('supplier/profile',$this->data);
		}else{
			redirect('/404');
		}
	}	
	/*********************upload profile using ajax********************/
	public function upload_profile_picture(){
		
		if($_FILES){ 
			//print_r($_FILES);die;
			$userData					= $this->session->userdata('Users');
			$config['upload_path'] 		= dirname($_SERVER["SCRIPT_FILENAME"]).'/public/users/';
			$config['allowed_types'] 	= 'png|jpg|jpeg|gif';
			$this->load->library('upload', $config);
			$new_name = time().$_FILES["file-input"]['name'];
			$config['file_name'] = $new_name;
			if (file_exists(DOCUMENT_PATH.$config['file_name'])) {
				//delete_files(DOCUMENT_PATH.$_FILES['picture']['name'], TRUE);
				 unlink('./public/users/' .$config['file_name']);
			}
			if ( ! $this->upload->do_upload('file-input'))
			{
				$picture = $this->input->post('file-input');
			}else{
				$data 		= array('upload_data' => $this->upload->data());
				$picture 	= $data['upload_data']['file_name'];
			}
			$save=array(
				'id'=>$userData['id'],
				'picture'=>$picture,
				'modified_date'=>date('Y-m-d h:i:s')
			);
			//print_r($save);die;
			$insertId 			= $this->Users_model->save_users($save);
			$image				= base_url('public/users/' . $picture);
			if($insertId>0){
				echo "<img src='".$image."' class='img-responsive img-circle profilr-img'>";
				die;
			}else{
				echo ERROR;die;
			}	
		}	
	}


	/*
		Date - 		31-01-2016
		Code by - 	Deepoo Gupta
		Code For -  Filter suppliers
	*/
	public function advance_search(){
		//print_r($_REQUEST);die; 
		$first_name = '';
		if(isset($_REQUEST['first_name']) && !empty($_REQUEST['first_name'])){
			$first_name	=	$_REQUEST['first_name'];
		}
		$data['CI']=$this;
		$data['heading']='Advance search';
		$data['search']=array(
			'advance-search'=>true,
			'experts'=>true,
			'resources'=>true
		);
		$search		=	array(
								'first_name'=>$first_name
							);
		$data['suppliers']	= $this->Supplier_model->get_experts_resources('','','',$search);
		$data['skills'] 	= $this->Common_model->get_skills();
		$data['country']	= $this->Common_model->get_AllCountry();
		$data['first_name']	= $first_name;
		//$this->data['city']		=	$this->Common_model->get_AllCity(isset($this->data['supplier'][0]['state_id']) ? $this->data['supplier'][0]['state_id']:'');
		//echo "<pre>";print_r($data['suppliers']);echo "</pre>";die;
		$this->view('supplier/suppliers', $data);
	}
	public function expert($value){
		$value		=	urldecode($value);
		$data['CI'] =   $this;
		$heading	=	explode('+',$value);
		$data['heading']=ucwords(implode(' ',$heading));
		$data['search']=array(
			'advance-search'=>true,
			'experts'=>true,
			'resources'=>false
		);
		$data['suppliers']  = $this->Supplier_model->get_experts_resources('Experts',$value);
		$data['skills'] 	= $this->Common_model->get_skills();
		$data['country']	= $this->Common_model->get_AllCountry();
		//$data['count'] 		= $this->Experts_model->find_users_experties($expertId);
		$data['heading']		=	ucwords(urldecode($value));
		$this->view('supplier/suppliers', $data);
	}
	public function resource($type){
		$value			=	urldecode($type);
		$data['CI']		=	$this;
		$heading		=	explode('+',$type);
		$data['heading']=	ucwords(implode(' ',$heading));
		$data['search']=array(
			'advance-search'=>true,
			'experts'=>false,
			'resources'=>true
		);
		$data['suppliers'] 	= $this->Supplier_model->get_experts_resources('Resources',$value);
		$data['skills'] 	= $this->Common_model->get_skills();
		$data['country']	= $this->Common_model->get_AllCountry();
		$data['heading']		= ucwords(urldecode($value));
		$this->view('supplier/suppliers', $data);
	}
	/*************get state from country id************/
	public function get_state(){
			$country_id		=	$this->input->post('whereId');
			$table			=	$this->input->post('table');
			$data 			=   $this->Common_model->get_state($country_id,$table);
			echo $data;die;
	}
	/*************get city from state id************/
	public function get_city($state_id){
			$states_id		=	$this->input->post('whereId');
			$table			=	$this->input->post('modelName');
			$data 			=   $this->Common_model->get_city($states_id,$table);
			echo $data;die;
	}
	
	public function individual($id = NULL){
		
		$data['CI']					=	$this;
		$session 					=	$this->session->userdata('Users');
		$this->data['country']		= 	$this->Common_model->get_AllCountry();
		$this->data['skills'] 		= 	$this->Common_model->get_skills();
		$this->data['questions']	=	$this->Common_model->get_questions();
		$this->data['functional']	=	$this->Common_model->get_functional_areas();
		$this->data['users'] 	= 	$this->Users_model->get_details($session['id']);
		if(isset($session) && !empty($session) && empty($id)){
			$id		 =  $session['id'];
		}
		/*************Save profile view*******************/
		if(isset($session) && $session['user_type']==0 && !empty($id)){ 
			if($this->Users_model->view_check_exists($session['id'],$id) == false){
				$data = array(
								'user_id' =>$session['id'],
								'supplier_id'=>$id
						);
				$this->Users_model->save_profile_view($data);
			}
			
		}
		/*************end**********************/
		$this->data['session'] = $session;
		$this->data['CI'] 		=   $this;
		$this->data['supplier'] = 	$this->Users_model->details($id);
		if(empty($this->data['supplier'])){
			redirect('/');
		}
		$this->data['country']		= 	$this->Common_model->get_AllCountry();
		$this->data['skills'] 		= 	$this->Common_model->get_skills();
		$this->data['experience']	=	$this->Supplier_model->get_experience_areas($id);
		$this->data['certificate']	=	$this->Supplier_model->get_certificate_areas($id);
		$this->data['education']	=	$this->Supplier_model->get_education_areas($id);
		$this->data['video'] 		= 	$this->Supplier_model->get_video($id);
		//print_r($this->data['video']);
		$data['fields'][0]	=  'supplier_id';
		$data['value'][0]	=   $id;
		$this->data['rating'] = $this->Common_model->get_common_result($data,'supplier_feedback');
		
		$this->view('supplier/individual',$this->data);
	}
	/*************recieve call by supplier*****************/
	public function supplier_call(){
	
		$this->partial('supplier/supplier_call');
	}
	/*******************edit profile*******************/
	public function edit_profile(){
		
		$session 				=	$this->session->userdata('Users');
		$this->data['CI'] 		=   $this;	
		$this->data['supplier'] = 	$this->Users_model->details($session['id']);
		$this->data['roles']	=	$this->Experts_model->find_all_experties('Experts');
		$this->data['resources']=	$this->Experts_model->find_all_experties('Resources');
		$this->data['country']	=	$this->Common_model->get_AllCountry();
		$this->data['state']	=	$this->Common_model->get_AllState(isset($this->data['supplier'][0]['country_id']) ? $this->data['supplier'][0]['country_id']:'');
		$this->data['city']		=	$this->Common_model->get_AllCity(isset($this->data['supplier'][0]['state_id']) ? $this->data['supplier'][0]['state_id']:'');
		$this->data['functional']	=	$this->Common_model->get_functional_areas();
		
		$this->data['experience']	=	$this->Supplier_model->get_experience_areas($session['id']);
		$this->data['certificate']	=	$this->Supplier_model->get_certificate_areas($session['id']);
		$this->data['education']	=	$this->Supplier_model->get_education_areas($session['id']);
		$this->data['skills']		=	$this->Supplier_model->find_skills($session['id'],$this->data['supplier'][0]['skills_listing']);
		$this->data['session'] 		=	$this->session->userdata('Users');
		$this->data['video'] 		= 	$this->Supplier_model->get_video($session['id']);
		if(empty($this->data['supplier'])){
			redirect('/');
		}
		$data['fields'][0]	=  'supplier_id';
		$data['value'][0]	=   $session['id'];
		$this->data['rating'] = $this->Common_model->get_common_result($data,'supplier_feedback');
		//echo "<pre>";print_r($this->data['supplier']);echo "</pre>";
		$this->view('supplier/update_profile',$this->data);
	}
	
	public function organization($id = NULL){

		$session =	$this->session->userdata('Users');
		if(isset($session) && !empty($session) && empty($id)){
			$id		 =  $session['id'];
		}
		/*************Save profile view*******************/
		if(isset($session) && $session['user_type']==0 && !empty($id)){ 
			if($this->Users_model->view_check_exists($session['id'],$id) == false){
				$data = array(
								'user_id' =>$session['id'],
								'supplier_id'=>$id
						);
				$this->Users_model->save_profile_view($data);
			}
		}
		/*************end**********************/
		$this->data['session'] 	= 	$session;
		$this->data['CI'] 		=   $this;
		$this->data['supplier'] = 	$this->Users_model->details($id);
		if(empty($this->data['supplier'])){
			redirect('/');
		}
		$data = array();
		$data['fields'][0] 	=	'supplier_id';
		$data['value'][0] 	=	$id;
		//echo "<pre>";print_r($this->data['supplier']);echo "</pre>";
		$this->data['skills']		=	$this->Supplier_model->find_skills($id);
		$this->data['resources']	=	$this->Experts_model->find_all_experties('Resources');
		$this->data['profiles']		=	$this->Common_model->get_common_result($data,'orgnization_profiles');
		//echo "<pre>";print_r($this->data['profiles']);echo "</pre>";
		$this->data['video'] 		= 	$this->Supplier_model->get_video($id);
		//echo "<pre>";print_r($this->data['video']);echo "</pre>";
		$this->view('supplier/organization',$this->data);
		//$this->view('supplier/organization',$this->data);
	}
	
	/************add/update experties*********************/
	public function add_business_info(){
		
		if(!$_POST){
			return ERROR;
		}else{
				$session 		=	$this->session->userdata('Users');
				$about_us  		= 	$this->input->post('about_us');
				$experties[] 	=  	$this->input->post('experties');
				$resources[] 	=  	$this->input->post('resources');
				$countries[] 	=  	$this->input->post('user_country_id');
				$users_info=array(
						'id'=>$session['id'],
						'about_us'=>$about_us,
						'modified_date'=>date('Y-m-d h:i:s')
				   );
				$resultId = $this->Users_model->save_users($users_info);
				if($resultId>0){
					if(is_array($experties) && !empty($experties)){
						$experties_info=array(
							'user_id'=>$session['id'],
							'expert_id'=>$experties,
				   		);
						 $this->Supplier_model->save_experties($experties_info);
					}if(is_array($resources) && !empty($resources)){
							$resources_info=array(
							'user_id'=>$session['id'],
							'resources_id'=>$resources,
				   		);
						 $this->Supplier_model->save_resources($resources_info);
					}if(is_array($countries) && !empty($countries)){
							$countries_info=array(
							'user_id'=>$session['id'],
							'countries'=>$countries,
				   		);
						 $this->Supplier_model->save_user_countries($countries_info);
					}

				}	
				echo 'Success';die;	
		}	
	}
	/**************find experties*********************/
	public function find_experties($userId=null){

		$experties = $this->Experts_model->find_experties($userId);
		if(isset($experties)){
			$result = array();
			foreach($experties as $key=>$value){
				$result[] = $value['type'];
			}
		}
		return $result;
		
	}
	
	/**************find experties*********************/
	public function find_resources($userId=null){

		$experties = $this->Resources_model->find_resources($userId);
		if(isset($experties)){
			$result = array();
			foreach($experties as $key=>$value){
				$result[] = $value['type'];
			}
		}
		return $result;
		
	}
	/**************find experties*********************/
	public function find_serving_location($userId=null){

		$experties = $this->Experts_model->find_serving_location($userId);
		if(isset($experties)){
			$result = array();
			foreach($experties as $key=>$value){
				$result[] = $value['country_name'];
			}
		}
		return $result;
		
	}
	/***************find resources***************************/
	public function find_skills($userId=null){

		$experties = $this->Supplier_model->find_skills($userId);
		if(isset($experties)){
			$result = array();
			foreach($experties as $key=>$value){
				$result[$key]['id'] = $value['id'];
				$result[$key]['title'] = $value['title'];
			}
		}
		//echo "<pre>";print_r($result);echo "</pre>";
		return $result;
		
	}
	/***************find resources***************************/
	public function find_functional_area($userId=null){

		$experties = $this->Supplier_model->find_functional_area($userId);
		if(isset($experties)){
			$result = array();
			foreach($experties as $key=>$value){
				$result[] = $value['name'];
			}
		}
		return $result;
		
	}
	
	/***************find resources***************************/
	public function find_service_location($userId=null){

		$experties = $this->Supplier_model->find_service_location($userId);
		if(isset($experties)){
			$result = array();
			foreach($experties as $key=>$value){
				$result[] = $value['name'];
			}
		}
		return $result;
		
	}
	/************add/update experties*********************/
	public function add_personal_info(){
		
		if(!$_POST){
			return ERROR;
		}else{
				$session 		=	$this->session->userdata('Users');
				$address  		= 	$this->input->post('address');
				$phone 			=  	$this->input->post('phone');
				$country_id 	=  	$this->input->post('country_id');
				$state_id 		=  	$this->input->post('state_id');
				$city_id 		=  	$this->input->post('city_id');
				$website_link 	=  	$this->input->post('website_link');
				$gender 		=  	$this->input->post('gender');
				$experience 	=  	$this->input->post('experience');
				$job_title 		=  	$this->input->post('job_title');
				
				//echo $languages;die;
				$users_info=array(
						'id'=>$session['id'],
						'address'=>$address,
						'phone'=>$phone,
						'country_id'=>$country_id,
						'state_id'=>$state_id,
						'city_id'=>$city_id,
						'website_link'=>$website_link,
						'gender'=>$gender,
						'experience'=>$experience,
						'modified_date'=>date('Y-m-d h:i:s')
				);
				$data	=	array('user_id'=>$session['id'],'job_title'=>$job_title);
				$resultId = $this->Users_model->save_users($users_info);
				$this->Users_model->user_details($data,'user_details');
				if($resultId>0){
					echo 'Success';die;		
				}	
				else{
					echo ERROR;
				}
		 }	
	}
	/******************add skill info***************************************/
	public function add_skill_info(){
		//print_r($_POST);die;
			if(!$_POST){
			echo ERROR;die;
		}else{
				$session 					=	$this->session->userdata('Users');
				$skills  					= 	$this->input->post('skill');
				$functional_resourcesId[] 	=	$this->input->post('functional_resource_id');
				$language[] 				=  	$this->input->post('language');
				$functional_limit			=	$this->input->post('functional_limit');
				$languages					=	'';
				if(isset($language) && count($language)>0){
					$languages 					=	implode(",",$language[0]);
				}
				$skill_info=array(
						'user_id'=>$session['id'],
						'skill'=>$skills,
				);
				$functional_info=array(
						'user_id'=>$session['id'],
						'functional_resources_id'=>$functional_resourcesId,
				);
				$users_info	=	array(
									'id'=>$session['id'],
									'training_type'=>$this->input->post('training_type'),
									'travel_mode'=>$this->input->post('travel_mode'),
									'language'=>$languages,
									'modified_date'=>date('Y-m-d h:i:s')
								);
				
				if(is_array($skill_info) || is_array($functional_info) || is_array($users_info)){
					$existing	=	$this->Supplier_model->save_skill($skill_info);
					$this->Users_model->save_users($users_info);
					if(!empty($existing)){
						echo '"'.$existing.'"'.' SKILLS ALREADY EXIST, Please try unique or add from add skills';die;
					}
					if(!empty($functional_resourcesId) && count($functional_resourcesId[0])>$functional_limit){
						echo FUNCTIONAL_LIMIT_EXCEED."<br><font color='green'>Rest of other successfully added</font>";
						die;
					}else{
						$this->Supplier_model->save_functional($functional_info);
						echo 'Success';die;
					}
					
					
				}
				//print_r($existing);die;
				else{
					
					$this->Users_model->save_users($users_info);
					
				}		
		 }	
	
	}
	
	/****************add skill info in user*******************/
	public function save_user_skills(){
	
		if(!$_POST){
			return ERROR;
		}else{
			$session 			=	$this->session->userdata('Users');
			$skill_id  			= 	$this->input->post('exist_skill_id');
			$skill_info=array(
						'user_id'=>$session['id'],
						'skill_id'=>$skill_id,
			);
			$this->Supplier_model->save_user_skills($skill_info);
			echo 'Success';die;
		}
	}
	
	/******************add skill info***************************************/
	public function add_work_experience_info(){
		//print_r($_POST);die;
		if(!$_POST){
			return ERROR;
		}else{
				$session 			=	$this->session->userdata('Users');
				$designation 		= 	$this->input->post('designation');
				$year 				=	$this->input->post('years');
				$title 				=	$this->input->post('title');
				$description 		=	$this->input->post('description');
				
				$experience_info=array(
						'user_id'=>$session['id'],
						'title'=>$title,
						'designation'=>$designation,
						'years'=>$year,
						'description'=>$description
				);
				$users_info	=	array(
								'id'=>$session['id'],
								'modified_date'=>date('Y-m-d h:i:s')
							);
				$this->Users_model->save_users($users_info);
				$experience = $this->Supplier_model->save_experience($experience_info);
				if($experience>0){
					echo 'Success';die;
				}else{
					echo ERROR;
				}		
		 }	
	}
/*****************add/certificate**************************************/
public function add_certificate_info($data){
//print_r($_POST);die;
	if(!$_POST){
		echo ERROR;die;
	}else{
			$session 			=	$this->session->userdata('Users');
			$start_year 		= 	$this->input->post('start_date');
			$end_year 			=	$this->input->post('end_date');
			$title 				=	$this->input->post('title');
			$description 		=	$this->input->post('description');
			$type 				=	$this->input->post('type');
			$experience_info=array(
				'user_id'=>$session['id'],
				'title'=>$title,
				'start_date'=>$start_year,
				'end_date'=>$end_year,
				'description'=>$description,
				'type'=>$type
			);
			$users_info	=	array(
								'id'=>$session['id'],
								'modified_date'=>date('Y-m-d h:i:s')
							);
			$this->Users_model->save_users($users_info);
			$experience = $this->Supplier_model->save_certificate($experience_info);
			if($experience>0){
				echo 'Success';die;
			}else{
				echo ERROR;
			}		
	 }
}
/*****************add/certificate**************************************/
public function add_org_info(){
//print_r($_POST);die;
	if(!$_POST){
		echo ERROR;die;
	}else{
			$session 			=	$this->session->userdata('Users');
			$title 				= 	$this->input->post('title');
			$description 		=	$this->input->post('description');
			$type 				=	$this->input->post('type');
			$experience_info=array(
				'supplier_id'=>$session['id'],
				'title'=>$title,
				'description'=>$description,
				'type'=>$type
			);
			$experience_info	=	$this->Common_model->save($experience_info,'orgnization_profiles');
			if($experience_info>0){
				echo 'Success';die;
			}else{
				echo ERROR;
			}		
	 }
}
/*****************************Add Education/Update************************/
/*****************add/certificate**************************************/
public function add_education_info($data){
	if(!$_POST){
		return ERROR;
	}else{
			$session 		=	$this->session->userdata('Users');
			$title 			= 	$this->input->post('degree');
			$institute 		=	$this->input->post('institute');
			$country_id 	=	$this->input->post('education_country_id');
			$state_id 		=	$this->input->post('education_state_id');
			$city_id 		=	$this->input->post('education_city_id');
			$start_year 	=	$this->input->post('start_year');
			$end_year 		=	$this->input->post('end_year');
			$description	=	$this->input->post('description');
			$qualification_id=	$this->input->post('qualification_id');
			
			$experience_info=array(
				'user_id'=>$session['id'],
				'title'=>$title,
				'start_year'=>$start_year,
				'end_year'=>$end_year,
				'description'=>$description,
				'country_id'=>$country_id,
				'state_id'=>$state_id,
				'city_id'=>$city_id,
				'institute'=>$institute,
				'qualification_id'=>$qualification_id
			);
			$users_info	=	array(
								'id'=>$session['id'],
								'modified_date'=>date('Y-m-d h:i:s')
			);
			$this->Users_model->save_users($users_info);
			$experience = $this->Supplier_model->save_education($experience_info);
			if($experience>0){
				echo 'Success';die;
			}else{
				echo ERROR;
			}		
	 }
}
/****************delete suppliers info********************/
public function delete_info(){
	 
	 	if(!$_POST){
			return ERROR;
		}else{
			$type 		= 	$this->input->post('type');
			$id 		=	$this->input->post('whereId');
			$delete_info=array(
				'id'=>$id,
				'type'=>$type
			);
	 		$result		=	$this->Supplier_model->delete_experience_info($delete_info);
			if($result==TRUE){
				echo 'Success';
			}else{
				echo ERROR;
			}
	 	}
	 
	}	
/******************advance search via ajax**************************/
	public function suppliers_search(){
		if($_POST){
			//print_r($_POST);die;
			$expert_name	=	$this->input->post('expert_id');
			$type			=	$this->input->post('expert_type');
			
			$search_item = array(
					'skill_id'=>$this->input->post('skills'),
					'firm_type'=>$this->input->post('firm_type'),
					'qualification'=>$this->input->post('qualification'),
					'experience'=>$this->input->post('experience'),
					'language'=>$this->input->post('language'),
					'gender'=>$this->input->post('gender'),
					'country_id'=>$this->input->post('country_id'),
					'state_id'=>$this->input->post('state_id'),
					'city_id'=>$this->input->post('city_id'),
					'training_type'=>$this->input->post('training_type'),
					'rating'=>$this->input->post('rating'),
					'travel_mode'=>$this->input->post('travel_mode'),
					'expert_id'=>$this->input->post('expert_id'),
					'expert_type'=>$this->input->post('expert_type')
			);
			if(isset($type) && ($type == 'experts')){
				$data['experts']	= $this->Supplier_model->get_experts_resources('Experts',$expert_name,$search_item);
				$this->partial('experts/experts_element',$data);
			}else if(isset($type) && ($type == 'resources')){
				$data['resources']	= $this->Supplier_model->get_experts_resources('Resources',$expert_name,$search_item);
				$this->partial('resources/resources_element',$data);
			}else if(isset($type) && ($type == 'events')){
				$cname		=	'';
				$sname		=	'';
				$cityname	=	'';	
				if($search_item['country_id']){
					$country = $this->Common_model->get_data($search_item['country_id'],'countries');
					$cname	 = $country->name;
				}
				if($search_item['state_id']){
					$states = $this->Common_model->get_data($search_item['state_id'],'states');
					$sname	= $states->name;	
				}
				if($search_item['city_id']){
					$cities 	= $this->Common_model->get_data($search_item['city_id'],'cities');
					$cityname	= $cities->name;	
				}
				$search_item	=	array(
										'country_id' => $cname,
										'state_id' =>$sname,
										'city_id'=>$cityname
									);
									
				//print_r($search_item);die;
				$this->data['data']	= $this->Events_model->get_events_filter('Events',$expert_name,$search_item);
				//print_r($data);die;
				$this->partial('events/events_element',$this->data);
			}else{
				$data['suppliers']	= $this->Supplier_model->get_experts_resources('','',$search_item);
				$this->partial('supplier/suppliers_search',$data);
			}
		}
	}	
	
	public function find_users_experties($expertId,$type){
		return $this->Experts_model->find_users_experties_resources($expertId,$type);		
	}
	/***********view profile for supplier****************/
	public function view_profile(){
		
		$session =	$this->session->userdata('Users');
		if(!empty($session)){
			$this->data['CI'] 		=   $this;
			$this->data['supplier'] = 	$this->Users_model->details($session['id']);
			$this->data['session'] 	= $session;
			//echo "<pre>";print_r($this->data);echo "</pre>";
			$this->data['country']	= $this->Common_model->get_AllCountry();
			$this->data['skills'] 	= $this->Common_model->get_skills();
			$this->data['experience']	=	$this->Supplier_model->get_experience_areas($session['id']);
			$this->data['certificate']	=	$this->Supplier_model->get_certificate_areas($session['id']);
			$this->data['education']	=	$this->Supplier_model->get_education_areas($session['id']);
			$this->view('supplier/view_profile',$this->data);
		}else{
			redirect('/');
		}
	}
	
	/******************completed supplier individual registration***********************/
	public function supplier_individual(){
		$session	=	$this->session->userdata('Users');
		if(!$_POST || empty($session)){
			echo ERROR;die;
		}else{
			$session	=	$this->session->userdata('Users');
			$config['upload_path'] 		= dirname($_SERVER["SCRIPT_FILENAME"]).'/public/users/';
			$config['allowed_types'] 	= 'png|jpg|jpeg|gif';
			$this->load->library('upload', $config);
			if (isset($_FILES['picture']['name']) && !empty($_FILES['picture']['name']) && file_exists(DOCUMENT_PATH.$_FILES['picture']['name'])) {
				//delete_files(DOCUMENT_PATH.$_FILES['picture']['name'], TRUE);
				 unlink('./public/users/' . $_FILES['picture']['name']);
			}
			if ( ! $this->upload->do_upload('picture'))
			{
				$picture = $this->input->post('picture');
			}else{
				$data = array('upload_data' => $this->upload->data());
				$picture = $data['upload_data']['file_name'];
			}
			$functional_resourcesId[] 	=	$this->input->post('functional_resource_id');
			$functional_limit			=	$this->input->post('functional_limit');
		
			$users = array(
						'id'	=>$session['id'],
						'address'=>$this->input->post('address'),
						'country_id'=>$this->input->post('users_country_id'),
						'state_id'=>$this->input->post('users_state_id'),
						'city_id'=>$this->input->post('users_city_id'),
						'phone'=>$this->input->post('phone'),
						'picture'=>$picture
			);
			$details	=	array(
								'user_id'=>$session['id'],
								'job_title'=>$this->input->post('job_title'),
								'pan_number'=>$this->input->post('pan_number'),
								'cin_number'=>$this->input->post('cin_number'),
								'vat_number'=>$this->input->post('vat_number'),
								'service_tax_number'=>$this->input->post('service_tax_number')
							);
			$service_countries[] = 		$this->input->post('serving_country_id');
			
			
			$functional_info=array(
					'user_id'=>$session['id'],
					'functional_resources_id'=>$functional_resourcesId,  
			);
			//print_r($functional_info);die;
			if(!empty($details) && !empty($users)){
				$successId	= $this->Users_model->save_user_details($users,$details,$service_countries);
				if($successId>0){
					$data = array(
							'id'=>$session['id'],
							'registration_check'=>0
					);
					$this->Users_model->save_users($data);
					if(!empty($functional_resourcesId) && count($functional_resourcesId[0])>$functional_limit){
						//echo FUNCTIONAL_LIMIT_EXCEED."<br><font color='green'>Rest of other successfully added</font>";
				$str = "In 'Functional Area' You need to choose maximum ".$functional_limit." category that you can upgrade later after confirmation from 'Edit Profile' Section.";
				$str .= "<br>Please refresh this page to go to your dashboard and click on 'Your Profile' to add/update";
				echo $str;die;
				}else{
					$this->Supplier_model->save_functional($functional_info);
				}
				echo 'Success';die;
				}else{
					echo ERROR;die;
				}
			}else {
				echo ERROR;die;
			}
		}
	}	
	
	
	/****************************job details****************************/
	public function job_details($id){
		if($this->input->is_ajax_request()){
     		//Execute Your Code
			$this->data['result'] = $this->Users_model->job_details($id);
			$this->data['users']  = $this->session->userdata('Users');
			//print_r($this->data['users']);
			$this->partial('elements/jobs/job_details',$this->data);	
 		}
	}	
	
	/*****************get skill****************/
	public function get_skill(){
		$skill		=	$_GET['term'];
		$result 	= 	$this->Supplier_model->get_skills($skill,'skills');
		$data		=	array();
		if(isset($result) && !empty($result)){
			foreach($result as $key=>$value){
				$data[$key]['id']		=	$value['id'];
				$data[$key]['value']	=	$value['title'];
			}
			//print_r($data);die;
			echo json_encode($data);die;
		}
	}
	
	/******************update skill********************/
	public function update_skills(){
		$session			=	$this->session->userdata('Users');
		$user_id			=	$session['id'];
		$expert_id			=	$this->input->post('expert_id');
		$experts_info		=	array(
									'user_id' =>$user_id,
									'expert_id' =>$expert_id
								);
		$experts 	=   $this->Supplier_model->update_skills($experts_info);
		if($experts>0){
			echo 'Success';die;
		}else{
			echo ERROR;
		}		
	}
	
	/*******************edit profile*******************/
	public function orgnization_profile(){
		
		$session 				=	$this->session->userdata('Users');
		$this->data['CI'] 		=   $this;	
		$this->data['supplier'] = 	$this->Users_model->details($session['id']);
		$this->data['roles']	=	$this->Experts_model->find_all_experties('Experts');
		$this->data['resources']=	$this->Experts_model->find_all_experties('Resources');
		$this->data['country']	=	$this->Common_model->get_AllCountry();
		$this->data['state']	=	$this->Common_model->get_AllState(isset($this->data['supplier'][0]['country_id']) ? $this->data['supplier'][0]['country_id']:'');
		$this->data['city']		=	$this->Common_model->get_AllCity(isset($this->data['supplier'][0]['state_id']) ? $this->data['supplier'][0]['state_id']:'');
		$this->data['functional']	=	$this->Common_model->get_functional_areas();
		
		$this->data['experience']	=	$this->Supplier_model->get_experience_areas($session['id']);
		$this->data['certificate']	=	$this->Supplier_model->get_certificate_areas($session['id']);
		$this->data['education']	=	$this->Supplier_model->get_education_areas($session['id']);
		$this->data['skills']		=	$this->Supplier_model->find_skills($session['id']);
		$this->data['session'] 		=	$this->session->userdata('Users');
		
		if(empty($this->data['supplier'])){
			redirect('/');
		}
		//echo "<pre>";print_r($this->data['resources']);echo "</pre>";
		$this->view('supplier/orgnization_profile',$this->data);
	}
	
	
	/*******************orgnization edit profile*******************/
	public function orgnization_update(){
		
		$session 					=	$this->session->userdata('Users');
		$this->data['CI'] 			=   $this;	
		$data = array();
		$data['fields'][0] 			=	'supplier_id';
		$data['value'][0] 			=	$session['id'];
		$this->data['supplier'] 	= 	$this->Users_model->details($session['id']);
		$this->data['roles']		=	$this->Experts_model->find_all_experties('Experts');
		$this->data['resources']	=	$this->Experts_model->find_all_experties('Resources');
		$this->data['country']		=	$this->Common_model->get_AllCountry();
		$this->data['state']		=	$this->Common_model->get_AllState(isset($this->data['supplier'][0]['country_id']) ? $this->data['supplier'][0]['country_id']:'');
		$this->data['city']			=	$this->Common_model->get_AllCity(isset($this->data['supplier'][0]['state_id']) ? $this->data['supplier'][0]['state_id']:'');
		$this->data['functional']	=	$this->Common_model->get_functional_areas();
		$this->data['profiles']		=	$this->Common_model->get_common_result($data,'orgnization_profiles');
		/*$this->data['experience']	=	$this->Supplier_model->get_experience_areas($session['id']);
		$this->data['certificate']	=	$this->Supplier_model->get_certificate_areas($session['id']);
		$this->data['education']	=	$this->Supplier_model->get_education_areas($session['id']);*/
		$this->data['skills']		=	$this->Supplier_model->find_skills($session['id']);
		$this->data['session'] 		=	$this->session->userdata('Users');
		$this->data['video'] 		= 	$this->Supplier_model->get_video($session['id']);
		if(empty($this->data['supplier'])){
			redirect('/');
		}
		//echo "<pre>";print_r($this->data['education']);echo "</pre>";
		$this->view('supplier/orgnization_update',$this->data);
	}
	
	public function add_orgnization_services(){
		
		if(!$_POST){
			echo ERROR;die;
		}
		else{
				$message	=	'';
				$expert_resourcesId 	=	$this->input->post('expert_resources_id');
				if(empty($expert_resourcesId)){
					$message .= "Please select any one supplier services<br>";
				}
				$session 				=	$this->session->userdata('Users');
				$service_description 	=  	$this->input->post('service_description');
				$equipment_service 		=  	$this->input->post('equipment_service');
				$orgnization_services_id= 	$this->input->post('expert_resources_id');
				$title[] 				=  	$this->input->post('title');
				$url[] 					=  	$this->input->post('url');
				//echo count($title[0]);
				//echo "<pre>";print_r($title);echo "</pre>";
				//echo count($title[0]);
				//die;
				
				if(is_array($title) && count($title[0]) == 0){ 
					$message	.= 'Title Field is required along field!<br>';
				}else if(isset($_FILES['picture']['name']) && count($_FILES['picture']['name']) == 0){
					$message 	.=	'Please upload image along Field<br>';
				}else if(count($url[0]) == 0){
					$message	.=	'URL Field is required along field<br>';
				}
				if(!empty($message)){
					echo $message;die;
				}
				
				if(count($title[0])>0){
					$url[] 					=  	$this->input->post('url');
					$files[] 				=	isset($_FILES['picture']) ? ($_FILES['picture']):'';

					for($count = 0;$count<count($title);$count++){
						if(isset($title[0][$count]) && empty($title[0][$count])){
							echo "Title Fields is required";die;
						}if(isset($files[0]['name'][$count]) && empty($files[0]['name'][$count])){
							echo "Please select File to upload";die;
						}if(isset($url[0][$count]) && empty($url[0][$count])){
							echo "URL Fields is required";die;
						}
					}
				}
				$orgnization_services_primary = array(
						'supplier_id'=>$session['id'],
						'orgnization_services_id' =>$orgnization_services_id,
						'service_description'=>$service_description,
						'equipment_service'=>$equipment_service
				);
				//print_r($orgnization_services_primary);die;
				$resultId = $this->Common_model->save_org($orgnization_services_primary,'orgnization_services');
				if($resultId>0){
						$path 					= 	dirname($_SERVER["SCRIPT_FILENAME"]).'/public/uploads/';
						$expert_resources_id  	= 	$this->input->post('expert_resources_id');
						$title[] 				=  	$this->input->post('title');
						$url[] 					=  	$this->input->post('url');
						$files[] 				=	$_FILES['picture'];
					
						if (!empty($_FILES['picture']['name'][0])) {
							if ($this->upload_files($path,$_FILES['picture']) === FALSE) {
								$data['error'] = $this->upload->display_errors('<div class="alert alert-danger">', '</div>');
							}
						}                  
						$secondary	=	array(
											'orgnization_services_id'=>$resultId,
											'title'=>$title,
											'file'=>$files,
											'url'=>$url
									);
					   $resultId = $this->Supplier_model->save_orgnization_services($secondary,'orgnization_services');
				}else{
					echo ERROR;
				}
				
				
				echo 'Success';die;		
		 }	
		
	}
	
	
	 private function upload_files($path,$files)
    {
        $config = array(
            'upload_path'   => $path,
            'allowed_types' => 'jpg|gif|png',
            'overwrite'     => 1,                       
        );
		$title		=	'org';
        $this->load->library('upload', $config);

        $images = array();
		//print_r($files);
        foreach ($files['name'] as $key => $image) {
            $_FILES['images[]']['name']= $files['name'][$key];
            $_FILES['images[]']['type']= $files['type'][$key];
            $_FILES['images[]']['tmp_name']= $files['tmp_name'][$key];
            $_FILES['images[]']['error']= $files['error'][$key];
            $_FILES['images[]']['size']= $files['size'][$key];

            $fileName = $title .'_'. $image;

            $images[] = $fileName;

            $config['file_name'] = $fileName;

            $this->upload->initialize($config);

            if ($this->upload->do_upload('images[]')) {
                $this->upload->data();
				//$data = array('upload_data' => $this->upload->data());
				//$picture = $data['upload_data']['file_name'];
				//return $picture;
            } else {
                return false;
            }
        }
        return $images;
    }

	/***********************get services images**************/
	public function get_services_detail($services_id,$id=null){
		$session 				=	$this->session->userdata('Users');
		if(isset($session) && !empty($session)){
			$id		 =  $session['id'];
		}
		$data = array(
					'supplier_id'=>$id,
					'orgnization_services_id'=>$services_id
				);
		$result  = $this->Supplier_model->get_info($data); 
		//echo "<pre>";print_r($result);echo "<pre>";die;
		return $result;
		
	}
	
	/******************website link************************/
	public function get_expert_group($url){
		$session 				=	$this->session->userdata('Users');
		$expert_group			=	$this->Supplier_model->get_expert_group($url,$session['id']);
		return $expert_group;
	}
	
	/*************************************supplier feedback request*****************/
	/**********************send inquery form*********************/
	public function send_feedback_request(){
		
		if(!$_POST){
			echo ERROR;
		}else{
				$session 			= $this->session->userdata('Users');
				$cname 				= $this->input->post('cname');
				$email 				= $this->input->post('cemail');
				$service_title 		= $this->input->post('service_title');
				$cmonth 			= $this->input->post('cmonth');
				$cyear 				= $this->input->post('cyear');
				$message 			= $this->input->post('message');
				$data['fields'][0]	= 'email';
				$data['value'][0]	= $email;
				$data['fields'][1]	= 'status';
				$data['value'][1]	= 0;
				$data['fields'][2]	= 'supplier_id';
				$data['value'][2]	= $session['id'];
											
				/*($check				= $this->Common_model->get_common_result($data,'user_feedback_request');
				if(!empty($check)){
					echo EMAIL_EXIST;die;
				}*/
				//print_r($startDate);die;
				$save=array(
					'supplier_id'=>$session['id'],
					'cname'=>$cname,
					'email'=>$email,
					'service_title'=>$service_title,
					'month'=>$cmonth,
					'year'=>$cyear,
					'message'=>$message
				);
				//print_r($save);die;
				$insertId = $this->Supplier_model->feedback_request($save);
				if($insertId>0){			
					$this->send_feedback($session['email'],$insertId);	
					echo 'Success';die;
				}else{
					echo ERROR;die;
				}	
		}
	}
	
	/************send mail***********************/
	function send_feedback($email,$insertId){
		
		$result = $this->Common_model->get_data($insertId,'user_feedback_request');
		//echo "<pre>";print_r($result);"</pre>";die;
		$this->load->library('email');
		$config['protocol']     = 'mail';
		$config['mailpath']     = "/usr/bin/sendmail"; 
		$config['smtp_host']    = 'localhost';
		$config['smtp_port']    = '465';
		$config['smtp_timeout'] = '7';
		$config['smtp_user']    = SMTP_USER;
		$config['smtp_pass']    = SMTP_PASSWORD;
		$config['charset']    	= 'utf-8';
		$config['newline']    	= "\r\n";
		$config['mailtype'] 	= 'html'; // or html
		$config['validation'] = TRUE; // bool whether to validate email or not      
		$this->email->initialize($config);
		$this->email->from('donotreply@infutive.com',SITE_NAME);
		$this->email->to(ADMIN_EMAIL);
		//$this->email->cc($admin['email']);
		$this->email->subject('Feedback Request');
		$message = "Feedback request from ".SITE_NAME."! <br><br> Details are following below: <br> Supplier Email: ".$email;
		$message .= '<br>'."Company/Organization: ".$result->cname.'<br>';
		$message .= " Request Email: ".$result->email."<br>";
		$message .= " Service Title: ".$result->service_title.'<br>';
		$message .= " Training date: ".$result->month."-".$result->year.'<br>';
		$message .= " Description: ".$result->message.'<br>';
		$message .= " Please create account with requested email for not registered user:".'<br>';
		$message .= "<br />Thanks for joining ".SITE_NAME."!<br /><br />Sincerely,<br />".SITE_NAME;
		$this->email->message($message);
		//$this->email->clear();
		if($this->email->send()){
			return true;
			//echo $this->email->print_debugger();
		}else{
			//echo $this->email->print_debugger();
		}
		
	}
	
	
	
	public function add_video_info(){
		
		if(!$_POST){
			echo ERROR;die;
		}
		else{
				
				$session 				=	$this->session->userdata('Users');
				$url[] 					=  	$this->input->post('url');
				if(isset($url[0]) && count($url[0]) == 0){
					$this->data['error']	=	'URL Field is required along field<br>';
					echo $this->data['error'];die;
				}
				if(count($url[0])>0){
					$data	=	array(
							'supplier_id'=>$session['id'],
							'url'=>$url
					);
					$resultId = $this->Supplier_model->save_video($data);
					echo 'Success';die;		
				}
			}	

	}	
	
	
	/*****************get skill****************/
	public function get_supplier(){
		$name		=	$_GET['term'];
		$result 	= 	$this->Supplier_model->get_suppliers($name,'users');
		$data		=	array();
		if(isset($result) && !empty($result)){
			foreach($result as $key=>$value){
				$data[$key]['id']		=	$value['id'];
				$data[$key]['value']	=	$value['first_name'];
			}
			//print_r($data);die;
			echo json_encode($data);die;
		}
	}
	
	public function pricing_plan($type,$current=null){
	
		$data			=	array();
		$data['session']=	$this->session->userdata('Users');
		$data['result']	=	$this->Supplier_model->admin_get_pricing_plan($type);
		$data['current']=	$current;
		if (PAYMENT_MODE == 'TEST') {
			$data['actionUrl']	=	PAYMENT_TEST_MODE_URL;
		} else {
			$data['actionUrl']	= 	PAYMENT_LIVE_MODE_URL;
		}
		//print_r($data);
		$this->partial('supplier/pricing_plan',$data);
	}
    public function cancel() {
        
      
        
    }
	
	public function update_rate(){
		
		$session 				=	$this->session->userdata('Users');
		if($this->input->is_ajax_request() && !empty($_POST)){
			$rate 					=  	$this->input->post('call_rate');
			$mobile 				=  	$this->input->post('mobile');
			if(isset($session['id']) && $rate>0){
				$data	=	array(
						'id'=>$session['id'],
						'call_rate'=>$rate,
						'mobile'=>$mobile
				);
				$resultId = $this->Common_model->save($data,'users');
				echo 'Success';die;		
			}else{
				echo "Call rate should be minimum $1";die;
			}
		}
		$data['result'] 						= 	$this->Common_model->get_data($session['id'],'users');
		$this->partial('supplier/update_rate',$data);		
	}	
	
	public function add_mobile(){
		
		$session 			=	$this->session->userdata('Users');
		if($this->input->is_ajax_request() && !empty($_POST)){
			$mobile 		=  	$this->input->post('mobile');
			if(isset($session['id']) && !empty($mobile)){
				$data	=	array(
						'id'=>$session['id'],
						'mobile'=>$mobile
				);
				$resultId = $this->Common_model->save($data,'users');
				echo 'Success';die;		
			}else{
				echo "Mobile number can not be blank";die;
			}
		}
		$this->partial('supplier/add_mobile');		
	}	

	
	public function call(){
		$session 				=	$this->session->userdata('Users');
		$result['session']		=	$session;
		/*if($this->input->is_ajax_request()){
			
		}*/
		$this->partial('supplier/call',$result);		
	
	}
	
	
	/************send mail***********************/
	function job_request(){
		$job_id 					=  	$this->input->post('job_id');
		$result	= $this->Users_model->job_details($job_id);
		//echo "<pre>";print_r($result);"</pre>";die;
		$this->load->library('email');
		$config['protocol']     = 'mail';
		$config['mailpath']     = "/usr/bin/sendmail"; 
		$config['smtp_host']    = 'localhost';
		$config['smtp_port']    = '465';
		$config['smtp_timeout'] = '7';
		$config['smtp_user']    = SMTP_USER;
		$config['smtp_pass']    = SMTP_PASSWORD;
		$config['charset']    	= 'utf-8';
		$config['newline']    	= "\r\n";
		$config['mailtype'] 	= 'html'; // or html
		$config['validation'] = TRUE; // bool whether to validate email or not      
		$this->email->initialize($config);
		$this->email->from('donotreply@infutive.com',SITE_NAME);
		$this->email->to(ADMIN_EMAIL);
		//$this->email->cc($admin['email']);
		$session 				=	$this->session->userdata('Users');
		$this->email->subject('Supplier Applied on Job Request');
		$message = "Following details are listed below from ".SITE_NAME."! <br><br>";
		$message .= " Supplier Email: ".$session['email']."<br>";
		$message .= " User Job Request Email: ".$result[0]['email']."<br>";
		$message .= " Reqirement Title: ".$result[0]['title'].'<br>';
		$message .= " Required Start date: ".$result[0]['job_start_date'].'<br>';
		$message .= " Required End date: ".$result[0]['job_end_date'].'<br>';
		$message .= " Description: ".$result[0]['description'].'<br>';
		$message .= "<br /> ".SITE_NAME."!<br /><br />Sincerely,<br />".SITE_NAME;
		$this->email->message($message);
		//$this->email->clear();
		if($this->email->send()){
			return true;
			//echo $this->email->print_debugger();
		}else{
			//echo $this->email->print_debugger();
		}
		
	}
	
	/***********twilio call api******************/
	public function twilio_call(){
		
		$version = "2010-04-01";
		// Set our Account SID and AuthToken
		$sid 	= 'ACd628e9947394f6b5d6ca26fad6e34e4f';//'ACa447934cced843df3c200fcb58e804ed';
		$token 	= '7fd0327f7ea3c90524d96b35b072eed2';//'1857a5e125311657314b85093f037245';
		// A phone number you have previously validated with Twilio
		$phonenumber = '+919811411434';
		// Instantiate a new Twilio Rest Client
		$client = new Services_Twilio($sid, $token, $version);
		try {
			// Initiate a new outbound call
			$call = $client->account->calls->create(
				$phonenumber, // The number of the phone initiating the call
				'+919953183364', // The number of the phone receiving call
				'http://demo.twilio.com/welcome/voice/' // The URL Twilio will request when the call is answered
			);
			echo 'Started call: ' . $call->sid;
		} catch (Exception $e) {
			echo 'Error: ' . $e->getMessage();
		}
	
	}
/********************end****************************/

/*********************************** End of function *********************/	
}

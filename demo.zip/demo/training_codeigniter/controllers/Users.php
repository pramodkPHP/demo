<?php
/***********************************
Default Controller for front end home page
Date:09 Jan 2016
Author:Pramod Kumar
************************************/
defined('BASEPATH') OR exit('No direct script access allowed');
class Users extends Front_Controller {
	public function __construct(){
		parent::__construct();
		$this->load->library('pagination');
		$this->load->model(array('Users_model','Common_model','Supplier_model', 'Events_model'));
		 $this->load->driver('cache');	
	}
	private function check_member_session(){
		@$session_data=$this->session->userdata('Users');
		if($session_data['user_id']!="")
		{
			redirect('users/dashboard');
		}
	}
	
	public function register()
	{			
		if(!$_POST) {
			$error = "Please provide input";
			return $error;die;
		} else {
			//print_r($_FILES); die;	
			$this->load->library('form_validation');
			$this->form_validation->set_error_delimiters('', '<br>' );
			$this->form_validation->set_rules('name', '<strong>Name</strong>', 'trim|required|xss_clean');
			$this->form_validation->set_rules('email', '<strong>Email</strong>', 'trim|required|valid_email|xss_clean');
			$this->form_validation->set_rules('password', '<strong>Location</strong>', 'trim|required|min_length[6]|matches[confirm_password]');
			$this->form_validation->set_rules('confirm_password', '<strong>Role</strong>', 'trim|required|xss_clean');
			//print_r(validation_errors()); die;	
			//$this->form_validation->set_rules('file', '<strong>Xls File/CSV</strong>', 'trim|required');
			if($this->form_validation->run() == FALSE){
				$error = $this->data['error']=validation_errors();
				echo $error;die;
				//$this->view('events/add_event',$this->data['error']);
			} 
			else { 
				  /***************upload xls file*********************/
					$name 			= $this->input->post('name');
					$email 			= $this->input->post('email');
					$password 		= $this->input->post('password');
					$user_type 		= $this->input->post('user_type');
					$firm_type 		= $this->input->post('firm_type');
					$both			=	0;
					$activationId	= time();
					if($this->Users_model->check_member_details($email,'') != false){
						echo EMAIL_EXIST;die;
					}
					if (strpos($name, ' ') !== false) {
						$nameArr = explode(" ", $name);
						$first_name = $nameArr[0];
						$last_name = $nameArr[1];
					}else{
						$first_name = $name;
						$last_name  = '';
					}
					if($user_type==2){
						$user_type	=	1;
						$both		=	1;
					}
					$save=array(
						'first_name'=>$first_name,
						'last_name'=>$last_name,
						'email'=>$email,
						'password'=>md5($this->input->post('password')),
						'user_type'=>$user_type,
						'activation_id'=>$activationId,
						'firm_type'=>$firm_type,
						'both'=>$both
				   );
					$insertId = $this->Users_model->save_users($save);
					if($insertId>0){
						/*****************End********************************/	
						$this->send_email($insertId);				
						echo 'Success';die;
						//redirect('events/add_event','refresh');
					}else{
						echo ERROR;die;
					}	
				}			
				/******************End upload xls file*****************/						
		   }					  
	  }
	  /******************remember me function ***************************/
	  private function verify_user($id,$email,$password,$remember){ 
	  		$userData = $this->Users_model->get_details($id);
			$this->session->set_userdata('Users', $userData);
			if($remember==1){ 
				$this->load->helper('cookie');
				$cookie = array('name'=>'uid','value'  => $id,'expire' => '1209600');
				set_cookie($cookie);
				$cookie2 = array('name'=> 'pass_cookie','value'  => $password,'expire' => '1209600');
				set_cookie($cookie2);
				return TRUE;
			}else{
					$this->load->helper('cookie');
					delete_cookie("email_cookie");
					delete_cookie("pass_cookie");	
			}
			return TRUE;
		}	
	
 /*********************************Login function**************************************/
	public function login()
	{						
		$this->check_member_session();
		$this->load->library(array('form_validation'));
		$this->form_validation->set_error_delimiters('<span style="color:#FF0000;">', '</span><br>');
		if(!$_POST){ 
			$error = "Please provide input";
			echo $error;die;
		}else{
			/*************forgot password*****************/
			$check = $this->input->post('check');
			if(isset($check) && $check == 1)
			{
				$this->form_validation->set_rules('email','Email','required|valid_email');
				if($this->form_validation->run()==false){ 
					$this->data['error']="<span style='color:#FF0000;' >Please provide required email field</span>";
					echo $this->data['error'];die;
				}else{
					$email_checkpoint=$this->Users_model->check_member_details($this->input->post('email'));
					if($email_checkpoint){
						$password	=	 base64_encode(time());
						$save=array(
							'id'		=>$email_checkpoint['id'],
							'password'=>md5($password),
				   		);
						$updateDB = $this->Users_model->save_users($save);
						if($updateDB>0){
							/*****************End********************************/	
							
							$this->send_password_email($updateDB,$password);				
							echo 'Success';die;
							//redirect('events/add_event','refresh');
						}else{
							echo ERROR;die;
						}	
					}else{
					 	$this->data['error']="<span style='color:#FF0000;' >Email does not exist in database, Please contact customer care support</span>";
						echo $this->data['error'];die;
					}
				}
			
			}
			$email = $this->input->post('email');
			$password = $this->input->post('password');
			$remember = $this->input->post('rememberme');
			$this->form_validation->set_rules('email','Email','required|valid_email');
			$this->form_validation->set_rules('password','Password','trim|required|min_length[6]');
			///validation check
			if($this->form_validation->run()==false){ 
				$this->data['error']="<span style='color:#FF0000;' >Invalid email or password. Please try again!</span>";
				echo $this->data['error'];die;
			}else{ 
				$email_checkpoint=$this->Users_model->check_member_details($email,$password);
				if($email_checkpoint){ 
					//print_r($email_checkpoint);die;
					if($email_checkpoint['status']==0)
					{
						// verify user
						$cookie_name = "uid";
						$cookie_value = $email_checkpoint['id'];
						setcookie($cookie_name, $cookie_value, time() + (86400 * 30), "/");
						setcookie('firstname', $email_checkpoint['first_name'], time() + (86400 * 30), "/");
						if($this->verify_user($email_checkpoint['id'],$email_checkpoint['email'],$password,$remember)){
							echo 'Success';die; 
						}
					}
					else{
				  		$this->data['error'] = "This User is Blocked! Please Contact our Support system.";
						echo $this->data['error'];die;
					}
				}else{
					$this->data['error']="<span style='color:#FF0000;' >Invalid email or password. Please try again!</span>";
					echo $this->data['error'];die;		
				}
			 }
		   }	
	  }
	  
	  /**********************User dashboard**********************************/
	  public function dashboard($module = null, $pages = NULL){ 
	  	
	  	$session_data	=	$this->session->userdata('Users');
		$data['CI']		=	$this;
		//print_r($session_data);
		$this->data['country']	= $this->Common_model->get_AllCountry();
		$config['base_url'] 	= base_url().'/users/dashboard';
		/**************paging*****************************/
		$econfig['per_page']		= LIMIT_PER_PAGE; 
		// Use pagination number for anchor URL.
		$econfig['use_page_numbers'] = TRUE;
		//Set that how many number of pages you want to view.
		$config['num_links'] = 5;;
		// Open tag for CURRENT link.
		$econfig['cur_tag_open'] = '&nbsp;<a class="current">';
		// Close tag for CURRENT link.
		$econfig['cur_tag_close'] = '</a>';
		// By clicking on performing NEXT pagination.
		$econfig['next_link'] = ' Next ';
		// By clicking on performing PREVIOUS pagination.
		$econfig['prev_link'] = ' Previous ';
		$this->pagination->initialize($econfig);
		$event_page = 1;
		$job_page	= 1;
		if($modules = 'events'){ 
			if($pages){
				$event_page = $pages ;
			}
		}else{
			if($pages){
				$job_page = $pages ;
			}
		}
		//print_r($session_data);
		/*********************************************************/
		if(isset($session_data) && ($session_data['user_type'] !='0')){ 
			
			$this->data['supplier'] = $this->Users_model->get_details($session_data['id']);
			$config['base_url'] 	= base_url().'/users/dashboard';
  			$config['per_page']		= LIMIT_PER_PAGE; 
			$this->data['skills'] 	= $this->Supplier_model->find_skills($session_data['id']);
			$this->data['current_user']	=	 $session_data;
			$config['total_rows'] 	= count($this->Users_model->get_new_jobs('','',$this->data['skills']));
			$this->data['new_work'] = $this->Users_model->get_new_jobs('',$config,$this->data['skills'],$job_page); //print_r($user); die;
			
			$this->pagination->initialize($config); 
			$this->data["job_paging"] = $this->pagination->create_links();
			/*************events paging***************/
			//echo $page;die;
			$econfig['base_url'] 		= base_url().'/users/dashboard/events';
			$econfig['total_rows'] 		= count($this->Events_model->get_supplier_events($session_data['id'],'',''));
			$this->data['events'] 		= $this->Events_model->get_supplier_events($session_data['id'],$econfig,$event_page); //print_r($user); die;
			$this->pagination->initialize($econfig); 
			$this->data["events_paging"] = $this->pagination->create_links();
			
			/**************profile view listing*******************/
			$this->data['view'] = $this->Users_model->get_profile_view($session_data['id']);
			$data['fields'][0]	=  'supplier_id';
			$data['value'][0]	=   $session_data['id'];
			$this->data['rating'] = $this->Common_model->get_common_result($data,'supplier_feedback');
			$this->data['video'] 	= $this->Supplier_model->get_video($session_data['id']);
			$this->data['functional']	=	$this->Common_model->get_functional_areas();
			//echo "<pre>";print_r($this->data['supplier']);echo "</pre>";
			$this->view('supplier/dashboard',$this->data);
		}else if($session_data['user_type']=='0'){
			$this->data['skills'] 	= $this->Common_model->get_skills(); 
			$this->data['current_user']	=	 $session_data;
			$this->data['supplier'] = $this->Users_model->get_details($session_data['id']); //print_r($user); die;
			$this->data['user'] 	= $this->Users_model->get_details($session_data['id']); //print_r($user); die;
			
  			$config['total_rows'] 	= count($this->Users_model->get_new_jobs($session_data['id'],'','',''));
  			$config['per_page']		= LIMIT_PER_PAGE;; 
			
			$this->data['new_work'] = $this->Users_model->get_new_jobs($session_data['id'],$config,'',$job_page); //print_r($user); die;
			$this->pagination->initialize($config); 
			$this->data["job_paging"] = $this->pagination->create_links();
			
			$econfig['base_url'] 		= base_url().'/users/dashboard/events';
			$econfig['total_rows'] 	= count($this->Events_model->get_supplier_events());
			$this->data['events'] 	= $this->Events_model->get_supplier_events('',$econfig,$event_page); //print_r($user); die;
			$this->pagination->initialize($econfig); 
			$this->data["events_paging"] = $this->pagination->create_links();
			
			/************feedback request**************************/
			$data['fields'][0]	= 'email';
			$data['value'][0]	= $session_data['email'];
			$data['fields'][1]	= 'status';
			$data['value'][1]	= 0;
			$this->data['feedback_request'] 	= $this->Common_model->get_common_result($data,'user_feedback_request'); 
			$this->session->set_userdata('feedback_request', $this->data['feedback_request']);
			$this->data['functional']	=	$this->Common_model->get_functional_areas();
			//echo "<pre>";print_r($this->data['supplier']);echo "</pre>";
			$this->view('users/dashboard',$this->data);
		}else{
				redirect('/','refresh');
		}
	  	
	  }
	  
	  /************send mail***********************/
	  function send_email($userId){
	  		//echo $userId;die;	
			//$admin = $this->admin_model->getinfo(); 
			$user = $this->Users_model->get_details($userId);
			//print_r($user);die;
			$this->load->library('email');
            $config['protocol']     = 'mail';
			$config['mailpath']     = "/usr/bin/sendmail"; 
            $config['smtp_host']    = 'localhost';
            $config['smtp_port']    = '465';
            $config['smtp_timeout'] = '7';
            $config['smtp_user']    = SMTP_USER;
            $config['smtp_pass']    = SMTP_PASSWORD;
            $config['charset']    	= 'utf-8';
            $config['newline']    	= "\r\n";
            $config['mailtype'] 	= 'html'; // or html
            $config['validation'] = TRUE; // bool whether to validate email or not      
            $this->email->initialize($config);
			$this->email->from(From_EMAIL,SITE_NAME);
			$this->email->to($user['email']);
			//$this->email->cc($admin['email']);
			$this->email->subject('Verify Your Email Address.');
			$message = "Welcome to ".SITE_NAME."! \n \n To complete your registration process, click on the link below or copy and paste this link on your browser.
			\n \n".base_url('users/confirm')."/".$user['id']."/".$user['activation_id']."
			<br /><br>Thanks<br>".SITE_NAME;
			$this->email->message($message);
			//$this->email->clear();
			if($this->email->send()){
				return true;
				//echo $this->email->print_debugger();
			}else{
				echo $this->email->print_debugger();
			}
			
		}
	  /*****************end mail *******************/
	  /****************verification of user by email click link******************/
	  	function confirm(){ //http://local.foo.com/e_sourcing/user/confirm/22/bae809a21d19e89e59c6f1268b763367
			$userId = $this->uri->segment(3); 
			$activation_code = $this->uri->segment(4); //echo $activation_code; die;	
			$member = $this->Users_model->get_details($userId); //print_r($user); die;
			if($member!="Not found"){
				if($member && $member['activation_id']==$activation_code) {
					$this->Users_model->activate_account($userId);
					$this->session->set_flashdata('success', 'Congratulations! Your account is now verified. Please login');	
				} else {
					$this->session->set_flashdata('error', 'Problem in account verification. Please try again later or contact our support system.');		
				}
			} else {
					$this->session->set_flashdata('error', 'Error!<br>This user is not exists.');		
				}
				redirect('/','refresh');
			
		}			
	/**********************End***********************************************/
	public function edit_profile(){
	 	$userData =	$this->session->userdata('Users');
		//echo "<pre>";print_r($this->data['country']);echo "</pre>";
		$this->data['profile']  = 	$userData;		
		$this->data['country']	=	$this->Common_model->get_country();
		$this->data['supplier'] = 	$this->Users_model->get_details($userData['id']);
		if($userData['user_type']=='0'){
			$this->view('supplier/edit_profile',$this->data);
		}else{
			redirect('/');
		}
	}
	
	/*********************post requiremnent***************/
	public function post_requirement(){
		$userData =	$this->session->userdata('Users');
		if(isset($userData) && !empty($userData)){
			$this->view('users/post_requirement');
		}else{
			redirect('/');
		}
	}
	public function organization_profile($id = NULL){
		if(!isset($id) || empty($id)){
			$session =	$this->session->userdata('Users');
			$id		 =   $session['id'];
		}
		$userData = $this->Users_model->get_details($id);
		$this->data['profile'] = $userData;
		$this->view('users/organization_profile',$this->data);
	}
	
	public function individual_profile($id = NULL){
	    if(!isset($id) || empty($id)){
			$session =	$this->session->userdata('Users');
			$id		 =   $session['id'];
		}
		$userData = $this->Users_model->get_details($id);
		$this->data['profile'] = $userData;
		$this->view('users/individual_profile',$this->data);
	}
	/**********Post job by user via ajax request**********/
	/*************Pramod Kumar********11 Jan 2015********************/
	public function job_post(){
		
		$session = $this->session->userdata('Users');
		if(empty($session)){
			echo LOGGED_REQUIRED;
		}else if(!$_POST){
			echo ERROR;
		}else{
				$title 					= $this->input->post('title');
				$skill_id 				= $this->input->post('skill_id');
				$job_country_id 		= $this->input->post('job_country_id');
				$job_state_id 			= $this->input->post('job_state_id');
				$job_city_id 			= $this->input->post('job_city_id');
				$start_date 			= $this->input->post('job_start_date');
				$end_date 				= $this->input->post('job_end_date');
				$description 			= $this->input->post('description');
				$industry_expertise_id 	= $this->input->post('industry_expertise_id');
				$startDate				= $start_date;	
				$endDate				= $end_date;	
				//print_r($startDate);die;
				$save=array(
					'user_id'=>$session['id'],
					'title'=>$title,
					'skill_id'=>$skill_id,
					'country_id'=>$job_country_id,
					'state_id'=>$job_state_id,
					'city_id'=>$job_city_id,
					'job_start_date'=>$startDate,
					'job_end_date'=>$endDate,
					'description'=>$description,
					'industry_expertise_id'=>$industry_expertise_id
				);
				//print_r($save);die;
				$insertId = $this->Users_model->save_jobs($save);
				if($insertId>0){				
					echo 'Success';die;
				}else{
					echo ERROR;die;
				}	
		}
	}
	/*********users messaging system*************/
	public function messages($id=NULL){
		
		$session = $this->session->userdata('Users');
		if(isset($id) && !empty($id)){
				$check = $this->Users_model->check_friend_list($session['id'],$id);
			if(empty($check)){
				$data = array('user_from'=>$session['id'],'user_to'=>$id);
				$this->Users_model->add_friend_list($data);
				redirect('users/dashboard');
			}
		}
		if(isset($session) && !empty($session)){
			$this->data['users'] = $this->Users_model->get_many_users_ids($session['id'],$session['user_type']);
			$this->view('users/messages',$this->data);
		}else{
			redirect('/');
		}
	}
	
	/***************get users on ajax request*************/
	public function get_current_user(){
		
		if($this->input->is_ajax_request()){
			
			$session = $this->session->userdata('Users');
			$userId = $this->input->post('userId');
			$result = $this->Users_model->get_details($userId);
			$message= $this->Users_model->get_message($userId,$session['id']);
			//print_r($message);die;
			$data = '';
			if(isset($result) && !empty($result)){
				 if(isset($result['picture']) && !empty($result['picture'])){
				 		$profilePic	=	 base_url('public/users/'.$result['picture']);
				 }else{
				 		$profilePic	=	 base_url('public/img/avatar-4.jpg'); 
				 }
				$data .= '<ul class="simple-post-list"><li><div class="post-image"><div class="img-thumbnail">
							 <img src="'.$profilePic.'" alt="" width="50" height="50">
					 		</div>
				 		</div>';
				$data .= '<div class="post-info"><a href="javascript:void(0)">'.ucwords($result['first_name']." ".$result['last_name']).'</a></div></li></ul>';
				$data .= '<input type="hidden" name="user_to" id="user_to" value="'.$result['id'].'">';
				$message_data = '';
				if(isset($message) && !empty($message)){
					foreach($message as $key=>$value){
						$class	= '';
						if($value['user_to'] == $session['id']){
							$class = 'green';
						}
						$message_data .= '<div style="float:left" class="'.$class.'">'.$value['message'].'</div>';
						$message_data .= '<div style="float:right" class="'.$class.'">'.$value['created_date'].'</div>'.'<br>';
					}
				}
				echo $data."~".$message_data;die;
			}else{
				echo ERROR;
			}
		}
	}
	/**************send message to supplier**************/
	public function send_message(){
		$user_to = $this->input->post('user_to');
		$message = $this->input->post('message');
		$session = $this->session->userdata('Users');
		$users   = array(
							'user_from' =>$session['id'],
							'user_to'=>$user_to,
							'message'=>$message,
							'ip_address'=>$_SERVER['REMOTE_ADDR']
						);
		$result 	=	$this->Users_model->send_message($users);
		$date		=	date('Y-m-d h:i:s');
		if($result>0){
			//$message_data .= '<div style="float:left">'.$message.'</div>';
			//$message_data .= '<div style="float:right">'.$date.'</div>'.'<br>';
			$message= $this->Users_model->get_message($user_to,$session['id']);
			$message_data = '';
				if(isset($message) && !empty($message)){
					foreach($message as $key=>$value){
						$class	= '';
						if($value['user_to'] == $session['id']){
							$class = 'green';
						}
						$message_data .= '<div style="float:left" class="'.$class.'">'.$value['message'].'</div>';
						$message_data .= '<div style="float:right" class="'.$class.'">'.$value['created_date'].'</div>'.'<br>';
					}
				}
			
			echo $message_data;die;
		}else{
			echo 'Error';die;
		}			
						
	}
	/***************************fb/twitter login************************/
	 /*     * *************************End************************************************** */

    public function fblogin() {
        $userfbData = ['firm_type' => $this->input->post('firm_type'), 'user_type' => $this->input->post('user_type')];
        $this->session->set_userdata('userfbData', $userfbData);
        $this->load->library('Facebook'); // Automatically picks appId and secret from config
        $data['login_url'] = $this->facebook->getLoginUrl(array(
            'redirect_uri' => site_url('users/fbregister'),
            'scope' => array("email") // permissions here
        ));
        redirect($data['login_url']);
        $user = $this->facebook->getUser();
//        if ($user) {
//            try {
//                $data['user_profile'] = $this->facebook->api('/me');
//            } catch (FacebookApiException $e) {
//                $user = null;
//            }
//        } else {
//            // Solves first time login issue. (Issue: #10)
//            //$this->facebook->destroySession();
//        }

        if ($user) {

            $data['logout_url'] = site_url('welcome/logout'); // Logs off application
        } else {
            $data['login_url'] = $this->facebook->getLoginUrl(array(
                'redirect_uri' => site_url('users/fbregister'),
                'scope' => array("email") // permissions here
            ));
            redirect($data['login_url']);
        }
    }

    public function fbregister() {
        $this->load->library('Facebook');
        $user = $this->facebook->getUser();
        if ($user) {
            try {
                $fbUserData = $this->facebook->api('/me');
                $userDBData = $this->Users_model->get_byfbid($fbUserData['id']);
                if ($userDBData == 'Not found') {

                    $name = explode(' ', $fbUserData['name']);
                    $first_name = $name[0] ? $name[0] : '';
                    $last_name = $name[1] ? $name[1] : '';
                    $save = array(
                        'first_name' => $first_name,
                        'last_name' => $last_name,
                        'email' => $fbUserData['id'],
                        'password' => '123',
                        'user_type' => $this->session->userdata('userfbData')['user_type'],
                        'activation_id' => time(),
                        'firm_type' => $this->session->userdata('userfbData')['firm_type']
                    );

                    $insertId = $this->Users_model->save_users($save);
                    $userData = $this->Users_model->get_details($insertId);
                    $this->session->set_userdata('Users', $userData);
                    redirect('users/dashboard');
                } else {
                    $userData = $this->Users_model->get_details($userDBData['id']);
                    $this->session->set_userdata('Users', $userData);
                    redirect('users/dashboard');
                }
            } catch (FacebookApiException $e) {
                $user = null;
            }
        } else {
            // Solves first time login issue. (Issue: #10)
            //$this->facebook->destroySession();
        }
    }

    public function twlogin() {
//        $this->session->sess_destroy();
        $userfbData = ['firm_type' => $this->input->post('firm_type'), 'user_type' => $this->input->post('user_type')];
		//print_r($userfbData);die;
        $this->session->set_userdata('usertwData', $userfbData);

        $this->load->library('twconnect');

        /* twredirect() parameter - callback point in your application */
        /* by default the path from config file will be used */
        $ok = $this->twconnect->twredirect('twtest/callback');
        if (!$ok) {
            echo 'Could not connect to Twitter. Refresh the page or try again later.';
        }
    }

    public function twregister() {
        $this->load->library('Twconnect');
        $this->twconnect->twaccount_verify_credentials();
        $userTwData = $this->twconnect->tw_user_info;
        if ((count( (array)$userTwData) ) == 0) {
            try {
                $userDBData = $this->Users_model->get_bytwid($userTwData->id);
                if ($userDBData == 'Not found') {

                    $name = explode(' ', $userTwData->name);
                    $first_name = reset($name) ? reset($name) : '';
                    $last_name = last($name) ? last($name) : '';
                    $save = array(
                        'first_name' => $first_name,
                        'last_name' => $last_name,
                        'email' => $userTwData->id,
                        'password' => '123',
                        'user_type' => $this->session->userdata('usertwData')['user_type'],
                        'activation_id' => time(),
                        'firm_type' => $this->session->userdata('usertwData')['firm_type']
                    );

                    $insertId = $this->Users_model->save_users($save);
                    $userData = $this->Users_model->get_details($insertId);
                    $this->session->set_userdata('Users', $userData);
                    redirect('users/dashboard');
                } else {
                    $userData = $this->Users_model->get_details($userDBData['id']);
                    $this->session->set_userdata('Users', $userData);
                    redirect('users/dashboard');
                }
            } catch (FacebookApiException $e) {
                $user = null;
            }
        } else {
            // Solves first time login issue. (Issue: #10)
            //$this->facebook->destroySession();
        }
    }
	
	public function linkedin_login(){
	
		//print_r($_POST);die;
		$userlbData = ['firm_type' => $this->input->post('firm_type'), 'user_type' => $this->input->post('user_type')];
		$this->session->set_userdata('userLinkedinData', $userlbData);
	
		//print_r($this->session->userdata('userLinkedinData'));
		if (isset($_GET["oauth_problem"]) && $_GET["oauth_problem"] <> "") { 
  			// in case if user cancel the login. redirect back to home page.
  			$_SESSION["err_msg"] = $_GET["oauth_problem"];
  			redirect('/');
  			exit;
		}
		$client = new oauth_client_class;
		$client->debug = false;
		$client->debug_http = true;
		$client->redirect_uri = call_back_url;
		$client->client_id = linkedinApiKey;
		$application_line = __LINE__;
		$client->client_secret = linkedinApiSecret;
		//print_r($client);
		//echo strlen($client->client_secret);die;
		if (strlen($client->client_id) == 0 || strlen($client->client_secret) == 0) 
  		die('Please go to LinkedIn Apps page https://www.linkedin.com/secure/developer?newapp= , '.
			'create an application, and in the line '.$application_line.
			' set the client_id to Consumer key and client_secret with Consumer secret. '.
			'The Callback URL must be '.$client->redirect_uri).' Make sure you enable the '.
			'necessary permissions to execute the API calls your application needs.';

			/* API permissions
			 */
			$client->scope = 'r_basicprofile r_emailaddress';
			if (($success = $client->Initialize())) {  
			  	if (($success = $client->Process())) {
					if (strlen($client->authorization_error)) {
				  		$client->error = $client->authorization_error;
				  		$success = false;
					} elseif (strlen($client->access_token)) {
				  			$success = $client->CallAPI(
								'http://api.linkedin.com/v1/people/~:(id,email-address,first-name,last-name,location,picture-url,public-profile-url,formatted-name)', 
								'GET', array(
									'format'=>'json'
								), array('FailOnAccessError'=>true), $user);
					  }
			    }
			  	$success = $client->Finalize($success);
				//die('here');			
			}
			if ($user) { //print_r($user);die;
					$userDBData = $this->Users_model->get_bytwid($user->emailAddress);
					//print_r($userDBData);die;
                	if ($userDBData == 'Not found') {
					//print_r($this->session->userdata('userLinkedinData'));die;
						$save = array(
							'first_name' => $user->firstName,
							'last_name' => $user->lastName,
							'email' => $user->emailAddress,
							'password' => '123',
							'user_type' =>$this->session->userdata('userLinkedinData')['user_type'],
							'activation_id' =>time(),
							'firm_type' => $this->session->userdata('userLinkedinData')['firm_type']
						);
						//print_r($save);die;
						$insertId = $this->Users_model->save_users($save);
						$userData = $this->Users_model->get_details($insertId);
						$this->session->set_userdata('Users', $userData);
						redirect('users/dashboard');
                	} else {
						$userData = $this->Users_model->get_details($userDBData['id']);
						$this->session->set_userdata('Users', $userData);
						redirect('users/dashboard');
                	}
			} else {
					exit();
			}		
	}
	
	
	public function send_rating(){
	
		if($this->input->is_ajax_request()){
			$session 		= $this->session->userdata('Users');
			$supplier_id	= $this->input->post('supplier_id');
			$rating			= $this->input->post('rating');
			$data			= array(
								'user_id'=>$session['id'],
								'supplier_id'=>$supplier_id,
								'rating'=>$rating
							 );
			$feedback_update	= array(
								'id'=>$this->input->post('feedback_id'),
								'status'=>'1'
							 );
			$result 	=	$this->Common_model->save($data,'supplier_feedback');
			/*$result	=	$this->Common_model->get_common_result($data,'supplier_feedback');
			if(!empty($result)){
				echo "Feedback can not be sent again";
				die;
			}else{(
				$this->Common_model->save($data,'supplier_feedback');
				echo 'Success';die;
			}*/
			if(!empty($result)){
				$this->Common_model->save($feedback_update,'user_feedback_request');
				echo 'Success';die;
			}else{
				echo ERROR;die;				
			}
		}
	}
	
	
	 /************send mail***********************/
	  function send_password_email($userId,$password){
	  		//echo $userId;die;	
			//$admin = $this->admin_model->getinfo(); 
			$user = $this->Users_model->get_details($userId);
			//print_r($user);die;
			$this->load->library('email');
            $config['protocol']     = 'mail';
			$config['mailpath']     = "/usr/bin/sendmail"; 
            $config['smtp_host']    = 'localhost';
            $config['smtp_port']    = '465';
            $config['smtp_timeout'] = '7';
            $config['smtp_user']    = SMTP_USER;
            $config['smtp_pass']    = SMTP_PASSWORD;
            $config['charset']    	= 'utf-8';
            $config['newline']    	= "\r\n";
            $config['mailtype'] 	= 'text'; // or html
            $config['validation'] = TRUE; // bool whether to validate email or not      
            $this->email->initialize($config);
			$this->email->from(From_EMAIL,SITE_NAME);
			$this->email->to($user['email']);
			//$this->email->cc($admin['email']);
			$this->email->subject('Forgot Password');
			$message = "Thanks for new password request to ".SITE_NAME."!:
			\n Plase get new password:
			\n \n"."Password: ".$password."
			<br />Thanks \n".SITE_NAME."!<br /><br />Sincerely,<br />".SITE_NAME;
			$this->email->message($message);
			//$this->email->clear();
			if($this->email->send()){
				return true;
				//echo $this->email->print_debugger();
			}else{
				//echo $this->email->print_debugger();
			}
			
		}
	
	/*****************change password********************/
	public function change_password()
	{						
		$this->load->library(array('form_validation'));
		$this->form_validation->set_error_delimiters('<span style="color:#FF0000;">', '</span><br>');
		$this->form_validation->set_rules('current_password','Current Password','trim|required|min_length[6]');
		$this->form_validation->set_rules('new_password','New Password','trim|required|min_length[6]');
		$this->form_validation->set_rules('confim_new_password','Confirm Password','trim|required|min_length[6]|matches[new_password]');
		if($this->form_validation->run()==false){ 
			$this->data['error'] = $this->data['error']=validation_errors();
			echo $this->data['error'];die;
		}else{
				$session 				= $this->session->userdata('Users');
				$current_password 		= $this->input->post('current_password');
				$new_password			= $this->input->post('new_password');
				$confim_new_password	= $this->input->post('confim_new_password');
				$current_user			= $this->Users_model->user_current_password($current_password);
				if($current_user){
					$save=array(
						'id'		=>$session['id'],
						'password'=>md5($new_password),
					);
					$updateDB = $this->Users_model->save_users($save);
					if($updateDB>0){
						/*****************End********************************/	
						$this->change_password_confirmation($updateDB);				
						echo 'Success';die;
						//redirect('events/add_event','refresh');
					}else{
						echo ERROR;die;
					}	
				}else{
					$this->data['error']="<span style='color:#FF0000;'>Current Password is wrong, Please go through forgot password</span>";
					echo $this->data['error'];die;
				}
			}
	}
	
	public function change_password_confirmation($userId){
			//$admin = $this->admin_model->getinfo(); 
			$user = $this->Users_model->get_details($userId);
			//print_r($user);die;
			$this->load->library('email');
            $config['protocol']     = 'mail';
			$config['mailpath']     = "/usr/bin/sendmail"; 
            $config['smtp_host']    = 'localhost';
            $config['smtp_port']    = '465';
            $config['smtp_timeout'] = '7';
            $config['smtp_user']    = SMTP_USER;
            $config['smtp_pass']    = SMTP_PASSWORD;
            $config['charset']    	= 'utf-8';
            $config['newline']    	= "\r\n";
            $config['mailtype'] 	= 'text'; // or html
            $config['validation'] = TRUE; // bool whether to validate email or not      
            $this->email->initialize($config);
			$this->email->from(From_EMAIL,SITE_NAME);
			$this->email->to($user['email']);
			//$this->email->cc($admin['email']);
			$this->email->subject('Change Password Request Completed');
			
			$message = SITE_NAME." Congratulations, Your Password has been successfully changed,:
			\n Please contact customer support, if you did not do this request \n \n
			<br />Thanks \n".SITE_NAME."!<br /><br />Sincerely,<br />".SITE_NAME;
			$this->email->message($message);
			//$this->email->clear();
			if($this->email->send()){
				return true;
				//echo $this->email->print_debugger();
			}else{
				//echo $this->email->print_debugger();
			}
		
	}
	
	
	 public function payment_notification() {

        // CONFIG: Enable debug mode. This means we'll log requests into 'ipn.log' in the same directory.
        // Especially useful if you encounter network errors or other intermittent problems with IPN (validation).
        // Set this to 0 once you go live or don't require logging.
        define("DEBUG", 1);
        // Set to 0 once you're ready to go live
        define("USE_SANDBOX", 1);
        define("LOG_FILE", "ipn.log");
        // Read POST data
        // reading posted data directly from $_POST causes serialization
        // issues with array data in POST. Reading raw POST data from input stream instead.
        $raw_post_data = file_get_contents('php://input');
        $raw_post_array = explode('&', $raw_post_data);
        $myPost = array();
        foreach ($raw_post_array as $keyval) {
                $keyval = explode ('=', $keyval);
                if (count($keyval) == 2)
                        $myPost[$keyval[0]] = urldecode($keyval[1]);
        }
        // read the post from PayPal system and add 'cmd'
        $req = 'cmd=_notify-validate';
        if(function_exists('get_magic_quotes_gpc')) {
                $get_magic_quotes_exists = true;
        }
        foreach ($myPost as $key => $value) {
                if($get_magic_quotes_exists == true && get_magic_quotes_gpc() == 1) {
                        $value = urlencode(stripslashes($value));
                } else {
                        $value = urlencode($value);
                }
                $req .= "&$key=$value";
        }
        // Post IPN data back to PayPal to validate the IPN data is genuine
        // Without this step anyone can fake IPN data
        if(USE_SANDBOX == true) {
                $paypal_url = "https://www.sandbox.paypal.com/cgi-bin/webscr";
        } else {
                $paypal_url = "https://www.paypal.com/cgi-bin/webscr";
        }
        $ch = curl_init($paypal_url);
        if ($ch == FALSE) {
                return FALSE;
        }
        curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $req);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_FORBID_REUSE, 1);
		curl_setopt($ch, CURLOPT_SSLVERSION, 6);
        if(DEBUG == true) {
                curl_setopt($ch, CURLOPT_HEADER, 1);
                curl_setopt($ch, CURLINFO_HEADER_OUT, 1);
        }
        // CONFIG: Optional proxy configuration
        //curl_setopt($ch, CURLOPT_PROXY, $proxy);
        //curl_setopt($ch, CURLOPT_HTTPPROXYTUNNEL, 1);
        // Set TCP timeout to 30 seconds
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 30);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Connection: Close'));
        // CONFIG: Please download 'cacert.pem' from "http://curl.haxx.se/docs/caextract.html" and set the directory path
        // of the certificate as shown below. Ensure the file is readable by the webserver.
        // This is mandatory for some environments.
        //$cert = __DIR__ . "./cacert.pem";
        //curl_setopt($ch, CURLOPT_CAINFO, $cert);
        $res = curl_exec($ch);
       // $this->_sendPaymentMail('pramod.itprofessional@gmail.com',500,curl_errno($ch));
		/*if (curl_errno($ch) != 0) // cURL error
        {
            if(DEBUG == true) {	
                error_log(date('[Y-m-d H:i e] '). "Can't connect to PayPal to validate IPN message: " . curl_error($ch) . PHP_EOL, 3, LOG_FILE);
            }
            curl_close($ch);
            exit;
        } else {
            // Log the entire HTTP response if debug is switched on.
            if(DEBUG == true) {
                error_log(date('[Y-m-d H:i e] '). "HTTP request of validation request:". curl_getinfo($ch, CURLINFO_HEADER_OUT) ." for IPN payload: $req" . PHP_EOL, 3, LOG_FILE);
                error_log(date('[Y-m-d H:i e] '). "HTTP response of validation request: $res" . PHP_EOL, 3, LOG_FILE);
            }
            curl_close($ch);
        }*/
		//$this->_sendPaymentMail('pramod.itprofessional@gmail.com',500,$res);
		if ( $res === FALSE )
    	{
        	error_log(date('[Y-m-d H:i e] '). "Can't connect to PayPal to validate IPN message: " . curl_error($ch) . PHP_EOL, 3, LOG_FILE);
        	curl_close( $ch );
        	return;
    	}
        // Inspect IPN validation result and act accordingly
        // Split response headers and payload, a better way for strcmp
        $tokens = explode("\r\n\r\n", trim($res));
        $res = trim(end($tokens));
		//$this->_sendPaymentMail('pramod.itprofessional@gmail.com',500,'test');
        if (strcmp ($res, "VERIFIED") == 0) {
			//$this->_sendPaymentMail('pramod.itprofessional@gmail.com',500,'now its ok');
            // assign posted variables to local variables
            $item_name 			= $_POST['item_name'];
            $payment_status 	= $_POST['payment_status'];
            $payment_amount 	= $_POST['mc_gross'];
            $payment_currency 	= $_POST['mc_currency'];
            $txn_id 			= $_POST['txn_id'];
            $receiver_email 	= $_POST['receiver_email'];
            $payer_email 		= $_POST['payer_email'];

            // check whether the payment_status is Completed
            $isPaymentCompleted = false;
            if($payment_status == "Completed") {
                  $isPaymentCompleted = true;
            }
            // check that txn_id has not been previously processed
            $isUniqueTxnId = false; 
			$result	=	$this->Supplier_model->get_payment($txn_id,'suppliers_payment');
          //  $result = 	$this->StudentPayment->find('all',array('conditions'=>array('StudentPayment.txn_id'=>$txn_id)));
            //$result = $db->selectQuery("SELECT * FROM payments WHERE txn_id = '$txn_id'");
            if(empty($result)) {
                $isUniqueTxnId = true;
            }
            // check that receiver_email is your PayPal email
            // check that payment_amount/payment_currency are correct
            if($isUniqueTxnId && $payment_currency == "USD") {
                $customValue = explode("~",$_POST['custom']);
                //$payment_id = $db->insertQuery("INSERT INTO payment(item_number, item_name, payment_status, payment_amount, payment_currency, txn_id) VALUES('$item_number', '$item_name', $payment_status, '$payment_amount', '$payment_currency', '$txn_id')");
                $supplier_id    	= $customValue['0'];
                $amount        		= $payment_amount;
                $payment_status		= $payment_status;
                $txn_id        		= $txn_id;
                $receiver_email		= $receiver_email;
                $payer_email   		= $payer_email;
                $payment_currency   = $payment_currency;
				
				$save=array(
					'supplier_id'=>$supplier_id,
					'amount'=>$amount,
					'payment_status'=>$payment_status,
					'txn_id'=>$txn_id,
					'receiver_email'=>$receiver_email,
					'payer_email'=>$payer_email,
					'payment_currency'=>$payment_currency
				);
				//print_r($save);die;
				$insertId = $this->Common_model->save($save,'suppliers_payment');
                if($insertId>0){
                    
					$result        	= 	$this->Common_model->get_data($supplier_id,'users');
                    $amount         =   '$'.$amount;
					$users_save=array(
						'id'=>$supplier_id,
						'membership_type'=>$customValue['1']
					);
					$this->Common_model->save($users_save,'users');
                    $this->_sendPaymentMail($result->email,$amount,$item_name);
                }
            }
            // process payment and mark item as paid.
            if(DEBUG == true) {
                    error_log(date('[Y-m-d H:i e] '). "Verified IPN: $req ". PHP_EOL, 3, LOG_FILE);
            }
        } else if (strcmp ($res, "INVALID") == 0) {
            // log for manual investigation
            // Add business logic here which deals with invalid IPN messages
            if(DEBUG == true) {
                    error_log(date('[Y-m-d H:i e] '). "Invalid IPN: $req" . PHP_EOL, 3, LOG_FILE);
            }
        }
       //$this->view('success');

    }
    
     /*
     * Sent mail for payment subscription
     * @pramod kumar
     * @30 September 2015
     */
      function _sendPaymentMail($email,$amount,$package) {
       
			$this->load->library('email');
			$config['protocol']     = 'mail';
			$config['mailpath']     = "/usr/bin/sendmail"; 
			$config['smtp_host']    = 'localhost';
			$config['smtp_port']    = '465';
			$config['smtp_timeout'] = '7';
			$config['smtp_user']    = SMTP_USER;
			$config['smtp_pass']    = SMTP_PASSWORD;
			$config['charset']    	= 'utf-8';
			$config['newline']    	= "\r\n";
			$config['mailtype'] 	= 'html'; // or html
			$config['validation'] = TRUE; // bool whether to validate email or not      
			$this->email->initialize($config);
			$this->email->from('donotreply@infutive.com',SITE_NAME);
			$this->email->to($email);
			$date		=	date('F d, Y');
			//$this->email->cc($admin['email']);
			$this->email->subject('Feedback Request');
			$message = "Payment Notification from ".SITE_NAME."! <br><br> Details are following below:<br>";
			$message .= '<br>'."Subscription Date: ".$date.'<br>';
			$message .= " amount: ".$amount."<br>";
			$message .= " Subscription Package: ".$package.'<br>';
			$message .= "<br />Thanks for joining ".SITE_NAME."!<br /><br />Sincerely,<br />".SITE_NAME;
			$this->email->message($message);
			//$this->email->clear();
			if($this->email->send()){
				return true;
				//echo $this->email->print_debugger();
			}else{
				//echo $this->email->print_debugger();
			}
    }
	
	public function delete(){
		$session 		= $this->session->userdata('Users');
		$save=array(
			'id'=>$session['id'],
			'status'=>'1',
		);
		//print_r($save);die;
		$insertId = $this->Common_model->save($save,'users');
		if($insertId>0){
			echo 'Success';die;
		}
	}
	
	public function login_change(){
		
		$user_type	=	$this->input->post('user_type');
		$session 	= 	$this->session->userdata('Users');
		$save=array(
				'id'=>$session['id'],
				'user_type'=>$user_type,
		);
		//print_r($save);die;
		$insertId = $this->Common_model->save($save,'users');
		if($insertId>0){
			$userData = $this->Users_model->get_details($insertId);
			$this->session->set_userdata('Users', $userData);
			echo 'Success';die; 
		}
	
	}

	
	/******************logout*******************/
	public function logout(){  	
		$this->session->sess_destroy();
		setcookie('uid', '', time() - (86400 * 30), "/");
		setcookie('firstname', '', time() - (86400 * 30), "/");
		$this->cache->clean();
		redirect('/','refresh');
	}		
/*********************************** End of function *********************/	
}

<?php

/*
  Question2Answer by Gideon Greenspan and contributors
  http://www.question2answer.org/

  File: index.php
  Description: A stub that only sets up the Q2A root and includes qa-index.php


  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  More about this license: http://www.question2answer.org/license.php
 */
ini_set('display_errors',0);
session_start();
if (!isset($_SESSION['QA_EXT_LOGGEDIN'])) {
    $parameter = $_GET['param'];
    $hash = $_GET['hash'];
    $salt = "cV0puOlx";
    $hashed = md5($salt . $parameter);
    if ($hash === $hashed) {
        $_SESSION['QA_EXT_LOGGEDIN'] = 1;
        $_SESSION['QA_EXT_LOGGEDIN_USERID'] = $_GET['param'];
    }
}

//	Set base path here so this works with symbolic links for multiple installations
define('QA_BASE_DIR', dirname(empty($_SERVER['SCRIPT_FILENAME']) ? __FILE__ : $_SERVER['SCRIPT_FILENAME']) . '/');
if(!isset($_COOKIE['uid'])){
	//die('here');
	//header('location:/');
}
require 'qa-include/qa-index.php';


/*
	Omit PHP closing tag to help avoid accidental output
*/
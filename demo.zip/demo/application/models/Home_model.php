<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Home_model extends CI_Model{
	function __costruct()
	{
		Parent::__construct();
		$this->load->database();
	}
	function get_images()
	{
		$this->db->select('images.*');
		$this->db->from('images');
		$this->db->order_by('images.order ASC');
		//echo $this->db->last_query();die;
		return $this->db->get()->result();
	}

	function order_update($ids){
		
		$id_array = explode(",",$ids);
		$count = 1;
		foreach ($id_array as $id){
			$data['order'] = $count;
			$this->db->update('images',$data,array('id'=>$id));
			$count ++;	
		}
		return true;
	}

}
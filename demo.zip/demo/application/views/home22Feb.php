<?php ini_set('display_errors',0);?>
<?php if(isset($error)){?><div class="error close_div"><button type="button" class="close">�</button><?php echo $error; ?><br></div><?php }?>
<?php 
@$success=$this->session->flashdata('success');
if(@$success!=""){?><div class="success close_div" style="color:#4b8df8;"><button type="button" class="close">�</button><?php echo $success;?> </div> <?php } ?>
<?php 
@$error=$this->session->flashdata('error');
if(@$error!=""){?><div class="error close_div" style="color:#4b8df8;"><button type="button" class="close">�</button><?php echo $error;?> </div> <?php } ?>

<style>
.expert
{
font-size: 15px;
    color: #fff;
    padding-top: 29px;
    position: relative;
	float:right;	
}

.expert a
{
	color:#fff !important;
}

.mb-sm-1
{
margin-bottom: 40px !important;
       margin-top: -19px;
    color: #fff;
    font-size: 3.6em;	
}
</style>
<div role="main" class="main">
				 <div class="slider-container">
					 <div class="section section-3">
                      <div class="home-concept" style="padding-top:120px;">
						<div class="row center" >
                        <div class="row" >
                        <div class="col-md-5    col-md-offset-4 ">
                        <p class="expert"> <a href="#" class="btn btn-success">Be Global Expert</a></p>
                        </div>
                        </div>
                         <div class="row" >
                        <h1 class="mb-sm-1 ">
								Find the Best <b>EXPERTS</b>
							 </h1>
                             </div>
							<div class="col-md-10 col-md-offset-2 ">
                            
                             <div class="col-md-2">
								 <div class="process-image" data-appear-animation="bounceIn" data-appear-animation-delay="200">
								 	 <a href="<?php echo base_url();?>supplier/expert/consultant">
									 <img src="<?php echo base_url('public/img/head-section/consultant.png'); ?>" alt="" />
									 </a>
									 
								 </div>
							 </div>
                              <div class="col-md-2">
								 <div class="process-image" data-appear-animation="bounceIn" data-appear-animation-delay="400">
								 	  <a href="<?php echo base_url();?>supplier/expert/<?php echo urlencode('subject experts');?>">
									 <img src="<?php echo base_url('public/img/head-section/subject.png'); ?>" alt="" />
									 </a>
								 </div>
							 </div>
                              <div class="col-md-2 ">
								 <div class="process-image" data-appear-animation="bounceIn">
								 	  <a href="<?php echo base_url();?>supplier/expert/innovators">
									 <img src="<?php echo base_url('public/img/head-section/innovators.png'); ?>" alt="" />
									 </a>
								 </div>
							 </div>
							 <div class="col-md-2 ">
								 <div class="process-image" data-appear-animation="bounceIn">
									 <a href="<?php echo base_url();?>supplier/expert/researcher">
									 	<img src="<?php echo base_url('public/img/head-section/research.png'); ?>" alt="" />
									</a>
									
								 </div>
							 </div>
                             
                              <div class="col-md-2 ">
								 <div class="process-image" data-appear-animation="bounceIn">
								 	  <a href="<?php echo base_url();?>supplier/expert/<?php echo urlencode('Keynotes Speakers');?>">
									 <img src="<?php echo base_url('public/img/head-section/keynote.png'); ?>" alt="" />
									 </a>
								 </div>
							 </div>
							
							
							 
						 </div>
                         </div>
                         
                         <div class="row center" >
							<div class="col-md-10 col-md-offset-2 ">
                            
                              <div class="col-md-2 ">
								 <div class="process-image" data-appear-animation="bounceIn">
								 	  <a href="<?php echo base_url();?>supplier/expert/trainers">
									 	<img src="<?php echo base_url('public/img/head-section/trainers.png'); ?>" alt="" />
									 </a>
								 </div>
							 </div>
                             <div class="col-md-2 ">
								 <div class="process-image" data-appear-animation="bounceIn">
									 <a href="<?php echo base_url();?>supplier/expert/counsellor">
									 	<img src="<?php echo base_url('public/img/head-section/counsellor.png'); ?>" alt="" />
									</a>
									
								 </div>
							 </div>
							<div class="col-md-2 ">
								 <div class="process-image" data-appear-animation="bounceIn">
									 <a href="<?php echo base_url();?>supplier/expert/coach">
									 	<img src="<?php echo base_url('public/img/head-section/coach.png'); ?>" alt="" />
									</a>
									
								 </div>
							 </div>
							 <div class="col-md-2">
								 <div class="process-image" data-appear-animation="bounceIn" data-appear-animation-delay="200">
								 	  <a href="<?php echo base_url();?>supplier/expert/mentor">
									 <img src="<?php echo base_url('public/img/head-section/mentor.png'); ?>" alt="" />
									 </a>
								 </div>
							 </div>
							 <div class="col-md-2">
								 <div class="process-image" data-appear-animation="bounceIn" data-appear-animation-delay="400">
								 	  <a href="<?php echo base_url();?>supplier/expert/<?php echo urlencode('visiting faculty');?>">
									 <img src="<?php echo base_url('public/img/head-section/faculty.png'); ?>" alt="" />
									 </a>
									
								 </div>
							 </div>
							
                             </div>
						 </div>
                      </div>            
					 </div>
				 </div>
                 
                  <div class="home-intro " id="home-intro">
					<div class="container">
				
						<div class="row">
							<div class="col-md-3">
							<a href="#">
                             <img src="<?php echo base_url('public/img/head-section/makeinindia.png'); ?>" class="img-responsive img-thumbnail" alt="" />
                            </a>	
							</div>
                            <div class="col-md-3">
							<a href="#">
                             <img src="<?php echo base_url('public/img/head-section/skill.png'); ?>" class="img-responsive img-thumbnail" alt="" />
                           
                            </a>		
							</div>
                            <div class="col-md-3">
							<a href="#">
                            <img src="<?php echo base_url('public/img/head-section/startup.png'); ?>" class="img-responsive img-thumbnail" alt="" />
                           
                            </a>		
							</div>
							<div class="col-md-3">
                           <a href="#">	  <img src="<?php echo base_url('public/img/head-section/business-setup.png'); ?>" class="img-responsive img-thumbnail" alt="" /></a>
							
							</div>
						</div>
				
					</div>
				</div>
                 
				 	<div class="container" id="How-it-works" style="padding-top:110px;">
					 <div class="row">
						 <div class="col-md-4">
							<div class="embed-responsive embed-responsive-16by9">
								<iframe frameborder="0" allowfullscreen="" src="http://www.youtube.com/embed/oNBBijn4JuY?showinfo=0&amp;wmode=opaque"></iframe>
							</div>
						 </div>
						 <div class="col-md-7 col-md-offset-1">
							 <h2 class="mt-xl"><strong>How  </strong> does it works </h2>
							 <p class="lead">
								Donec convallis a magna at interdum. Sed consequat dignissim risus. Praesent consectetur iaculis augue. Mauris a lacus tortor. Fusce quis libero et diam vulputate semper. Donec id porttitor neque. Vestibulum ante ipsum primis
							 </p>
							 <p>
								Donec convallis a magna at interdum. Sed consequat dignissim risus. Praesent consectetur iaculis augue. Mauris a lacus tortor. Fusce quis libero et diam vulputate semper. Donec id porttitor neque. Vestibulum ante ipsum primis
							 </p>
						 </div>
					 </div>

					 <hr class="tall">
					 <div class="row">
						 <div class="col-md-7">
							 <h2 class="mt-xl">Lorem <strong>ipsum dolor sit amet </strong></h2>
							 <p class="lead">
								Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.Lorem ipsum dolor sit amet, 
							 </p>
							 <p>
								consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpatLorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat
							 </p>
						 </div>
						 <div class="col-md-4 col-md-offset-1 mt-xl">
							 <img class="img-responsive appear-animation fadeInRight appear-animation-visible" src="<?php echo base_url('public/img/learn.jpg'); ?>" alt="style switcher" data-appear-animation="fadeInRight">
						 </div>
					 </div>

					 <hr class="tall">

					<div class="row">
						 <div class="col-md-4">
							<img src="<?php echo base_url('public/img/lorem.jpg'); ?>" class="img-responsive appear-animation fadeInRight appear-animation-visible">
						 </div>
						 <div class="col-md-7 col-md-offset-1">
							 <h2 class="mt-xl"><strong>Lorem </strong>ipsum dolor sit amet </h2>
							 <p class="lead">
								Donec convallis a magna at interdum. Sed consequat dignissim risus. Praesent consectetur iaculis augue. Mauris a lacus tortor. Fusce quis libero et diam vulputate semper. Donec id porttitor neque. Vestibulum ante ipsum primis
							 </p>
							 <p>
								Donec convallis a magna at interdum. Sed consequat dignissim risus. Praesent consectetur iaculis augue. Mauris a lacus tortor. Fusce quis libero et diam vulputate semper. Donec id porttitor neque. Vestibulum ante ipsum primis
							 </p>
						 </div>
					 </div>
				 </div>
				
                
                <section class="parallax section section-text-light section-parallax section-center mt-none" data-stellar-background-ratio="0.5" style="background-image: url(&quot;http://preview.oklerthemes.com/porto/3.8.1/img/parallax-image.jpg&quot;); background-position: 0% -126.648px;">
					 <div class="container">
						 <div class="row">
							 
                          <div class="col-md-2 col-md-offset-1">

											 <h5 class="text-semibold text-uppercase mt-lg">Training <br/> Company </h5>
											 <span class="thumb-info thumb-info-hide-wrapper-bg">
												 <span class="thumb-info-wrapper">
													 <img src="<?php echo base_url('public/img/projects/project-4.jpg');?>" class="img-responsive" alt="">		 
												 </span>
												 <span class="thumb-info-caption">
													 <span class="thumb-info-caption-text">Lorem ipsum dolor </span>
													 <span class="thumb-info-social-icons">
														 <a target="_blank" href="http://www.facebook.com/"><i class="fa fa-facebook"></i><span>Facebook </span></a>
														 <a href="http://www.twitter.com/"><i class="fa fa-twitter"></i><span>Twitter </span></a>
														 <a href="http://www.linkedin.com/"><i class="fa fa-linkedin"></i><span>Linkedin </span></a>
													 </span>
												 </span>
											 </span>

										 </div>   
                                         
                                          <div class="col-md-2 ">

											 <h5 class="text-semibold text-uppercase mt-lg">Training Facilities Provider </h5>
											 <span class="thumb-info thumb-info-hide-wrapper-bg">
												 <span class="thumb-info-wrapper">
													 <img src="<?php echo base_url('public/img/projects/project-4.jpg');?>" class="img-responsive" alt="">
													 
												 </span>
												 <span class="thumb-info-caption">
													 <span class="thumb-info-caption-text">Lorem ipsum dolor </span>
													 <span class="thumb-info-social-icons">
														 <a target="_blank" href="http://www.facebook.com/"><i class="fa fa-facebook"></i><span>Facebook </span></a>
														 <a href="http://www.twitter.com/"><i class="fa fa-twitter"></i><span>Twitter </span></a>
														 <a href="http://www.linkedin.com/"><i class="fa fa-linkedin"></i><span>Linkedin </span></a>
													 </span>
												 </span>
											 </span>

										 </div>   
                                         
                                          <div class="col-md-2 ">

											 <h5 class="text-semibold text-uppercase mt-lg">Product Tools Provider </h5>
											 <span class="thumb-info thumb-info-hide-wrapper-bg">
												 <span class="thumb-info-wrapper">
													 <img src="<?php echo base_url('public/img/projects/project-4.jpg');?>" class="img-responsive" alt="">
												 </span>
												 <span class="thumb-info-caption">
													 <span class="thumb-info-caption-text">Lorem ipsum dolor</span>
													 <span class="thumb-info-social-icons">
														 <a target="_blank" href="http://www.facebook.com/"><i class="fa fa-facebook"></i><span>Facebook </span></a>
														 <a href="http://www.twitter.com/"><i class="fa fa-twitter"></i><span>Twitter </span></a>
														 <a href="http://www.linkedin.com/"><i class="fa fa-linkedin"></i><span>Linkedin </span></a>
													 </span>
												 </span>
											 </span>

										 </div>   
                                         
                                          <div class="col-md-2 ">

											 <h5 class="text-semibold text-uppercase mt-lg">Content <br/> Provider </h5>
											 <span class="thumb-info thumb-info-hide-wrapper-bg">
												 <span class="thumb-info-wrapper">
													 <img src="<?php echo base_url('public/img/projects/project-4.jpg');?>" class="img-responsive" alt="">
												 </span>
												 <span class="thumb-info-caption">
													 <span class="thumb-info-caption-text">Lorem ipsum dolor </span>
													 <span class="thumb-info-social-icons">
														 <a target="_blank" href="http://www.facebook.com/"><i class="fa fa-facebook"></i><span>Facebook </span></a>
														 <a href="http://www.twitter.com/"><i class="fa fa-twitter"></i><span>Twitter </span></a>
														 <a href="http://www.linkedin.com/"><i class="fa fa-linkedin"></i><span>Linkedin </span></a>
													 </span>
												 </span>
											 </span>

										 </div>   
                                         
                                          <div class="col-md-2 ">

											 <h5 class="text-semibold text-uppercase mt-lg">Professional <br/> Bodies </h5>
											 <span class="thumb-info thumb-info-hide-wrapper-bg">
												 <span class="thumb-info-wrapper">
													 <img src="<?php echo base_url('public/img/projects/project-4.jpg');?>" class="img-responsive" alt="">
												 </span>
												 <span class="thumb-info-caption">
													 <span class="thumb-info-caption-text">Lorem ipsum dolor </span>
													 <span class="thumb-info-social-icons">
														 <a target="_blank" href="http://www.facebook.com/"><i class="fa fa-facebook"></i><span>Facebook </span></a>
														 <a href="http://www.twitter.com/"><i class="fa fa-twitter"></i><span>Twitter </span></a>
														 <a href="http://www.linkedin.com/"><i class="fa fa-linkedin"></i><span>Linkedin </span></a>
													 </span>
												 </span>
											 </span>
										 </div>   
                             
						 </div>
					 </div>
                     
                     </section>
                     
                     
                     <div class="container">
                     
                     <h1>Featured <strong>Companies/Experts</strong></h1>
                     <div class="content-grid content-grid-dashed mt-xlg mb-lg">
										 <div class="col-md-3 content-grid-row">
											 <div class="content-grid-item col-md-12 center">
												 <img class="img-responsive" src="<?php echo base_url('public/img/resource1.jpg');?>" alt="">
											 </div>
											
											 <div class="content-grid-item col-md-12 center">
												 <img class="img-responsive" src="<?php echo base_url('public/img/resource2.jpg');?>" alt="">
											 </div>
                                              <div class="content-grid-item col-md-12 center">
												 <img class="img-responsive" src="<?php echo base_url('public/img/resource3.jpg');?>" alt="">
											 </div>
										 </div>
										 <div class="col-md-6 content-grid-row">
											
											 <div class="content-grid-item col-md-12 center">
												 <img class="img-responsive" src="<?php echo base_url('public/img/abc.jpg');?>" alt="">
											 </div>
										 </div>
										 <div class="col-md-3 content-grid-row">
											 <div class="content-grid-item col-md-12 center">
												 <img class="img-responsive" src="<?php echo base_url('public/img/resource1.jpg');?>" alt="">
											 </div>
											
											 <div class="content-grid-item col-md-12 center">
												<img class="img-responsive" src="<?php echo base_url('public/img/resource2.jpg');?>" alt="">
											 </div>
                                              <div class="content-grid-item col-md-12 center">
												 <img class="img-responsive" src="<?php echo base_url('public/img/resource3.jpg');?>" alt="">
											 </div>
										 </div>
									 </div>
                     <hr class="tall">
					 <h2>Latest From <strong>Our Blog  </strong></h2>

					
					

					 <div class="row">

						 <ul class="team-list sort-destination" data-sort-id="team" style="position: relative; height: 442px;">
							 <li class="col-md-3 col-sm-6 col-xs-12 isotope-item leadership" style="position: absolute; left: 0px; top: 0px;">
								 <span class="thumb-info thumb-info-hide-wrapper-bg mb-xlg">
									 <span class="thumb-info-wrapper">
										 <a href="./about-me.html">
											 <img src="img/resource1.jpg" class="img-responsive" alt="">
											 <span class="thumb-info-title">
												 <span class="thumb-info-inner">Corporate & Modern Languages </span>
												 <span class="thumb-info-type">by Anna Doe </span>
											 </span>
										 </a>
									 </span>
									 <span class="thumb-info-caption">
										 <span class="thumb-info-caption-text">Lorem ipsum xxxxx sit amet, xxxxxxxxxxx adipiscing elit. Xxxx ac ligula xx, non suscipitaccumsan. <a href="#" class="read-more pull-right">read more  <i class="fa fa-angle-right"></i></a> </span>
                                        
										 <span class="thumb-info-social-icons">
											 <a target="_blank" href="http://www.facebook.com/"><i class="fa fa-facebook"></i><span>Facebook </span></a>
											 <a href="http://www.twitter.com/"><i class="fa fa-twitter"></i><span>Twitter </span></a>
											 <a href="http://www.linkedin.com/"><i class="fa fa-linkedin"></i><span>Linkedin </span></a>
										 </span>
									 </span>
								 </span>
							 </li>
							 <li class="col-md-3 col-sm-6 col-xs-12 isotope-item marketing" style="position: absolute; left: 292px; top: 0px;">
								 <span class="thumb-info thumb-info-hide-wrapper-bg mb-xlg">
									 <span class="thumb-info-wrapper">
										 <a href="./about-me.html">
											 <img src="img/resource2.jpg" class="img-responsive" alt="">
											 <span class="thumb-info-title">
												 <span class="thumb-info-inner">Marketing & Statistics </span>
												 <span class="thumb-info-type">by Anna Doe </span>
											 </span>
										 </a>
									 </span>
									 <span class="thumb-info-caption">
										 <span class="thumb-info-caption-text">Lorem ipsum xxxxx sit amet, xxxxxxxxxxx adipiscing elit. Xxxx ac ligula xx, non suscipitaccumsan. <a href="#" class="read-more pull-right">read more  <i class="fa fa-angle-right"></i></a> </span>
										 <span class="thumb-info-social-icons">
											 <a target="_blank" href="http://www.facebook.com/"><i class="fa fa-facebook"></i><span>Facebook </span></a>
											 <a href="http://www.twitter.com/"><i class="fa fa-twitter"></i><span>Twitter </span></a>
											 <a href="http://www.linkedin.com/"><i class="fa fa-linkedin"></i><span>Linkedin </span></a>
										 </span>
									 </span>
								 </span>
							 </li>
							 <li class="col-md-3 col-sm-6 col-xs-12 isotope-item development" style="position: absolute; left: 585px; top: 0px;">
								 <span class="thumb-info thumb-info-hide-wrapper-bg mb-xlg">
									 <span class="thumb-info-wrapper">
										 <a href="./about-me.html">
											 <img src="img/resource3.jpg" class="img-responsive" alt="">
											 <span class="thumb-info-title">
												 <span class="thumb-info-inner">Sales & Modern Promotion </span>
												 <span class="thumb-info-type">by Anna Doe </span>
											 </span>
										 </a>
									 </span>
									 <span class="thumb-info-caption">
										 <span class="thumb-info-caption-text">Lorem ipsum xxxxx sit amet, xxxxxxxxxxx adipiscing elit. Xxxx ac ligula xx, non suscipitaccumsan. <a href="#" class="read-more pull-right">read more  <i class="fa fa-angle-right"></i></a> </span>
										 <span class="thumb-info-social-icons">
											 <a target="_blank" href="http://www.facebook.com/"><i class="fa fa-facebook"></i><span>Facebook </span></a>
											 <a href="http://www.twitter.com/"><i class="fa fa-twitter"></i><span>Twitter </span></a>
											 <a href="http://www.linkedin.com/"><i class="fa fa-linkedin"></i><span>Linkedin </span></a>
										 </span>
									 </span>
								 </span>
							 </li>
							 <li class="col-md-3 col-sm-6 col-xs-12 isotope-item design" style="position: absolute; left: 877px; top: 0px;">
								 <span class="thumb-info thumb-info-hide-wrapper-bg mb-xlg">
									 <span class="thumb-info-wrapper">
										 <a href="./about-me.html">
											 <img src="img/resource1.jpg" class="img-responsive" alt="">
											 <span class="thumb-info-title">
												 <span class="thumb-info-inner">Sales & Modern Promotion </span>
												 <span class="thumb-info-type">by Anna Doe </span>
											 </span>
										 </a>
									 </span>
									 <span class="thumb-info-caption">
										 <span class="thumb-info-caption-text">Lorem ipsum xxxxx sit amet, xxxxxxxxxxx adipiscing elit. Xxxx ac ligula xx, non suscipitaccumsan. <a href="#" class="read-more pull-right">read more  <i class="fa fa-angle-right"></i></a> </span>
										 <span class="thumb-info-social-icons">
											 <a target="_blank" href="http://www.facebook.com/"><i class="fa fa-facebook"></i><span>Facebook </span></a>
											 <a href="http://www.twitter.com/"><i class="fa fa-twitter"></i><span>Twitter </span></a>
											 <a href="http://www.linkedin.com/"><i class="fa fa-linkedin"></i><span>Linkedin </span></a>
										 </span>
									 </span>
								 </span>
							 </li>
							
						 </ul>

					 </div>

				 </div>
                     
             
			
             
 <section class="parallax section section-text-light section-parallax section-center mt-none" data-stellar-background-ratio="0.5" style="background-image: url(&quot;http://preview.oklerthemes.com/porto/3.8.1/img/parallax-image.jpg&quot;); background-position: 0% -171.648px;">
					 <div class="container">
						 <div class="row">
							 <div class="col-md-10 col-md-offset-1">
								 <div class="owl-carousel nav-bottom rounded-nav owl-theme owl-loaded owl-carousel-init" data-plugin-options="{&quot;items&quot;: 1, &quot;loop&quot;: false}">
									 
									 
								 <div class="owl-stage-outer" style="padding-left: 0px; padding-right: 0px;"><div class="owl-stage" style="width: 1890px; transform: translate3d(0px, 0px, 0px); transition: 0.25s;"><div class="owl-item active" style="width: 945px; margin-right: 0px;"><div>
										 <div class="col-md-12">
											 <div class="testimonial testimonial-style-2 testimonial-with-quotes mb-none">
												 <div class="testimonial-author">
													 <img src="<?php echo base_url();?>public/img/clients/client-1.jpg" class="img-responsive img-circle" alt="">
												 </div>
												 <blockquote>
													 <p>Lorem ipsum xxxxx sit amet, xxxxxxxxxxx adipiscing elit. Xxx eget risus xxxxx, tincidunt turpis xx, interdum tortor. Xxxxxxxxxxx potenti. Lorem xxxxx dolor sit xxxx, consectetur adipiscing xxxx. Cum sociis xxxxxxx penatibus et xxxxxx dis parturient xxxxxx, nascetur ridiculus xxx. Fusce ante xxxxxx, convallis non xxxxxxxxxxx sed, pharetra xxx ex. </p>
												 </blockquote>
												 <div class="testimonial-author">
													 <p><strong>John Smith </strong><span>CEO &amp; Xxxxxxx - Okler </span></p>
												 </div>
											 </div>
										 </div>
									 </div></div><div class="owl-item" style="width: 945px; margin-right: 0px;"><div>
										 <div class="col-md-12">
											 <div class="testimonial testimonial-style-2 testimonial-with-quotes mb-none">
												 <div class="testimonial-author">
													 <img src="<?php echo base_url();?>public/img/clients/client-1.jpg" class="img-responsive img-circle" alt="">
												 </div>
												 <blockquote>
													 <p>Lorem ipsum xxxxx sit amet, xxxxxxxxxxx adipiscing elit. Xxx eget risus xxxxx, tincidunt turpis xx, interdum tortor. Xxxxxxxxxxx potenti. Lorem xxxxx dolor sit xxxx, consectetur adipiscing xxxx. </p>
												 </blockquote>
												 <div class="testimonial-author">
													 <p><strong>John Smith </strong><span>CEO &amp; Xxxxxxx - Okler </span></p>
												 </div>
											 </div>
										 </div>
									 </div></div></div></div><div class="owl-controls"><div class="owl-nav"><div class="owl-prev" style="display: none;"></div><div class="owl-next" style="display: none;"></div></div><div class="owl-dots" style=""><div class="owl-dot active"><span></span></div><div class="owl-dot"><span></span></div></div></div></div>
							 </div>
						 </div>
					 </div>
				 </section>
<!-- Model -->
<button type="button" class="btn btn-warning btn-lg feed" data-toggle="modal" data-target="#defaultModal" data-direction='right'>Feedback </button>
<button type="button" class="btn btn-success btn-lg feed-1" data-toggle="modal" data-target="#defaultModalNew" data-direction='right'>Enquiry </button>
<?php echo $this->load->view('elements/feedback.php');?>
<?php echo $this->load->view('elements/user_job_posting.php');?>
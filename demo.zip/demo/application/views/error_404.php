<div role="main" class="main">
<section class="page-header" style="margin-top:122px">
	 <div class="container">
		 <div class="row">
			 <div class="col-md-12">
				 
			 </div>
		 </div>
		 <div class="row">
			 <div class="col-md-12">
				 <h1></h1>
			 </div>
		 </div>
	 </div>
 </section>
<div class="container">
	<section class="page-not-found">
		<div class="row">
			<div class="col-md-6 col-md-offset-1">
				<div class="page-not-found-main">
					<h2>404 <i class="fa fa-file"></i></h2>
					<p>We're sorry, but the page you were looking for doesn't exist.</p>
				</div>
			</div>
			<div class="col-md-4">
				<h4 class="heading-primary">Here are some useful links</h4>
				<ul class="nav nav-list">
					 <li><a href="<?php echo base_url();?>about-us">About Us </a></li>
					 <li> <a href="<?php echo base_url();?>vision">Vision </a></li>
					 <li><a href="<?php echo base_url();?>Why-Get-Me-Experts">Why Get Me Experts?</a></li>
					 <li><a href="<?php echo base_url();?>How-to-use">How it works?</a></li>
					 <li><a href="<?php echo base_url();?>Service-Provider">Service Provider </a></li>
					 <li><a href="<?php echo base_url();?>Add-your-business">Add Your Business</a></li>
					 <li><a href="<?php echo base_url();?>Benefits">Benefits</a></li>
					  <li><a href="<?php echo base_url();?>Terms-Conditions">Terms & Conditions</a></li>
					  <li><a href="<?php echo base_url();?>Privacy-Policy">Privacy Policy</a></li>
				</ul>
			</div>
		</div>
	</section>
</div>     
                     
                     
             
			
             
 
                 
			
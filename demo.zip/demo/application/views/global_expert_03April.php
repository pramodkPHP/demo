<?php ini_set('display_errors',0);?>
<?php if(isset($error)){?>
<div class="error close_div"><button type="button" class="close">�</button><?php echo $error; ?><br></div>
<?php }?>
<?php 
   @$success=$this->session->flashdata('success');
   if(@$success!=""){?>
<div class="success close_div" style="color:#4b8df8;"><button type="button" class="close">�</button><?php echo $success;?> </div>
<?php } ?>
<?php 
   @$error=$this->session->flashdata('error');
   if(@$error!=""){?>
<div class="error close_div" style="color:#4b8df8;"><button type="button" class="close">�</button><?php echo $error;?> </div>
<?php } ?>
<style>
   .expert
   {
   font-size: 15px;
   color: #fff;
   padding-top: 29px;
   position: relative;
   float:right;
   margin-bottom: 0px;	
   }
   .expert a
   {
   color:#fff !important;
   }
   .mb-sm-1
   {
   margin-bottom: 40px !important;
   margin-top: 0px;
   color: #fff;
   font-size: 3.6em;	
   }
</style>
<div role="main" class="main">
<div class="slider-container">
   <div class="section section-3">
      <div class="home-concept" style="padding-top:170px;">
         <div class="row center" >
            <div class="row">
              <h1 class="mb-sm-1">Be A Global Expert</h1>
            </div>
             
                <!-- My New Slider Start Here  -->
           <div class="row">
			<div class="col-md-12">
    	    	
                <div id="myCarousel" class="carousel slide">
                 
                <ol class="carousel-indicators">
                    <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
                    <li data-target="#myCarousel" data-slide-to="1"></li>
                   
                </ol>
                 
                <!-- Carousel items -->
                <div class="carousel-inner">
                    
                <div class="item active">
                	<div class="col-md-12  ">
                	  <div class="col-md-2 col-md-offset-1 col-sm-4 col-xs-6"> 
                      
                      <a href="<?php echo base_url();?>supplier/expert/consultant">
                     <img src="<?php echo base_url('public/img/head-section/consultant.png'); ?>" alt="" />
                     </a>
                     
                     <a href="<?php echo base_url();?>supplier/expert/trainers">
                     <img src="<?php echo base_url('public/img/head-section/trainers.png'); ?>" alt="" />
                     </a>
                     
                     </div>
                      
                	  <div class="col-md-2 col-sm-4 col-xs-6">
                       <a href="<?php echo base_url();?>supplier/expert/<?php echo urlencode('subject experts');?>">
                     <img src="<?php echo base_url('public/img/head-section/subject.png'); ?>" alt="" />
                     </a>
                      
                       <a href="<?php echo base_url();?>supplier/expert/counsellor">
                     <img src="<?php echo base_url('public/img/head-section/counsellor.png'); ?>" alt="" />
                     </a>
                     
                      </div>
                     
                	  <div class="col-md-2 col-sm-4 col-xs-6">
                     <a href="<?php echo base_url();?>supplier/expert/innovators">
                     <img src="<?php echo base_url('public/img/head-section/innovators.png'); ?>" alt="" />
                     </a>
                      <a href="<?php echo base_url();?>supplier/expert/coach">
                     <img src="<?php echo base_url('public/img/head-section/coach.png'); ?>" alt="" />
                     </a>
                      </div>
                     
                	 <div class="col-md-2 col-sm-4 col-xs-6">
                     <a href="<?php echo base_url();?>supplier/expert/researcher">
                     <img src="<?php echo base_url('public/img/head-section/research.png'); ?>" alt="" />
                     </a>
                       <a href="<?php echo base_url();?>supplier/expert/mentor">
                     <img src="<?php echo base_url('public/img/head-section/mentor.png'); ?>" alt="" />
                     </a>
                     </div>
                     <div class="col-md-2 col-sm-4 col-xs-6">
                         <a href="<?php echo base_url();?>supplier/expert/<?php echo urlencode('Keynotes Speakers');?>">
                     <img src="<?php echo base_url('public/img/head-section/keynote.png'); ?>" alt="" />
                     </a>
                          <a href="<?php echo base_url();?>supplier/expert/<?php echo urlencode('visiting faculty');?>">
                     <img src="<?php echo base_url('public/img/head-section/faculty.png'); ?>" alt="" />
                     </a>
                         </div>
                     
                	</div><!--/row-fluid-->
                </div><!--/item-->
                 
                <div class="item">
                	<div class="col-md-12  ">
                		 
                        
                		 <div class="col-md-2 col-md-offset-1 col-sm-4 col-xs-6">
                         <a href="<?php echo base_url();?>supplier/expert/innovators">
                     <img src="<?php echo base_url('public/img/head-section/innovators.png'); ?>" alt="" />
                     </a>
                         <a href="<?php echo base_url();?>supplier/expert/coach">
                     <img src="<?php echo base_url('public/img/head-section/coach.png'); ?>" alt="" />
                     </a>
                         </div>
                        
                		 <div class="col-md-2 col-sm-4 col-xs-6">
                          <a href="<?php echo base_url();?>supplier/expert/consultant">
                     <img src="<?php echo base_url('public/img/head-section/consultant.png'); ?>" alt="" />
                     </a>
                        <a href="<?php echo base_url();?>supplier/expert/trainers">
                     <img src="<?php echo base_url('public/img/head-section/trainers.png'); ?>" alt="" />
                     </a>
                         </div>
                        
                		 <div class="col-md-2 col-sm-4 col-xs-6">
                          <a href="<?php echo base_url();?>supplier/expert/<?php echo urlencode('Keynotes Speakers');?>">
                     <img src="<?php echo base_url('public/img/head-section/keynote.png'); ?>" alt="" />
                     </a>
                        <a href="<?php echo base_url();?>supplier/expert/<?php echo urlencode('visiting faculty');?>">
                     <img src="<?php echo base_url('public/img/head-section/faculty.png'); ?>" alt="" />
                     </a>
                         </div>
                         
                         
                          <div class="col-md-2 col-sm-4 col-xs-6">
                         <a href="<?php echo base_url();?>supplier/expert/<?php echo urlencode('subject experts');?>">
                     <img src="<?php echo base_url('public/img/head-section/subject.png'); ?>" alt="" />
                     </a>
                         <a href="<?php echo base_url();?>supplier/expert/counsellor">
                     <img src="<?php echo base_url('public/img/head-section/counsellor.png'); ?>" alt="" />
                     </a>
                         </div>
                         
                          <div class="col-md-2 col-sm-4 col-xs-6">
                          <a href="<?php echo base_url();?>supplier/expert/<?php echo urlencode('Keynotes Speakers');?>">
                     <img src="<?php echo base_url('public/img/head-section/keynote.png'); ?>" alt="" />
                     </a>
                        <a href="<?php echo base_url();?>supplier/expert/<?php echo urlencode('visiting faculty');?>">
                     <img src="<?php echo base_url('public/img/head-section/faculty.png'); ?>" alt="" />
                     </a>
                         </div>
                        
                	</div><!--/row-fluid-->
                </div><!--/item-->
                 
               
                 
                </div><!--/carousel-inner-->
                 
                <a class="left carousel-control" href="#myCarousel" data-slide="prev">&lt;</a>
                <a class="right carousel-control" href="#myCarousel" data-slide="next">&gt;</a>
                </div><!--/myCarousel-->
                 
            
		</div>
	</div> 
            
            
            
            
           <!-- My New Slider End Here  -->   
               
               
         </div>
         
      </div>
   </div>
</div>


<div class="home-intro " id="home-intro">
   <div class="container">
      <div class="row">
         <div class="col-md-2">
        
            <a href="<?php echo base_url();?>supplier/expert/<?php echo urlencode('make in india');?>" class="btn btn-tertiary btn-block btn-lg" >
         Make in India
            </a>	
         </div>
         <div class="col-md-2">
            <a href="<?php echo base_url();?>supplier/expert/<?php echo urlencode('skill india mission');?>" class="btn btn-tertiary btn-block btn-lg" >
            Skill India 
            </a>		
         </div>
         <div class="col-md-2">
            <a href="#" class="btn btn-tertiary btn-block btn-lg" >
           Digital India
            </a>		
         </div>
         <div class="col-md-2">
            <a href="#" class="btn btn-tertiary btn-block btn-lg" >	
             Innovation
              
             </a>
         </div>
          <div class="col-md-2">
            <a href="#" class="btn btn-tertiary btn-block btn-lg" >	
            Swachh Bharat
              
             </a>
         </div>
          <div class="col-md-2">
            <a href="#" class="btn btn-tertiary btn-block btn-lg" >	
          Start Up India
              
             </a>
         </div>
      </div>
   </div>
</div>

<div class="container" id="How-it-works" style="padding-top:50px;">
   
   
   <div class="row" id="creat-account" >
      <div class="col-md-8 my-section">
         <h2 class="mt-xl">Why <strong>Join Us </strong></h2>
         <div class="featured-boxes featured-boxes-style-5">
            <div class="row">
               <div class="col-md-4">
                  <div class="featured-box featured-box-quaternary featured-box-effect-4" style="height: 194px;">
                     <div class="box-content">
                        <i class="icon-featured fa fa-bookmark text-center"></i>
                        <h4 class="text-center">Create personal<br/> brand online</h4>
                     </div>
                  </div>
               </div>
               <div class="col-md-4">
                  <div class="featured-box featured-box-secondary featured-box-effect-4" style="height: 194px;">
                     <div class="box-content">
                        <i class="icon-featured fa fa-bookmark"></i>
                        <h4 class="text-center">Promote your Expertise at social media</h4>
                     </div>
                  </div>
               </div>
               <div class="col-md-4">
                  <div class="featured-box featured-box-tertiary featured-box-effect-4" style="height: 194px;">
                     <div class="box-content">
                        <i class="icon-featured fa fa-bookmark"></i>
                        <h4 class="text-center">Connect with Global Experts Community</h4>
                     </div>
                  </div>
               </div>
               <div class="col-md-4">
                  <div class="featured-box featured-box-quaternary featured-box-effect-4" style="height: 194px;">
                     <div class="box-content">
                        <i class="icon-featured fa fa-bookmark"></i>
                        <h4 class="text-center">Get new Business Opportunities</h4>
                     </div>
                  </div>
               </div>
               <div class="col-md-4">
                  <div class="featured-box featured-box-tertiary featured-box-effect-4" style="height: 194px;">
                     <div class="box-content">
                        <i class="icon-featured fa fa-bookmark"></i>
                        <h4 class="text-center">Get paid for Audio/Video<br/> Call Advise</h4>
                     </div>
                  </div>
               </div>
               <div class="col-md-4">
                  <div class="featured-box featured-box-quaternary featured-box-effect-4" style="height: 194px;">
                     <div class="box-content">
                        <i class="icon-featured fa fa-bookmark"></i>
                        <h4 class="text-center">Option to Consult without sharing your identity</h4>
                     </div>
                  </div>
               </div>
               <div class="col-md-4">
                  <div class="featured-box featured-box-secondary featured-box-effect-4" style="height: 194px;">
                     <div class="box-content">
                        <i class="icon-featured fa fa-bookmark"></i>
                        <h4 class="text-center">Read & Write Blogs on Expertise areas</h4>
                     </div>
                  </div>
               </div>
               <div class="col-md-4">
                  <div class="featured-box featured-box-tertiary featured-box-effect-4" style="height: 194px;">
                     <div class="box-content">
                        <i class="icon-featured fa fa-bookmark"></i>
                        <h4 class="text-center">Get access to Industry Reports, Presentations & Analytics</h4>
                     </div>
                  </div>
               </div>
               <div class="col-md-4">
                  <div class="featured-box featured-box-quaternary featured-box-effect-4" style="height: 194px;">
                     <div class="box-content">
                        <i class="icon-featured fa fa-bookmark"></i>
                        <h4 class="text-center">Be available to Media & Events Organisers</h4>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <div class="col-md-3 col-md-offset-1 my-form-here mt-xl">
         <div class="featured-boxes mt-none mb-none">
            <div class="featured-box featured-box-primary mt-xl">
               <div class="box-content search-event">
                  <h3 class="mb-none" style="font-size: 1.6em;">Make Your Account</h3>
                  <hr/>
                  <span id="supplier_status" style="display: none;"><img src="<?php echo base_url();?>/public/img/<?php echo AJAX_LOADER;?>"></span>
                  <div class="message error" id="supplier_Error" style="display:none;"></div>
                  <div class="message success" id="supplier_Success" style="display:none;"></div>
                  <form id="supplier_form" class="form-horizontal mb-lg" action="<?php echo base_url('index.php/users/register'); ?>" novalidate method="post"/>
                     <div class="form-group mt-lg">
                       
                        <div class="col-sm-12">
                           <input type="text" name="name" name="name" class="form-control" placeholder="Type your name..." required/="" />
                        </div>
                     </div>
                     <div class="form-group  mb-lg">
                      
                        <div class="col-sm-12">
                           <input type="text" name="email" id="email" class="form-control" placeholder="Type your email..." required/="" />
                        </div>
                     </div>
                     <div class="form-group  mb-lg">
                       
                        <div class="col-sm-12">
                            <input type="password" name="password" id="password" class="form-control" placeholder="Password" />
                        </div>
                     </div>
                     <div class="form-group  mb-lg">
                       
                        <div class="col-sm-12">
                           <input type="password" name="confirm_password" id="confirm_password" class="form-control" placeholder="Confirm Password" />
                        </div>
                     </div>
                     <div class="form-group  mb-lg">
                       
                        <div class="col-sm-7">
                         <select class="form-control" name="firm_type" id="firm_type">
                            <option selected="selected">Select Firm Type</option>
							<option value="0">Individual</option>
							<option value="1">Organisation</option>
                     	</select>
                        </div>
                        <div class="col-sm-5">
							<input type="hidden" name="user_type" id="user_type" value="1"/>
							<input type="submit" name="submit" value="submit" class="btn btn-primary  pull-right" />
                           <!--<button type="button" class="btn btn-primary btn-lg pull-right">Submit </button>	-->
                        </div>
                     </div>
                  </form>
               </div>
            </div>
         </div>
      </div>
   </div>
   
</div>

<!-- Model -->
<button type="button" class="btn btn-success  feed-1" data-toggle="modal" data-target="#defaultModalNew" data-direction='right'>Enquiry </button>
<?php echo $this->load->view('elements/feedback.php');?>
<?php echo $this->load->view('elements/inquiry.php');?>
<script type="text/javascript">
   $(document).ready(function(e){
   	$("#supplier_form").validate({
   	rules: {
   		name: "required",
   		email: {
   			required: true,
   			email: true
   		},
   		password: {
   				required:true,
   				minlength:6
   		},		
   		confirm_password: {
   					required:true,
   					minlength:6
   					//equalTo:'#password'
   		}
   	},
   	messages: {
   		name: "Please enter your name",
   		email: "Please enter a valid email address",
   		password: "Please enter password minimum 6 character",
   		confirm_password: "Confirm Password should be equal to password"
   	},
   	submitHandler: function(form) {
   		// Setup form validation on the #register-form element
   		form = $("#supplier_form").serialize();
   		base_url='<?php echo base_url();?>';
   		$.ajax({
   		   url: base_url + 'users/register/' + new Date().getTime(),
   		   data: form,
   		   type: "POST",
   		   cache: false,
   		   beforeSend:function(){
   			   $('#supplier_status').show();
   		   },
   		   success: function(response) {
   			   try {
   				   $('#supplier_status').hide();
   				   if(response=='Success'){
   					   	   $('#supplierr_Error').hide();
   						   $('#supplier_Success').show();
   						   $('#supplier_Success').html('Thanks for registering with our expert training, Please check mail to login!');
   						   //window.location.reload();
   				   }else{
   					   $('#supplier_Success').hide();
   					   $('#supplier_Error').show();
   					   $('#supplier_Error').html(response);
   				   }
   			   } catch (e) {
   				   return false;
   			   }
   		   },
       		error: function(response){
       		   $('#register_Success').hide();
   			   $('#register_Error').show();
   			   $('#register_Error').html('Email is already exists, Please try another email');
       	   	}
   		 });
   		 return false;        
      }
   });
   });
</script>
<?php //ini_set('display_errors',0);?>
<?php if(isset($error)){?>
<div class="error close_div"><button type="button" class="close">�</button><?php echo $error; ?><br></div>
<?php }?>
<?php 
   @$success=$this->session->flashdata('success');
   if(@$success!=""){?>
<div class="success close_div" style="color:#4b8df8;"><button type="button" class="close">�</button><?php echo $success;?> </div>
<?php } ?>
<?php 
   @$error=$this->session->flashdata('error');
   if(@$error!=""){?>
<div class="error close_div" style="color:#4b8df8;"><button type="button" class="close">�</button><?php echo $error;?> </div>
<?php } ?>
<style>
   .expert
   {
   font-size: 15px;
   color: #fff;
   padding-top: 29px;
   position: relative;
   float:right;
   margin-bottom: 0px;	
   }
   .expert a
   {
   color:#fff !important;
   }
   .mb-sm-1
   {
   margin-bottom: 40px !important;
   margin-top: 0px;
   color: #fff;
   font-size: 3.6em;	
   }
</style>
<div role="main" class="main">
<div class="slider-container">
   <div class="section section-3">
      <div class="home-concept" style="padding-top:120px;">
         <div class="row center" >
            <div class="row" >
               <div class="col-md-5 col-md-offset-4">
                  <p class="expert"> </p>
               </div>
            </div>
            <div class="row" >
               <h1 class="mb-sm-1">
                  Find the Best <b>EXPERTS</b>
               </h1>
            </div>
            
            <!-- My New Slider Start Here  -->
           <div class="row">
			<div class="col-md-12">
    	    	
                <div id="myCarousel" class="carousel slide">
                 
                <ol class="carousel-indicators">
                    <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
                    <li data-target="#myCarousel" data-slide-to="1"></li>
                   
                </ol>
                 
                <!-- Carousel items -->
                <div class="carousel-inner">
                    
                <div class="item active">
                	<div class="col-md-12  ">
                	  <div class="col-md-2 col-md-offset-1 col-sm-4 col-xs-6"> 
                      
                      <a href="<?php echo base_url();?>supplier/expert/consultant">
                     <img src="<?php echo base_url('public/img/head-section/consultant.png'); ?>" alt="" />
                     </a>
                     
                     <a href="<?php echo base_url();?>supplier/expert/trainer">
                     <img src="<?php echo base_url('public/img/head-section/trainers.png'); ?>" alt="" />
                     </a>
                     
                     </div>
                      
                	  <div class="col-md-2 col-sm-4 col-xs-6">
                       <a href="<?php echo base_url();?>supplier/expert/<?php echo urlencode('subject expert');?>">
                     <img src="<?php echo base_url('public/img/head-section/subject.png'); ?>" alt="" />
                     </a>
                      
                       <a href="<?php echo base_url();?>supplier/expert/counsellor">
                     <img src="<?php echo base_url('public/img/head-section/counsellor.png'); ?>" alt="" />
                     </a>
                     
                      </div>
                     
                	  <div class="col-md-2 col-sm-4 col-xs-6">
                     <a href="<?php echo base_url();?>supplier/expert/innovator">
                     <img src="<?php echo base_url('public/img/head-section/innovators.png'); ?>" alt="" />
                     </a>
                      <a href="<?php echo base_url();?>supplier/expert/coach">
                     <img src="<?php echo base_url('public/img/head-section/coach.png'); ?>" alt="" />
                     </a>
                      </div>
                     
                	 <div class="col-md-2 col-sm-4 col-xs-6">
                     <a href="<?php echo base_url();?>supplier/expert/researcher">
                     <img src="<?php echo base_url('public/img/head-section/research.png'); ?>" alt="" />
                     </a>
                       <a href="<?php echo base_url();?>supplier/expert/mentor">
                     <img src="<?php echo base_url('public/img/head-section/mentor.png'); ?>" alt="" />
                     </a>
                     </div>
                     <div class="col-md-2 col-sm-4 col-xs-6">
                         <a href="<?php echo base_url();?>supplier/expert/<?php echo urlencode('Keynotes Speaker');?>">
                     <img src="<?php echo base_url('public/img/head-section/keynote.png'); ?>" alt="" />
                     </a>
                          <a href="<?php echo base_url();?>supplier/expert/<?php echo urlencode('visiting faculty');?>">
                     <img src="<?php echo base_url('public/img/head-section/faculty.png'); ?>" alt="" />
                     </a>
                         </div>
                     
                	</div><!--/row-fluid-->
                </div><!--/item-->
                 
                <div class="item">
                	<div class="col-md-12  ">
                		 
                        
                		 <div class="col-md-2 col-md-offset-1 col-sm-4 col-xs-6">
                         <a href="<?php echo base_url();?>supplier/expert/innovator">
                     		<img src="<?php echo base_url('public/img/head-section/innovators.png'); ?>" alt="" />
                     	</a>
                         <a href="<?php echo base_url();?>supplier/expert/coach">
                     <img src="<?php echo base_url('public/img/head-section/coach.png'); ?>" alt="" />
                     </a>
                         </div>
                        
                		 <div class="col-md-2 col-sm-4 col-xs-6">
                          <a href="<?php echo base_url();?>supplier/expert/consultant">
                     <img src="<?php echo base_url('public/img/head-section/consultant.png'); ?>" alt="" />
                     </a>
                        <a href="<?php echo base_url();?>supplier/expert/trainer">
                     <img src="<?php echo base_url('public/img/head-section/trainers.png'); ?>" alt="" />
                     </a>
                         </div>
                        
                		 <div class="col-md-2 col-sm-4 col-xs-6">
                          <a href="<?php echo base_url();?>supplier/expert/<?php echo urlencode('Keynotes Speaker');?>">
                     <img src="<?php echo base_url('public/img/head-section/keynote.png'); ?>" alt="" />
                     </a>
                        <a href="<?php echo base_url();?>supplier/expert/<?php echo urlencode('visiting faculty');?>">
                     <img src="<?php echo base_url('public/img/head-section/faculty.png'); ?>" alt="" />
                     </a>
                         </div>
                         
                         
                          <div class="col-md-2 col-sm-4 col-xs-6">
                         <a href="<?php echo base_url();?>supplier/expert/<?php echo urlencode('subject expert');?>">
                     <img src="<?php echo base_url('public/img/head-section/subject.png'); ?>" alt="" />
                     </a>
                         <a href="<?php echo base_url();?>supplier/expert/counsellor">
                     <img src="<?php echo base_url('public/img/head-section/counsellor.png'); ?>" alt="" />
                     </a>
                         </div>
                         
                          <div class="col-md-2 col-sm-4 col-xs-6">
                          <a href="<?php echo base_url();?>supplier/expert/<?php echo urlencode('Keynotes Speaker');?>">
                     <img src="<?php echo base_url('public/img/head-section/keynote.png'); ?>" alt="" />
                     </a>
                        <a href="<?php echo base_url();?>supplier/expert/<?php echo urlencode('visiting faculty');?>">
                     <img src="<?php echo base_url('public/img/head-section/faculty.png'); ?>" alt="" />
                     </a>
                         </div>
                        
                	</div><!--/row-fluid-->
                </div><!--/item-->
                 
               
                 
                </div><!--/carousel-inner-->
                 
                <a class="left carousel-control" href="#myCarousel" data-slide="prev">&lt;</a>
                <a class="right carousel-control" href="#myCarousel" data-slide="next">&gt;</a>
                </div><!--/myCarousel-->
                 
            
		</div>
	</div> 
            
            
            
            
           <!-- My New Slider End Here  --> 
            
         </div>
         
      </div>
   </div>
</div>
<div class="home-intro " id="home-intro">
   <div class="container">
      <div class="row">
	  <?php $experties = $CI->get_option('Experts');
	  		if(isset($experties) && !empty($experties)){
				foreach($experties as $key=>$value){
					if($value->expert_group == '1'){?>
         			<div class="col-md-2">
            			<a href="<?php echo base_url();?>supplier/expert/<?php echo urlencode($value->type);?>" class="btn btn-tertiary btn-block btn-lg">
							<?php echo $value->type;?>
						</a>	
         			</div>
		<?php }}}?>
      </div>
   </div>
</div>
<div class="container" id="How-it-works" style="padding-top:60px; padding-bottom:60px;">
    <div class="row" >
    <h2 style="background: #F8B82A; width: 30%; margin-left: 37%;" class="mt-xl text-center"><strong>How it works </strong> </h2>
						 <div class="col-md-5 col-md-offset-1">
						 
						
                          <img src="<?php echo base_url('public/img/head-section/h1.png'); ?>" alt="" class="center-block" style="height: 160px; margin-bottom: 40px;" />
														<div class="feature-box">
										 <div class="feature-box-icon">
											 <i class="fa">1</i>
										 </div>
										 <div class="feature-box-info">
											 <h4 class="heading-primary mb-none">Find an Expert. </h4>
											 <ol type="a">
											 <li>Browse through our list of experts to find the suitable expert .</li>
											 <li>Post an enquiry and we will find suitable experts for you.   </li>
											 </ol>
										 </div>
									 </div>
									 <div class="feature-box">
										 <div class="feature-box-icon">
											 <i class="fa">2</i>
										 </div>
										 <div class="feature-box-info">
											 <h4 class="heading-primary mb-none">Request a Call</h4>
											 <p class="tall">Select 3 date and time which you are convenient with. You will be pre-charged
for the estimated length of call based on expert&acute;s per minute rate. </p>
										 </div>
									 </div>
									 
									 <div class="feature-box">
										 <div class="feature-box-icon">
											 <i class="fa">3</i>
										 </div>
										 <div class="feature-box-info">
											 <h4 class="heading-primary mb-none">Get Connected</h4>
											 <p class="tall">Connect on call with the expert to get your query solved. </p>
										 </div>
									 </div>
						 </div>
						 <div class="col-md-5 col-md-offset-1">
						  <img src="<?php echo base_url('public/img/head-section/h2.png'); ?>" alt=""  class="center-block" style="height: 160px; margin-bottom: 40px;" />
						
							<div class="feature-box">
										 <div class="feature-box-icon">
											 <i class="fa">1</i>
										 </div>
										 <div class="feature-box-info">
											 <h4 class="heading-primary mb-none">Post Your Project </h4>
											 <p>Describe your project and tell us the functional area and service you require</p>
										 </div>
									 </div>
									 <div class="feature-box">
										 <div class="feature-box-icon">
											 <i class="fa">2</i>
										 </div>
										 <div class="feature-box-info">
											 <h4 class="heading-primary mb-none">Choose the Best Expert.</h4>
											 <p class="tall">We will find the suitable experts for you and you can choose amongst them. </p>
										 </div>
									 </div>
									 
									 <div class="feature-box">
										 <div class="feature-box-icon">
											 <i class="fa">3</i>
										 </div>
										 <div class="feature-box-info">
											 <h4 class="heading-primary mb-none">Collaborate</h4>
											 <p class="tall">Once you choose the expert you can start working with them. </p>
										 </div>
									 </div>
									 
									  <div class="feature-box">
										 <div class="feature-box-icon">
											 <i class="fa">4</i>
										 </div>
										 <div class="feature-box-info">
											 <h4 class="heading-primary mb-none">Pay</h4>
											 <p class="tall">Payment as per the T&C of the expert. </p>
										 </div>
									 </div>
									 
									 
									 
									 
						 </div>
					 </div>
  
   
   <hr class="tall">
   <div class="row">
      <div class="col-md-4">
         <img src="<?php echo base_url('public/img/lorem.jpg'); ?>" class="img-responsive appear-animation fadeInRight appear-animation-visible">
      </div>
      <div class="col-md-7 col-md-offset-1">
       <!--  <h2 class="mt-xl">Why <strong>GME</strong> (User Page) </h2>-->
         <div class="feature-box">
										 <div class="feature-box-icon">
											<i class="fa fa-chevron-right"></i>
										 </div>
										 <div class="feature-box-info">
											 <h4 class="heading-primary mb-none">Expertise on Demand</h4>
											 <p class="tall">Every business needs experts in different areas to help them grow. But hiring a full time expert 
may not be required frequently. Get quick and easy access to experts in relevant area. </p>
										 </div>
									 </div>
                                     
                                     <div class="feature-box">
										 <div class="feature-box-icon">
											 <i class="fa fa-chevron-right"></i>
										 </div>
										 <div class="feature-box-info">
											 <h4 class="heading-primary mb-none">Professional Advice</h4>
											 <p class="tall">Get expert advice is the subject matter you require. </p>
										 </div>
									 </div>
                                     
                                     <div class="feature-box">
										 <div class="feature-box-icon">
											<i class="fa fa-chevron-right"></i>
										 </div>
										 <div class="feature-box-info">
											 <h4 class="heading-primary mb-none">Value for Money</h4>
											 <p class="tall">Hiring a full time expert may not be a cost effective mode. Pay for only those services that you 

require and not for anything else. </p>
										 </div>
									 </div>
                                     
                                     <div class="feature-box">
										 <div class="feature-box-icon">
											<i class="fa fa-chevron-right"></i>
										 </div>
										 <div class="feature-box-info">
											 <h4 class="heading-primary mb-none">Save Time</h4>
											 <p class="tall">We help you to reduce your discomfort in finding a good expert. Save time by getting the advice

sitting at your own place. </p>
										 </div>
									 </div>
                                     
                                     <div class="feature-box">
										 <div class="feature-box-icon">
											 <i class="fa fa-chevron-right"></i>
										 </div>
										 <div class="feature-box-info">
											 <h4 class="heading-primary mb-none">Quality</h4>
											 <p class="tall">We ensure the quality of experts by rating them for their service. </p>
										 </div>
									 </div>
                                     <p>You can connect with an expert of any sector/industry, in any location and for any duration. You just 

have to share your requirement with us and we will provide you with the expert of your choice.</p>
      </div>
   </div>
</div>
<section class="parallax section section-text-light section-parallax section-center mt-none" data-stellar-background-ratio="0.5" style="background-image: url(&quot;http://preview.oklerthemes.com/porto/3.8.1/img/parallax-image.jpg&quot;); background-position: 0% -126.648px;     padding: 50px 0 50px 0;">
   <div class="container">
      <div class="row">
      <h2 class="text-center">Resources</h2>
         <div class="col-md-2 ">
            <span class="thumb-info thumb-info-hide-wrapper-bg">
            <span class="thumb-info-wrapper">
          	<a href="<?php echo base_url();?>supplier/resource/<?php echo urlencode('training company');?>"><i class="fa fa-puzzle-piece fa-4x"></i></a>
            </span>
            <span class="thumb-info-caption">
            <span class="thumb-info-caption-text">
				<a href="<?php echo base_url();?>supplier/resource/<?php echo urlencode('training company');?>">Training Company</a>
            </span>
            </span>
			</span>
         </div>
         <div class="col-md-2 ">
            <span class="thumb-info thumb-info-hide-wrapper-bg">
            <span class="thumb-info-wrapper">
            <a href="<?php echo base_url();?>supplier/resource/<?php echo urlencode('Training Services Provider');?>"><i class="fa fa-crosshairs fa-4x"></i></a>
            </span>
            <span class="thumb-info-caption">
            <span class="thumb-info-caption-text">
				<a href="<?php echo base_url();?>supplier/resource/<?php echo urlencode('Training Services Provider');?>">Training Services Provider</a>
			</span>
            </span>
            </span>
         </div>
         <div class="col-md-2 ">
            <span class="thumb-info thumb-info-hide-wrapper-bg">
            <span class="thumb-info-wrapper">
           	<a href="<?php echo base_url();?>supplier/resource/<?php echo urlencode('Product Tools Provider');?>"><i class="fa fa-cogs fa-4x"></i></a>
            </span>
            <span class="thumb-info-caption">
            <span class="thumb-info-caption-text">
			<a href="<?php echo base_url();?>supplier/resource/<?php echo urlencode('Product Tools Provider');?>">Product Tools Provider</a>
			</span>
            </span>
            </span>
         </div>
         <div class="col-md-2 ">
            <span class="thumb-info thumb-info-hide-wrapper-bg">
            <span class="thumb-info-wrapper">
           	<a href="<?php echo base_url();?>supplier/resource/<?php echo urlencode('Content Provider');?>"><i class="fa fa-pencil-square-o fa-4x"></i></a>
            </span>
            <span class="thumb-info-caption">
            <span class="thumb-info-caption-text">
				<a href="<?php echo base_url();?>supplier/resource/<?php echo urlencode('Content Provider');?>">Content Provider</a>
			 </span>
            </span>
            </span>
         </div>
         <div class="col-md-2 ">
            
            <span class="thumb-info thumb-info-hide-wrapper-bg">
            <span class="thumb-info-wrapper">
          	<a href="<?php echo base_url();?>supplier/resource/<?php echo urlencode('Professional Bodies');?>"><i class="fa fa-code-fork fa-4x"></i></a>
            </span>
            <span class="thumb-info-caption">
            <span class="thumb-info-caption-text">
			<a href="<?php echo base_url();?>supplier/resource/<?php echo urlencode('Professional Bodies');?>">Professional Bodies</a></span>
            </span>
            </span>
         </div>
         
         <div class="col-md-2 ">
            <span class="thumb-info thumb-info-hide-wrapper-bg">
            <span class="thumb-info-wrapper">
          	<a href="<?php echo base_url();?>supplier/resource/<?php echo urlencode('R&D Labs on lease');?>"><i class="fa fa-flask fa-4x"></i></a></span>
            <span class="thumb-info-caption">
            <span class="thumb-info-caption-text">
			<a href="<?php echo base_url();?>supplier/resource/<?php echo urlencode('R&D Labs on lease');?>">R&D Labs on lease</a></span>
            </span>
            </span>
         </div>
      </div>
   </div>
</section>
<hr class="tall">
<div class="container">
 <h1><strong>I wanna know</strong></h1>
 <div class="row">
	 <div class="col-md-7" style="background: #e5e5e5;">
		<ul id="news">
		<?php if(isset($questions) && !empty($questions)){
				foreach($questions as $key=>$value){?>
				<li class="item1" style="width:534px;">
					<img src="http://placehold.it/75x75"/><p><h5><?php echo $value['title'];?></h5></p>
					<p><?php echo $value['content'];?>
						<a href="#" class="lnk-tertiary learn-more pull-right" data-toggle="modal" data-target="#smallModal">View more<i class="fa fa-angle-right"></i></a>
					</p>
				</li>
			<?php }}?>
		</ul>
	 </div>
	 <div class="col-md-4 col-md-offset-1 mt-xl">
		  <img src="<?php echo base_url('public/img/a11.png'); ?>" class="img-responsive appear-animation fadeInRight appear-animation-visible" style="margin-top:-85px;">
	 </div>
 </div>
 
 </div>

<!--<button type="button" class="btn btn-warning btn-lg feed" data-toggle="modal" data-target="#defaultModal" data-direction='right'>Feedback </button>-->
<a href="<?php echo base_url();?>home/global_expert" style="color:#fff !important" class="btn btn-success feed-99">Be A Global Expert</a>
<button type="button" class="btn btn-success  feed-1" data-toggle="modal" data-target="#defaultModalNew" data-direction='right'>Enquiry </button>
<?php echo $CI->partial('elements/feedback.php');?>
<?php echo $CI->partial('elements/inquiry.php');?>

<script type="text/javascript">
$(document).ready(function() {
    $('#myCarousel').carousel({
	    interval: 600000
	})
});

 
</script>

<script type="text/javascript">
   $(document).ready(function(e){
   	$("#supplier_form").validate({
   	rules: {
   		name: "required",
   		email: {
   			required: true,
   			email: true
   		},
   		password: {
   				required:true,
   				minlength:6
   		},		
   		confirm_password: {
   					required:true,
   					minlength:6
   					//equalTo:'#password'
   		}
   	},
   	messages: {
   		name: "Please enter your name",
   		email: "Please enter a valid email address",
   		password: "Please enter password minimum 6 character",
   		confirm_password: "Confirm Password should be equal to password"
   	},
   	submitHandler: function(form) {
   		// Setup form validation on the #register-form element
   		form = $("#supplier_form").serialize();
   		base_url='<?php echo base_url();?>';
   		$.ajax({
   		   url: base_url + 'users/register/' + new Date().getTime(),
   		   data: form,
   		   type: "POST",
   		   cache: false,
   		   beforeSend:function(){
   			   $('#supplier_status').show();
   		   },
   		   success: function(response) {
   			   try {
   				   $('#supplier_status').hide();
   				   if(response=='Success'){
   					   	   $('#supplierr_Error').hide();
   						   $('#supplier_Success').show();
   						   $('#supplier_Success').html('Thanks for registering with our expert training, Please check mail to login!');
   						   //window.location.reload();
   				   }else{
   					   $('#supplier_Success').hide();
   					   $('#supplier_Error').show();
   					   $('#supplier_Error').html(response);
   				   }
   			   } catch (e) {
   				   return false;
   			   }
   		   },
       		error: function(response){
       		   $('#register_Success').hide();
   			   $('#register_Error').show();
   			   $('#register_Error').html('Email is already exists, Please try another email');
       	   	}
   		 });
   		 return false;        
      }
   });
   });
</script>
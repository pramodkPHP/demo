<?php //ini_set('display_errors',0);?>
<?php if(isset($error)){?>
<div class="error close_div"><button type="button" class="close">�</button><?php echo $error; ?><br></div>
<?php }?>
<?php 
   @$success=$this->session->flashdata('success');
   if(@$success!=""){?>
<div class="success close_div" style="color:#4b8df8;"><button type="button" class="close">�</button><?php echo $success;?> </div>
<?php } ?>
<?php 
   @$error=$this->session->flashdata('error');
   if(@$error!=""){?>
<div class="error close_div" style="color:#4b8df8;"><button type="button" class="close">�</button><?php echo $error;?> </div>
<?php } ?>
<style>
   .expert
   {
   font-size: 15px;
   color: #fff;
   padding-top: 29px;
   position: relative;
   float:right;
   margin-bottom: 0px;	
   }
   .expert a
   {
   color:#fff !important;
   }
   .mb-sm-1
   {
   margin-bottom: 40px !important;
   margin-top: 0px;
   color: #fff;
   font-size: 3.6em;	
   }
</style>
<div role="main" class="main">
<div class="slider-container">
   <div class="section section-3">
      <div class="home-concept" style="padding-top:120px;">
         <div class="row center" >
            <div class="row" >
               <div class="col-md-5 col-md-offset-4">
                  <p class="expert"> <a href="<?php echo base_url();?>home/global_expert" class="btn btn-success feed-99">Be Global Expert</a></p>
               </div>
            </div>
            <div class="row" >
               <h1 class="mb-sm-1">
                  Find the Best <b>EXPERTS</b>
               </h1>
            </div>
            <div class="col-md-10 col-md-offset-1 ">
            
            	<div class="rotator-wrap">
    <ul class="rotator">
    
        <li>  <div class="process-image" data-appear-animation="bounceIn" data-appear-animation-delay="200">
                     <a href="<?php echo base_url();?>supplier/expert/consultant">
                     <img src="<?php echo base_url('public/img/head-section/consultant.png'); ?>" alt="" />
                     </a>
                  </div> 
                   <div class="process-image" data-appear-animation="bounceIn">
                     <a href="<?php echo base_url();?>supplier/expert/trainers">
                     <img src="<?php echo base_url('public/img/head-section/trainers.png'); ?>" alt="" />
                     </a>
                  </div>
                  </li>
                  
        <li>  <div class="process-image" data-appear-animation="bounceIn" data-appear-animation-delay="400">
                     <a href="<?php echo base_url();?>supplier/expert/<?php echo urlencode('subject experts');?>">
                     <img src="<?php echo base_url('public/img/head-section/subject.png'); ?>" alt="" />
                     </a>
                  </div>
                  <div class="process-image" data-appear-animation="bounceIn">
                     <a href="<?php echo base_url();?>supplier/expert/counsellor">
                     <img src="<?php echo base_url('public/img/head-section/counsellor.png'); ?>" alt="" />
                     </a>
                  </div>
                  
                  </li>
        
        <li>  <div class="process-image" data-appear-animation="bounceIn">
                     <a href="<?php echo base_url();?>supplier/expert/innovators">
                     <img src="<?php echo base_url('public/img/head-section/innovators.png'); ?>" alt="" />
                     </a>
                  </div>
                  <div class="process-image" data-appear-animation="bounceIn">
                     <a href="<?php echo base_url();?>supplier/expert/coach">
                     <img src="<?php echo base_url('public/img/head-section/coach.png'); ?>" alt="" />
                     </a>
                  </div>
                   
                   </li>
        
        <li>   <div class="process-image" data-appear-animation="bounceIn">
                     <a href="<?php echo base_url();?>supplier/expert/researcher">
                     <img src="<?php echo base_url('public/img/head-section/research.png'); ?>" alt="" />
                     </a>
                  </div>
                  
                    <div class="process-image" data-appear-animation="bounceIn" data-appear-animation-delay="200">
                     <a href="<?php echo base_url();?>supplier/expert/mentor">
                     <img src="<?php echo base_url('public/img/head-section/mentor.png'); ?>" alt="" />
                     </a>
                  </div>
                  </li>
        
        <li> <div class="process-image" data-appear-animation="bounceIn">
                     <a href="<?php echo base_url();?>supplier/expert/<?php echo urlencode('Keynotes Speakers');?>">
                     <img src="<?php echo base_url('public/img/head-section/keynote.png'); ?>" alt="" />
                     </a>
                  </div>
                  
                    <div class="process-image" data-appear-animation="bounceIn" data-appear-animation-delay="400">
                     <a href="<?php echo base_url();?>supplier/expert/<?php echo urlencode('visiting faculty');?>">
                     <img src="<?php echo base_url('public/img/head-section/faculty.png'); ?>" alt="" />
                     </a>
                  </div>
                  
                  </li>
        
        <li>  <div class="process-image" data-appear-animation="bounceIn">
                     <a href="<?php echo base_url();?>supplier/expert/innovators">
                     <img src="<?php echo base_url('public/img/head-section/innovators.png'); ?>" alt="" />
                     </a>
                  </div>
                  <div class="process-image" data-appear-animation="bounceIn">
                     <a href="<?php echo base_url();?>supplier/expert/coach">
                     <img src="<?php echo base_url('public/img/head-section/coach.png'); ?>" alt="" />
                     </a>
                  </div>
                   
                   </li>
        
        <li>  <div class="process-image" data-appear-animation="bounceIn" data-appear-animation-delay="200">
                     <a href="<?php echo base_url();?>supplier/expert/consultant">
                     <img src="<?php echo base_url('public/img/head-section/consultant.png'); ?>" alt="" />
                     </a>
                  </div> 
                   <div class="process-image" data-appear-animation="bounceIn">
                     <a href="<?php echo base_url();?>supplier/expert/trainers">
                     <img src="<?php echo base_url('public/img/head-section/trainers.png'); ?>" alt="" />
                     </a>
                  </div>
                  </li>
        
          <li> <div class="process-image" data-appear-animation="bounceIn">
                     <a href="<?php echo base_url();?>supplier/expert/<?php echo urlencode('Keynotes Speakers');?>">
                     <img src="<?php echo base_url('public/img/head-section/keynote.png'); ?>" alt="" />
                     </a>
                  </div>
                  
                    <div class="process-image" data-appear-animation="bounceIn" data-appear-animation-delay="400">
                     <a href="<?php echo base_url();?>supplier/expert/<?php echo urlencode('visiting faculty');?>">
                     <img src="<?php echo base_url('public/img/head-section/faculty.png'); ?>" alt="" />
                     </a>
                  </div>
                  
                  </li>
                  
                     <li>  <div class="process-image" data-appear-animation="bounceIn" data-appear-animation-delay="400">
                     <a href="<?php echo base_url();?>supplier/expert/<?php echo urlencode('subject experts');?>">
                     <img src="<?php echo base_url('public/img/head-section/subject.png'); ?>" alt="" />
                     </a>
                  </div>
                  <div class="process-image" data-appear-animation="bounceIn">
                     <a href="<?php echo base_url();?>supplier/expert/counsellor">
                     <img src="<?php echo base_url('public/img/head-section/counsellor.png'); ?>" alt="" />
                     </a>
                  </div>
                  
                  </li>
                  
                   <li>  <div class="process-image" data-appear-animation="bounceIn">
                     <a href="<?php echo base_url();?>supplier/expert/innovators">
                     <img src="<?php echo base_url('public/img/head-section/innovators.png'); ?>" alt="" />
                     </a>
                  </div>
                  <div class="process-image" data-appear-animation="bounceIn">
                     <a href="<?php echo base_url();?>supplier/expert/coach">
                     <img src="<?php echo base_url('public/img/head-section/coach.png'); ?>" alt="" />
                     </a>
                  </div>
                   
                   </li>
        
                </ul>
              </div>
            
            
            
            
           
            </div>
         </div>
         
      </div>
   </div>
</div>
<div class="home-intro " id="home-intro">
   <div class="container">
      <div class="row">
	  <?php $experties = $CI->get_option('Experts');
	  		if(isset($experties) && !empty($experties)){
				foreach($experties as $key=>$value){
					if($value->expert_group == '1'){?>
         			<div class="col-md-2">
            			<a href="<?php echo base_url();?>supplier/expert/<?php echo urlencode($value->type);?>" class="btn btn-tertiary btn-block btn-lg">
							<?php echo $value->type;?>
						</a>	
         			</div>
		<?php }}}?>
      </div>
   </div>
</div>
<div class="container" id="How-it-works" style="padding-top:110px;">
   <div class="row">
      <div class="col-md-4">
         <div class="embed-responsive embed-responsive-16by9">
            <iframe frameborder="0" allowfullscreen="" src="http://www.youtube.com/embed/oNBBijn4JuY?showinfo=0&amp;wmode=opaque"></iframe>
         </div>
      </div>
      <div class="col-md-7 col-md-offset-1">
         <h2 class="mt-xl"><strong>How  </strong> does it works </h2>
         <p class="lead">
            Donec convallis a magna at interdum. Sed consequat dignissim risus. Praesent consectetur iaculis augue. Mauris a lacus tortor. Fusce quis libero et diam vulputate semper. Donec id porttitor neque. Vestibulum ante ipsum primis
         </p>
         <p>
            Donec convallis a magna at interdum. Sed consequat dignissim risus. Praesent consectetur iaculis augue. Mauris a lacus tortor. Fusce quis libero et diam vulputate semper. Donec id porttitor neque. Vestibulum ante ipsum primis
         </p>
      </div>
   </div>
  
   
   <hr class="tall">
   <div class="row">
      <div class="col-md-4">
         <img src="<?php echo base_url('public/img/lorem.jpg'); ?>" class="img-responsive appear-animation fadeInRight appear-animation-visible">
      </div>
      <div class="col-md-7 col-md-offset-1">
         <h2 class="mt-xl"><strong>Lorem </strong>ipsum dolor sit amet </h2>
         <p class="lead">
            Donec convallis a magna at interdum. Sed consequat dignissim risus. Praesent consectetur iaculis augue. Mauris a lacus tortor. Fusce quis libero et diam vulputate semper. Donec id porttitor neque. Vestibulum ante ipsum primis
         </p>
         <p>
            Donec convallis a magna at interdum. Sed consequat dignissim risus. Praesent consectetur iaculis augue. Mauris a lacus tortor. Fusce quis libero et diam vulputate semper. Donec id porttitor neque. Vestibulum ante ipsum primis
         </p>
      </div>
   </div>
</div>
<section class="parallax section section-text-light section-parallax section-center mt-none" data-stellar-background-ratio="0.5" style="background-image: url(&quot;http://preview.oklerthemes.com/porto/3.8.1/img/parallax-image.jpg&quot;); background-position: 0% -126.648px;     padding: 100px 0 100px 0;">
   <div class="container">
      <div class="row">
         <div class="col-md-2 ">
            
            <span class="thumb-info thumb-info-hide-wrapper-bg">
            <span class="thumb-info-wrapper">
            <img src="<?php echo base_url('public/img/projects/project-1.jpg');?>" class="img-responsive" alt="">		 
            </span>
            <span class="thumb-info-caption">
            <span class="thumb-info-caption-text">Training Company </span>
           
            </span>
            </span>
         </div>
         <div class="col-md-2 ">
           
            <span class="thumb-info thumb-info-hide-wrapper-bg">
            <span class="thumb-info-wrapper">
            <img src="<?php echo base_url('public/img/projects/project-2.jpg');?>" class="img-responsive" alt="">
            </span>
            <span class="thumb-info-caption">
            <span class="thumb-info-caption-text">Training Services Provider </span>
            
            </span>
            </span>
         </div>
         <div class="col-md-2 ">
           
            <span class="thumb-info thumb-info-hide-wrapper-bg">
            <span class="thumb-info-wrapper">
            <img src="<?php echo base_url('public/img/projects/project-3.jpg');?>" class="img-responsive" alt="">
            </span>
            <span class="thumb-info-caption">
            <span class="thumb-info-caption-text">Product Tools Provider</span>
           
            </span>
            </span>
         </div>
         <div class="col-md-2 ">
           
            <span class="thumb-info thumb-info-hide-wrapper-bg">
            <span class="thumb-info-wrapper">
            <img src="<?php echo base_url('public/img/projects/project-4.jpg');?>" class="img-responsive" alt="">
            </span>
            <span class="thumb-info-caption">
            <span class="thumb-info-caption-text">Content Provider </span>
           
            </span>
            </span>
         </div>
         <div class="col-md-2 ">
            
            <span class="thumb-info thumb-info-hide-wrapper-bg">
            <span class="thumb-info-wrapper">
            <img src="<?php echo base_url('public/img/projects/project-5.jpg');?>" class="img-responsive" alt="">
            </span>
            <span class="thumb-info-caption">
            <span class="thumb-info-caption-text">Professional Bodies </span>
           
            </span>
            </span>
         </div>
         
         <div class="col-md-2 ">
          
            <span class="thumb-info thumb-info-hide-wrapper-bg">
            <span class="thumb-info-wrapper">
            <img src="<?php echo base_url('public/img/projects/project-6.jpg');?>" class="img-responsive" alt="">
            </span>
            <span class="thumb-info-caption">
            <span class="thumb-info-caption-text">R&D Labs on lease</span>
           
            </span>
            </span>
         </div>
      </div>
   </div>
</section>
<div class="container">
   <h1>Featured <strong>Companies/Experts</strong></h1>
   <div class="content-grid content-grid-dashed mt-xlg mb-lg">
      <div class="col-md-3 content-grid-row">
         <div class="content-grid-item col-md-12 center">
            <img class="img-responsive" src="<?php echo base_url('public/img/resource1.jpg');?>" alt="">
         </div>
         <div class="content-grid-item col-md-12 center">
            <img class="img-responsive" src="<?php echo base_url('public/img/resource2.jpg');?>" alt="">
         </div>
         <div class="content-grid-item col-md-12 center">
            <img class="img-responsive" src="<?php echo base_url('public/img/resource3.jpg');?>" alt="">
         </div>
      </div>
      <div class="col-md-6 content-grid-row">
         <div class="content-grid-item col-md-12 center">
            <img class="img-responsive" src="<?php echo base_url('public/img/abc.jpg');?>" alt="">
         </div>
      </div>
      <div class="col-md-3 content-grid-row">
         <div class="content-grid-item col-md-12 center">
            <img class="img-responsive" src="<?php echo base_url('public/img/resource4.jpg');?>" alt="">
         </div>
         <div class="content-grid-item col-md-12 center">
            <img class="img-responsive" src="<?php echo base_url('public/img/resource5.jpg');?>" alt="">
         </div>
         <div class="content-grid-item col-md-12 center">
            <img class="img-responsive" src="<?php echo base_url('public/img/resource6.jpg');?>" alt="">
         </div>
      </div>
   </div>
</div>
<section class="parallax section section-text-light section-parallax section-center mt-none" data-stellar-background-ratio="0.5" style="background-image: url(&quot;http://preview.oklerthemes.com/porto/3.8.1/img/parallax-image.jpg&quot;); background-position: 0% -171.648px;">
   <div class="container">
      <div class="row">
         <div class="col-md-10 col-md-offset-1">
            <div class="owl-carousel nav-bottom rounded-nav owl-theme owl-loaded owl-carousel-init" data-plugin-options="{&quot;items&quot;: 1, &quot;loop&quot;: false}">
               <div class="owl-stage-outer" style="padding-left: 0px; padding-right: 0px;">
                  <div class="owl-stage" style="width: 1890px; transform: translate3d(0px, 0px, 0px); transition: 0.25s;">
                     <div class="owl-item active" style="width: 945px; margin-right: 0px;">
                        <div>
                           <div class="col-md-12">
                              <div class="testimonial testimonial-style-2 testimonial-with-quotes mb-none">
                                 <div class="testimonial-author">
                                    <img src="<?php echo base_url();?>public/img/clients/client-1.jpg" class="img-responsive img-circle" alt="">
                                 </div>
                                 <blockquote>
                                    <p>Lorem ipsum xxxxx sit amet, xxxxxxxxxxx adipiscing elit. Xxx eget risus xxxxx, tincidunt turpis xx, interdum tortor. Xxxxxxxxxxx potenti. Lorem xxxxx dolor sit xxxx, consectetur adipiscing xxxx. Cum sociis xxxxxxx penatibus et xxxxxx dis parturient xxxxxx, nascetur ridiculus xxx. Fusce ante xxxxxx, convallis non xxxxxxxxxxx sed, pharetra xxx ex. </p>
                                 </blockquote>
                                 <div class="testimonial-author">
                                    <p><strong>John Smith </strong><span>CEO &amp; Xxxxxxx - Okler </span></p>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="owl-item" style="width: 945px; margin-right: 0px;">
                        <div>
                           <div class="col-md-12">
                              <div class="testimonial testimonial-style-2 testimonial-with-quotes mb-none">
                                 <div class="testimonial-author">
                                    <img src="<?php echo base_url();?>public/img/clients/client-1.jpg" class="img-responsive img-circle" alt="">
                                 </div>
                                 <blockquote>
                                    <p>Lorem ipsum xxxxx sit amet, xxxxxxxxxxx adipiscing elit. Xxx eget risus xxxxx, tincidunt turpis xx, interdum tortor. Xxxxxxxxxxx potenti. Lorem xxxxx dolor sit xxxx, consectetur adipiscing xxxx. </p>
                                 </blockquote>
                                 <div class="testimonial-author">
                                    <p><strong>John Smith </strong><span>CEO &amp; Xxxxxxx - Okler </span></p>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="owl-controls">
                  <div class="owl-nav">
                     <div class="owl-prev" style="display: none;"></div>
                     <div class="owl-next" style="display: none;"></div>
                  </div>
                  <div class="owl-dots" style="">
                     <div class="owl-dot active"><span></span></div>
                     <div class="owl-dot"><span></span></div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</section>
<!-- Model -->
<!--<button type="button" class="btn btn-warning btn-lg feed" data-toggle="modal" data-target="#defaultModal" data-direction='right'>Feedback </button>-->
<button type="button" class="btn btn-success  feed-1" data-toggle="modal" data-target="#defaultModalNew" data-direction='right'>Enquiry </button>
<?php echo $CI->partial('elements/feedback.php');?>
<?php echo $CI->partial('elements/inquiry.php');?>
<script type="text/javascript">
   $(document).ready(function(e){
   	$("#supplier_form").validate({
   	rules: {
   		name: "required",
   		email: {
   			required: true,
   			email: true
   		},
   		password: {
   				required:true,
   				minlength:6
   		},		
   		confirm_password: {
   					required:true,
   					minlength:6
   					//equalTo:'#password'
   		}
   	},
   	messages: {
   		name: "Please enter your name",
   		email: "Please enter a valid email address",
   		password: "Please enter password minimum 6 character",
   		confirm_password: "Confirm Password should be equal to password"
   	},
   	submitHandler: function(form) {
   		// Setup form validation on the #register-form element
   		form = $("#supplier_form").serialize();
   		base_url='<?php echo base_url();?>';
   		$.ajax({
   		   url: base_url + 'users/register/' + new Date().getTime(),
   		   data: form,
   		   type: "POST",
   		   cache: false,
   		   beforeSend:function(){
   			   $('#supplier_status').show();
   		   },
   		   success: function(response) {
   			   try {
   				   $('#supplier_status').hide();
   				   if(response=='Success'){
   					   	   $('#supplierr_Error').hide();
   						   $('#supplier_Success').show();
   						   $('#supplier_Success').html('Thanks for registering with our expert training, Please check mail to login!');
   						   //window.location.reload();
   				   }else{
   					   $('#supplier_Success').hide();
   					   $('#supplier_Error').show();
   					   $('#supplier_Error').html(response);
   				   }
   			   } catch (e) {
   				   return false;
   			   }
   		   },
       		error: function(response){
       		   $('#register_Success').hide();
   			   $('#register_Error').show();
   			   $('#register_Error').html('Email is already exists, Please try another email');
       	   	}
   		 });
   		 return false;        
      }
   });
   });
</script>
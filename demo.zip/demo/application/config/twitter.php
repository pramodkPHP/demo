<?php
/**
 * twconnect library configuration
 */

$config = array(
  'consumer_key'    => 'P1sIJzWLU1i5JsWUntOVkpbgx',
  'consumer_secret' => 'MKrSPo5abMIk0oDXt75xKvswBl8NUer7c6jmGE4UpNUvds7GJh',
  'oauth_callback'      => '/users/twregister' // Default callback application path
);

?>
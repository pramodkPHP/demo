<?php
defined('BASEPATH') OR exit('No direct script access allowed');
//ini_set('display_errors',0);
/*
|--------------------------------------------------------------------------
| Display Debug backtrace
|--------------------------------------------------------------------------
|
| If set to TRUE, a backtrace will be displayed along with php errors. If
| error_reporting is disabled, the backtrace will not display, regardless
| of this setting
|
*/
defined('SHOW_DEBUG_BACKTRACE') OR define('SHOW_DEBUG_BACKTRACE', TRUE);

/*
|--------------------------------------------------------------------------
| File and Directory Modes
|--------------------------------------------------------------------------
|
| These prefs are used when checking and setting modes when working
| with the file system.  The defaults are fine on servers with proper
| security, but you may wish (or even need) to change the values in
| certain environments (Apache running a separate process for each
| user, PHP under CGI with Apache suEXEC, etc.).  Octal values should
| always be used to set the mode correctly.
|
*/
defined('FILE_READ_MODE')  OR define('FILE_READ_MODE', 0644);
defined('FILE_WRITE_MODE') OR define('FILE_WRITE_MODE', 0666);
defined('DIR_READ_MODE')   OR define('DIR_READ_MODE', 0755);
defined('DIR_WRITE_MODE')  OR define('DIR_WRITE_MODE', 0755);

/*
|--------------------------------------------------------------------------
| File Stream Modes
|--------------------------------------------------------------------------
|
| These modes are used when working with fopen()/popen()
|
*/
defined('FOPEN_READ')                           OR define('FOPEN_READ', 'rb');
defined('FOPEN_READ_WRITE')                     OR define('FOPEN_READ_WRITE', 'r+b');
defined('FOPEN_WRITE_CREATE_DESTRUCTIVE')       OR define('FOPEN_WRITE_CREATE_DESTRUCTIVE', 'wb'); // truncates existing file data, use with care
defined('FOPEN_READ_WRITE_CREATE_DESCTRUCTIVE') OR define('FOPEN_READ_WRITE_CREATE_DESTRUCTIVE', 'w+b'); // truncates existing file data, use with care
defined('FOPEN_WRITE_CREATE')                   OR define('FOPEN_WRITE_CREATE', 'ab');
defined('FOPEN_READ_WRITE_CREATE')              OR define('FOPEN_READ_WRITE_CREATE', 'a+b');
defined('FOPEN_WRITE_CREATE_STRICT')            OR define('FOPEN_WRITE_CREATE_STRICT', 'xb');
defined('FOPEN_READ_WRITE_CREATE_STRICT')       OR define('FOPEN_READ_WRITE_CREATE_STRICT', 'x+b');

/*
|--------------------------------------------------------------------------
| Exit Status Codes
|--------------------------------------------------------------------------
|
| Used to indicate the conditions under which the script is exit()ing.
| While there is no universal standard for error codes, there are some
| broad conventions.  Three such conventions are mentioned below, for
| those who wish to make use of them.  The CodeIgniter defaults were
| chosen for the least overlap with these conventions, while still
| leaving room for others to be defined in future versions and user
| applications.
|
| The three main conventions used for determining exit status codes
| are as follows:
|
|    Standard C/C++ Library (stdlibc):
|       http://www.gnu.org/software/libc/manual/html_node/Exit-Status.html
|       (This link also contains other GNU-specific conventions)
|    BSD sysexits.h:
|       http://www.gsp.com/cgi-bin/man.cgi?section=3&topic=sysexits
|    Bash scripting:
|       http://tldp.org/LDP/abs/html/exitcodes.html
|
*/
defined('EXIT_SUCCESS')        OR define('EXIT_SUCCESS', 0); // no errors
defined('EXIT_ERROR')          OR define('EXIT_ERROR', 1); // generic error
defined('EXIT_CONFIG')         OR define('EXIT_CONFIG', 3); // configuration error
defined('EXIT_UNKNOWN_FILE')   OR define('EXIT_UNKNOWN_FILE', 4); // file not found
defined('EXIT_UNKNOWN_CLASS')  OR define('EXIT_UNKNOWN_CLASS', 5); // unknown class
defined('EXIT_UNKNOWN_METHOD') OR define('EXIT_UNKNOWN_METHOD', 6); // unknown class member
defined('EXIT_USER_INPUT')     OR define('EXIT_USER_INPUT', 7); // invalid user input
defined('EXIT_DATABASE')       OR define('EXIT_DATABASE', 8); // database error
defined('EXIT__AUTO_MIN')      OR define('EXIT__AUTO_MIN', 9); // lowest automatically-assigned error code
defined('EXIT__AUTO_MAX')      OR define('EXIT__AUTO_MAX', 125); // highest automatically-assigned error code
/****************User Defined message*************************************/
define('AJAX_LOADER','013.gif');      
define('ERROR','There is an error, Please contact support team'); 
define('SITE_NAME','Get Me Experts');    
define('support_email','donotreply@getmeexperts.com');       
define('RECORD_NOT_FOUND','Record not found');    
define('LOGGED_REQUIRED','Log-in required, Please login or register');
define('REGISTER_SUCCESS','Thanks for registering with us. Please check your mail to login');
define('FUNCTIONAL_LIMIT_EXCEED','Functional Limit has exceeded, please refer to your current plan in dashboard');
define('Supplier_Job_APPLY','Thanks for applying. You will be contacted as soon as possible');
define('FEEDBACK_FORM_MESSAGE','Free Domain mails are not allowed. Please add valid  email id of the company or contact the support team.');
define('FEEDBACK_SUCCESS','Your feedback request has been sent, you will get response as soon');
define('PROFILE_PIC','default.png');
define('LIMIT_PER_PAGE',5);
define('ADMIN_LIMIT_PER_PAGE',10);
define('LISTING_ICON_ACTIVE','li_activate.png');
define('LISTING_ICON_INACTIVE','li_deactivate.png');
define('LISTING_ICON_EDIT','li_edit.png');
define('LISTING_ICON_DELETE','li_delete.png');
define('LISTING_ICON_LOADER_ROW','li_loader.gif');
define('LISTING_ICON_VIEW','li_detail.png');
define('ADMIN_EMAIL','pramod.itprofessional@gmail.com');
define('EMAIL_EXIST','Email id already exists. Please try another e-mail id');
//define('SMTP_USER','pantaron.education@gmail.com');
define('SMTP_USER','donotreply@getmeexperts.com');
//define('SMTP_PASSWORD','Pantaron@1234');
define('SMTP_PASSWORD','googlebaba123');
define('From_EMAIL','donotreply@getmeexperts.com');
define('ADD_EVENT_MSG','Institute registration - Domain does not exist');
$server = $_SERVER['HTTP_HOST'];
switch($server){
	case 'localhost':
	$base_url	=	$_SERVER['HTTP_HOST']."/training";
	define('call_back_url',$base_url."/users/linkedin_login");//TEST LIVE
	break;
	default:
	//$base_url	=	$_SERVER['HTTP_HOST'];
	$base_url	=	'http://getmeexperts.com';
	define('call_back_url',$base_url."/users/linkedin_login");//TEST LIVE
}
/****************payment variables*****************/
define('PAYMENT_MODE','TEST');//TEST LIVE
define('PAYMENT_TEST_MODE_URL','https://www.sandbox.paypal.com/cgi-bin/webscr');//LIVE
define('PAYMENT_LIVE_MODE_URL','https://www.paypal.com/cgi-bin/webscr');//LIVE
define('PAYMENT_BUSINESS_ID','pantaron.education@gmail.com');// Business email ID
//define('PAYMENT_BUSINESS_ID','neelam.vansh10@gmail.com');// Business email ID
//define('PAYMENT_BUSINESS_ID','foxaffairs@yahoo.com');// Business email ID
define('NOTIFY_URL',$base_url. "/users/payment_notification");// Business email ID
define('RETURN_URL',$base_url. "/users/dashboard");// Business email ID
define('CANCEL_RETURN_URL',$base_url. "/users/dashboard");// Business email ID
define('DEBUG', 1); // Set this to 0 once you go live or don't require logging.
define('USE_SANDBOX', 1); // Set this to 0 once you go live or don't require logging.
define('MEMBERSHIP_CHECK', false); // can not be check untill required in special case
define('linkedinApiKey', '7552w69hytcxdn'); // Set this to 0 once you go live or don't require logging.
define('linkedinApiSecret', '2pAqUPiq5slVGf2J'); // can not be check untill required in special case







<!DOCTYPE html>
<html>
    <head>
        <!-- Basic -->
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <title>Get Me Experts</title>
        <meta name="keywords" content="<?php echo isset($result->meta_keywords) ? $result->meta_keywords:'';?>" />
        <meta name="description" content="<?php echo isset($result->meta_description) ? $result->meta_description:'';?>" />
        <meta name="author" content="#" />
        <!-- Favicon -->
        <link rel="shortcut icon" href="<?php echo base_url(); ?>public/img/favicon.ico" type="image/x-icon" />
        <link rel="apple-touch-icon" href="<?php echo base_url(); ?>public/img/apple-touch-icon.png" />
        <!-- Mobile Metas -->
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <!-- Web Fonts  -->
        <link href='https://fonts.googleapis.com/css?family=Signika:400,300,700' rel='stylesheet' type='text/css'>
        <!-- Vendor CSS -->
		<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
       <link rel="stylesheet" href="<?php echo base_url(); ?>public/css/bootstrap.css" />
        <link rel="stylesheet" href="<?php echo base_url(); ?>public/css/font-awesome.css" />
        <link rel="stylesheet" href="<?php echo base_url(); ?>public/css/owl.carousel.min.css" media="screen" />
        <link rel="stylesheet" href="<?php echo base_url(); ?>public/css/owl.theme.default.min.css" media="screen" />
        <link rel="stylesheet" href="http://expert.infutive.com/public/css/magnific-popup.css" media="screen" />
        <!-- Theme CSS -->
        <link rel="stylesheet" href="http://expert.infutive.com/public/css/theme.css" />
        <link rel="stylesheet" href="http://expert.infutive.com/public/css/theme-elements.css" />
        <link rel="stylesheet" href="http://expert.infutive.com/public/css/theme-blog.css" />
        <link rel="stylesheet" href="http://expert.infutive.com/public/css/theme-shop.css" />
        <link rel="stylesheet" href="http://expert.infutive.com/public/css/theme-animate.css" />
        <link rel="stylesheet" href="http://expert.infutive.com/public/css/custom.css" />
        <!-- Current Page CSS -->
        <link rel="stylesheet" href="http://expert.infutive.com/public/js/rs-plugin/css/settings.css" media="screen" />
        <link rel="stylesheet" href="http://expert.infutive.com/public/css/component.css" media="screen" />
        <link rel="stylesheet" href="http://expert.infutive.com/public/css/colorbox.css" media="screen" />
        <script src="<?php echo base_url(); ?>public/js/jquery.js"></script>
        <script src="<?php echo base_url(); ?>public/js/jquery.appear.js"></script>
        <script src="<?php echo base_url(); ?>public/js/jquery.easing.js"></script>
        <!-- Head Libs -->
        <script src="<?php echo base_url(); ?>public/js/modernizr.js"></script>
        <script src="<?php echo base_url(); ?>public/js/jquery-form.js"></script>
        <link rel="stylesheet" href="<?php echo base_url(); ?>public/css/jquery-ui.css" />
        <script src="<?php echo base_url(); ?>public/js/jquery-ui.js"></script>
        <script src="<?php echo base_url(); ?>public/js/jquery.colorbox.js"></script>
		<link type="text/css" href="/cometchat/cometchatcss.php" rel="stylesheet" charset="utf-8">
		<script type="text/javascript" src="/cometchat/cometchatjs.php" charset="utf-8"></script>
        <!--[if IE]>
        <link rel="stylesheet" href="<?php echo base_url(); ?>public/css/ie.css" />
        <![endif]-->
        <!--[if lte IE 8]>
        <script src="./vendor/respond/respond.js"></script>
        <script src="./vendor/excanvas/excanvas.js"></script>
        <![endif]-->
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <style>
		.ui-autocomplete
		{
		z-index: 9999;
		border-radius:5px;	
		}
		</style>
    </head>
    <body>
	
        <div class="body">
            <?php 
            @$session_data = $this->session->userdata('Users'); //print_r($session_data);
			@$feedback_request = $this->session->userdata('feedback_request');
            if (isset($session_data) && !empty($session_data)) {
                ?>
				<script>
				var userid = "<?php echo $session_data['id'];?>"; // Must be populated programmatically
				document.cookie = "cc_data="+userid;
				</script>
				<link type="text/css" href="/cometchat/cometchatcss.php" rel="stylesheet" charset="utf-8">
				<script type="text/javascript" src="/cometchat/cometchatjs.php" charset="utf-8"></script>
				</script>
                <header id="header" class=" light valign font-color-dark" style="background: #384045;" data-plugin-options='{"alwaysStickyEnabled": true}' >
                    <div class="container">
                        <div class="logo">
                            <a href="<?php echo base_url(); ?>">
                                <img width="150" height="60"  data-sticky-width="150" data-sticky-height="60" src="<?php echo base_url('public/img/logopant_w.png'); ?>"/>
                            </a>
                        </div>
                        <div class="btn-group pull-right" role="group" aria-label="..." style="margin-top:20px;">
                            <button type="button" class="btn btn-default"><a href="<?php echo base_url(); ?>users/dashboard">Dashboard</a></button>
							<?php if ($session_data['user_type'] == '0') { ?>
                            <button type="button" class="btn btn-default"><i class="fa fa-bell-o fa-lg"><?php echo count($feedback_request)?></i></button>
							<?php }?>
							<?php if ($session_data['user_type'] != '0') { ?>
                            <button type="button" class="btn btn-default"><i class="fa fa-bell-o fa-lg"></i></button>
							<?php }?>
                            <div class="btn-group" role="group">
                                <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <?php echo ucwords($session_data['first_name'] . " " . $session_data['last_name']); ?></button>
                                <ul class="dropdown-menu">
                                    <?php if ($session_data['user_type'] != '0' && $session_data['firm_type'] == 0) { ?>
                                        <li><a href="<?php echo base_url(); ?>supplier/edit_profile">Edit Profile</a></li>
                                    <?php } ?>
									  <?php if ($session_data['user_type'] == '1' && $session_data['firm_type'] == 1) { ?>
                                        <li><a href="<?php echo base_url(); ?>supplier/orgnization_update">Edit Profile</a></li>
                                    <?php } ?>
									
                                    <!--<li><a href="#">Login as SUPPLIER</a></li>
                                    <li><a href="#">Login as USER</a></li>-->
                                    <li><a href="#" data-toggle="modal" data-target="#change_password">Settings</a></li>
                                    <li><a href="<?php echo base_url(); ?>users/dashboard">Notifications</a></li>
                                    <li><a href="<?php echo base_url(); ?>users/logout">Logout</a></li>
                                </ul>
                            </div>
                        </div>
                        <?php if ($session_data['user_type'] != '0') { ?>
                            <div class="btn-group pull-left" role="group" style="margin-left: 530px;margin-top:10px;" >
                                <nav class="nav-top">
                                    <ul class="nav nav-pills nav-top">
                                        <li class="primary-1">
                                            <div class="dropdown">
                                                <button class="btn btn-info dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                                                    <i class="fa fa-cloud-upload"></i>ADD EVENT</button>
                                                <ul class="dropdown-menu" aria-labelledby="dropdownMenu1">
                                                    <li class="dropdown-header">Have you registered our<br/> institution with us? </li>
                                                    <li role="separator" class="divider"></li>
                                                    <li><a href="<?php echo base_url(); ?>events/add_event">Yes</a></li>
                                                    <li><button data-toggle='modal' data-target='#formModal-5'>No</button></li>
                                                </ul>
                                            </div>
                                        </li>
                                        <!--<li>
                                            <a href="<?php echo base_url(); ?>users/messages" class="btn btn-info"><i class="fa fa-user"></i>Message</a>
                                        </li>-->
                                    </ul>
                                </nav>
                            </div>
                        <?php } ?>
                    </div>
                    <?php //if ($session_data['user_type'] == '0') { ?>
                        <!--<nav class="nav-top">
                            <ul class="nav nav-pills nav-top" style="margin:-45px 501px 0 0;">
                                <li>
                                    <a href="<?php echo base_url(); ?>users/messages" class="btn btn-info"><i class="fa fa-user"></i>Message</a>
                                </li>
                            </ul>
                        </nav>-->
                    <?php //} ?>
                </header>
            <?php } else { ?>
                <header id="header" class="transparent semi-transparent light valign font-color-dark" data-plugin-options='{"alwaysStickyEnabled": true}'>
                    <div class="container">
                        <div class="logo">
                            <a href="<?php echo base_url(); ?>">
                                <img width="150" height="60"  data-sticky-width="150" data-sticky-height="60" src="<?php echo base_url('public/img/logopant_w.png'); ?>"/>
                            </a>
                        </div>
                        <div class="search">
							<form id="searchForm" action="<?php echo base_url();?>supplier/advance_search" method="post">
							<span id="supplier_Status" style="display: none;"><img src="<?php echo base_url();?>/public/img/<?php echo AJAX_LOADER;?>"></span>
							<div class="input-group">
								<input type="text" id="first_name" name="first_name" class="form-control search" placeholder="Search" required>
								<!--<input id="first_name" name="first_name" type="hidden" value="">
								<span class="input-group-btn" style="display:none;">
									<!--<button class="btn btn-default" type="submit"><i class="fa fa-search"></i></button>-->
									<!--<input type="submit" name="search" value="search" class="btn btn-submit">-->
								<!--</span>-->
								<span class="input-group-btn">
													<button class="btn btn-default" type="submit"><i class="fa fa-search"></i></button>
												</span>
							</div>
							</form>
                        </div>
                        <nav class="nav-top">
                            <ul class="nav nav-pills nav-top">
                                <li>
                                    <a href="#" class="btn btn-info" data-toggle="modal" data-target="#smallModal"><i class="fa fa-user"></i>Login</a>
                                </li>
                                <li>
                                    <a class="btn btn-info" data-toggle="modal" data-target="#formModal"><i class="fa fa-sign-in"></i>REGISTER </a>
                                </li>
                            </ul>
                        </nav>
                        <button class="btn btn-responsive-nav btn-inverse" data-toggle="collapse" data-target=".nav-main-collapse">
                            <i class="fa fa-bars"></i>
                        </button>
                    </div>
                    <div class="navbar-collapse nav-main-collapse collapse">
                        <div class="container">
                            <ul class="social-icons">
                                <li class="facebook"><a href="https://www.facebook.com/Getmeexperts/?fref=ts" data-toggle="modal" data-target="#smallModalFBLogin" onClick="$('#smallModal').modal('hide');">Facebook </a></li>
                                <li class="twitter"><a href="https://twitter.com/Get_Me_Experts" data-toggle="modal" data-target="#smallModalTWLogin" onClick="$('#smallModal').modal('hide');" title="Twitter">Twitter </a></li>
                                <li class="linkedin"><a href="https://www.linkedin.com/company/get-me-experts?trk=vsrp_companies_res_name&trkInfo=VSRPsearchId%3A2367480221460291614038%2CVSRPtargetId%3A7936764%2CVSRPcmpt%3Aprimary" target="_blank" title="Linkedin">Linkedin </a></li>
                            </ul>
                            <nav class="nav-main mega-menu">
                                <ul class="nav nav-pills nav-main" id="mainMenu">
                                    <li class="dropdown active">
                                        <a  href="<?php echo base_url(); ?>#How-it-works">How it works</a>
                                    </li>
                                    <li class="dropdown">
                                        <a class="dropdown-toggle" href="<?php echo base_url(); ?>experts">Experts</a>
                                        <ul class="dropdown-menu">
                                            <?php
                                            $CI = & get_instance();

                                            $options = $CI->get_option('Experts');

                                            if (!empty($options)) {
			
                                                foreach ($options as $option) {
													if($option->expert_group==0){
														$exeption = explode('(', $option->type);
														$urlArray = explode(' ', trim($exeption[0]));
														$url = strtolower(implode('+', $urlArray));
														echo '<li><a href="' . base_url() . 'supplier/expert/' . $url . '">' . $option->type . '</a></li>';
													}
                                                }
                                            }
                                            ?>
                                        </ul>
                                    </li>
                                    <li class="dropdown">
                                        <a class="dropdown-toggle" href="<?php echo base_url(); ?>resources">Resources</a>
                                        <ul class="dropdown-menu">
                                            <?php
                                            $options = $CI->get_option('Resources');

                                            if (!empty($options)) {

                                                foreach ($options as $option) {

                                                    $exeption = explode('(', $option->type);

                                                    $urlArray = explode(' ', trim($exeption[0]));

                                                    $url = strtolower(implode('+', $urlArray));

                                                    echo '<li><a href="' . base_url() . 'supplier/resource/' . $url . '">' . $option->type . '</a></li>';
                                                }
                                            }
                                            ?>
                                        </ul>
                                    </li>
									 <li class="dropdown">
                                        <a class="dropdown-toggle" href="<?php echo base_url(); ?>resources">Hot-Tags</a>
                                        <ul class="dropdown-menu">
                                            <?php
                                            $options = $CI->get_option('Experts');
											//print_r($options);
                                            if (!empty($options)) {

                                                foreach ($options as $option) {
													if($option->expert_group==1){
														$exeption = explode('(', $option->type);
														$urlArray = explode(' ', trim($exeption[0]));
														$url = strtolower(implode('+', $urlArray));
														echo '<li><a href="' . base_url() . 'supplier/expert/' . $url . '">' . $option->type . '</a></li>';
													}
                                                }
                                            }
                                            ?>
                                        </ul>
                                    </li>
                                    <li class="dropdown">
                                        <a class="dropdown-toggle" href="<?php echo base_url() . 'events/upcoming_events'; ?>">
                                            Upcoming Events
                                        </a>
                                        <ul class="dropdown-menu">
                                            <?php
                                            $options = $CI->get_option('Events');

                                            if (!empty($options)) {

                                                foreach ($options as $option) {

                                                    $exeption = explode('(', $option->type);

                                                    $urlArray = explode(' ', trim($exeption[0]));

                                                    $url = strtolower(implode('-', $urlArray));

                                                    echo ' <li><a href="' . base_url() . 'events/upcoming_events/' . $url . '">' . $option->type . '</a></li>';
                                                }
                                            }
                                            ?>							
                                        </ul>
                                    </li>
                                    <li>
                                        <a href="#">Blog</a>
                                    </li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                </header>
            <?php } ?>
            <?php if (empty($session_data)) { ?>
                <?php $this->load->view('elements/register'); ?>
                <?php $this->load->view('elements/login'); ?>
                <?php $this->load->view('elements/facebooklogin'); ?>
                <?php $this->load->view('elements/twlogin'); ?>
				 <?php $this->load->view('elements/linkedin'); ?>
                <?php
            } else {
                $this->load->view('elements/add_institution');
				$this->load->view('elements/change_password');
            }
            //$this->load->view('elements/supplier_register');
            //$this->load->view('elements/orgnization_register');
            ?>
			
<script type="text/javascript">
$(document).ready(function(){
	$("#search").autocomplete({
	  source: '<?php echo base_url(); ?>'+"supplier/get_supplier",
	  minLength: 1,
	  select: function( event, ui ) {
	  $(event.target).val(ui.item.value);
			$('#first_name').val(ui.item.value);
			return false;
	  }
	});
});
</script>		
</script>		
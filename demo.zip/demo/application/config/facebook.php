<?php if (!defined('BASEPATH')) exit('No direct script access allowed');


$config['appId']   = '453779391487101';
$config['secret']  = 'b0d92edfc19b27e9a986b0271b19f928';

?>

<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Index extends Front_Controller {

	public function __construct(){
		parent::__construct();
	}
	public function index()
	{
		$this->view('front/home');
	}
}

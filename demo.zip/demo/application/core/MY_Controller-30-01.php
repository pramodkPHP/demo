<?php
class Base_Controller extends CI_Controller{
	protected $header='';
	protected $footer='';
	protected $ajax=true;
	protected $current_date='';
	public function __construct(){
		parent::__construct();
		$this->current_date=date('Y-m-d H:i:s');
		$this->load->helper('ckeditor');
	}
	function view($view, $vars = array(), $string=false)
	{
		$this->load->view($this->header, $vars);
		$this->load->view($view, $vars);
		$this->load->view($this->footer, $vars);
	}
	function partial($view, $vars = array())
	{
		$this->load->view($view, $vars);
	}
	
	public function clear_session(){ 
		$this->session->sess_destroy();
	}
	public function ckeditor($id=NULL)
	{
		if($id!=NULL)
			$id=$id;
		else
			$id='description';
		
		return array(
			'id' 	=> 	$id,
			'path'	=>	'skin/js/ckeditor',
			'config' => array(
				'toolbar' => "Full", 	//Using the Full toolbar
				'width'  => "750px",	//Setting a custom width
				'height' => '150px',	//Setting a custom height
			),
				//Replacing styles from the "Styles tool"
				'styles' => array(
				//Creating a new style named "style 1"
				'style 1' => array (
					'name' 		=> 	'Blue Title',
					'element' 	=> 	'h2',
					'styles' => array(
						'color' 			=> 	'Blue',
						'font-weight' 		=> 	'bold'
					)
				),
			)
		);
	}
	
	
}
class Secure_Controller extends Base_Controller
{
	public $login=false;
	public function __construct(){
		parent::__construct();
		
		// Set globally header and footer that will be default 
		$this->header='admin/includes/header';  
		$this->footer='admin/includes/footer';
		if($this->session->userdata('login_admin'))
			$this->login=true;
		else
		{
			/* Load login model for DB related query */
			$this->load->model('login_model');
			$this->load->library('form_validation');
		}
	}
}
class Admin_Controller extends Base_Controller
{
	public $login_url='';
	public $user_id='';
	public $email='';
	public $login_admin=false;
	public $option='';
	public $action='';
	public $table='';
	public $perpage=20;
	public $redirect='';
	function __construct()
	{
		parent::__construct();
		// Set globally header and footer that will be default 
		$this->header='admin/includes/header';  
		$this->footer='admin/includes/footer';
		$this->login_url=base_url().'admin/secure/login';
		if($this->session->userdata('login_admin'))
		{
			$this->user_id=$this->session->userdata('user_id');
			$this->email=$this->session->userdata('email');
			$this->login_admin=true;
		}
		else
			redirect($this->login_url);
			$this->load->library('form_validation');
	}
	public function types($offset=0){
		$this->load->library('pagination');
		$data['option']=$this->option;
		
		$config['total_rows'] = $this->common_model->getOptions($this->option,true, true);
		$config['base_url'] = base_url().'admin/'.strtolower($this->option).'/types/';
		$config['per_page'] = $this->perpage;
		$this->pagination->initialize($config);
		$data['links']=$this->pagination->create_links();
		$data['rows']=$this->common_model->getOptions($this->option, true, false, $offset, $config['per_page']);
		$data['per_page'] = $config['per_page'];
		$data['offset'] =$offset;
		
		$this->view('admin/grid', $data);
	}
	public function form($id=NULL){
		$data=array();
		$data['type']='';
		$data['description']='';
		$data['button_value']='Add New';
		if($id!=NULL)
		{
			$result=$this->common_model->getOption($id);
			if($result)
			{
				$data['type']=$result->type;
				$data['description']=$result->description;
				$this->action=$this->action.'/'.$result->id;
				$data['button_value']='Update';
			}
			else
				show_404();
			
			$this->form_validation->set_rules('type', 'Type', 'required|max_length[50]');
		}
		else
			$this->form_validation->set_rules('type', 'Type', 'required|max_length[50]|is_unique[expert_resources_roles.type]');
		
		if($this->form_validation->run() == FALSE)
		{
			$data['action']=$this->action;
			$data['heading']=$this->option;
			$data['option']=$this->option;
			$data['ckeditor'] = $this->ckeditor();
			$this->view('admin/option-form', $data);
		}
		else
		{
			$save=array(
				'type'=>ucfirst($this->input->post('type')),
				'option'=>ucfirst($this->input->post('option')),
				'description'=>$this->input->post('description'),
			);
			if($id!=NULL)
				$save['id']=$id;
			else
				$save['created_at']=$this->current_date;
			$save['modified_at']=$this->current_date;
			
			$affected_id=$this->common_model->save($save, $this->table);
			redirect(base_url().'admin/'.strtolower($this->option).'/types');
		}
	}
	public function delete($id){
		
		$this->common_model->delete($id, $this->table);
		redirect($this->redirect);
	}
	public function updateStatus(){
		$save=array(
			'id'=>$this->input->post('id'),
			'is_active'=>$this->input->post('is_active')
		);
		$affected_id=$this->common_model->save($save, $this->table);
		$response=array(
			'error'=>0,
			'message'=>'Updated successfully'
		);
		echo json_encode($response);
	}
}
class Front_Controller extends Base_Controller
{
	function __construct(){
		parent::__construct();
		$this->header='elements/header';  
		$this->footer='elements/footer';
		$this->load->model(array());
		$this->load->helper(array('form_helper'));
		//echo $this->router->fetch_class(); 
		$RestrictedCls = array('users','supplier');
		$session_data=$this->session->userdata('Users');//print_r($session_data);
		if(isset($session_data) && !in_array($this->router->fetch_class(),$RestrictedCls)){
			redirect('users/dashboard');
		}
		
		/*	
			-Added below section by Deepoo Gupta 
			-Date - Jan-23nd-2016
			-Call below method once for saving options in session 
		*/
		
		//if(!$this->session->userdata('options'))   // Currently I made it comment for development mode. Uncomment it when it live
			$this->collect_options();
	}
	
	/*	
		- Added below section by Deepoo Gupta 
		- Date - Jan-23nd-2016
		- Collect all options once and save it into session so system would not hit repeatedly to db for same 
	*/
	public function collect_options(){
		$this->load->model('common_model');
		$options=$this->common_model->getOptions('All',false);
		$type=array();
		if($options){
			foreach($options as $option){
				$type[$option->option][]=$option;
			}
			$this->session->set_userdata('options', $type);
		}
	}
	/*	
		- Added below section by Deepoo Gupta 
		- Date - Jan-23nd-2016
		- Get Option 
	*/
	public function get_option($type){
		$options=$this->session->userdata('options');
		return isset($options[$type])?$options[$type]:array();
	}
}


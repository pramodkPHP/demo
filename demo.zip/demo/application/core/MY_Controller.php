<?php
class Base_Controller extends CI_Controller{
	protected $header='';
	protected $footer='';
	protected $ajax=true;
	protected $current_date='';
	public function __construct(){
		parent::__construct();
		$this->current_date=date('Y-m-d H:i:s');
		$this->load->helper('ckeditor');
		include APPPATH . 'Services/Twilio/Capability.php';
		include APPPATH . 'Services/Twilio.php';
		include APPPATH . 'LinkedIn/http.php';
		include APPPATH . 'LinkedIn/oauth_client.php';
	}
	function view($view, $vars = array(), $string=false)
	{
		$this->load->view($this->header, $vars);
		$this->load->view($view, $vars);
		$this->load->view($this->footer, $vars);
	}
	function partial($view, $vars = array())
	{
		$this->load->view($view, $vars);
	}
	
	public function clear_session(){ 
		$this->session->sess_destroy();
	}
	public function ckeditor($id=NULL)
	{
		if($id!=NULL)
			$id=$id;
		else
			$id='description';
		
		return array(
			'id' 	=> 	$id,
			'path'	=>	'skin/js/ckeditor',
			'config' => array(
				'toolbar' => "Full", 	//Using the Full toolbar
				'width'  => "750px",	//Setting a custom width
				'height' => '150px',	//Setting a custom height
			),
				//Replacing styles from the "Styles tool"
				'styles' => array(
				//Creating a new style named "style 1"
				'style 1' => array (
					'name' 		=> 	'Blue Title',
					'element' 	=> 	'h2',
					'styles' => array(
						'color' 			=> 	'Blue',
						'font-weight' 		=> 	'bold'
					)
				),
			)
		);
	}
	
	
}
class Secure_Controller extends Base_Controller
{
	public $login=false;
	public function __construct(){
		parent::__construct();
		
		// Set globally header and footer that will be default 
		$this->header='admin/includes/header';  
		$this->footer='admin/includes/footer';
		if($this->session->userdata('login_admin'))
			$this->login=true;
		else
		{
			/* Load login model for DB related query */
			$this->load->model('login_model');
			$this->load->library('form_validation');
		}
	}
}
class Admin_Controller extends Base_Controller
{
	public $login_url='';
	public $user_id='';
	public $user_email='';
	public $login_admin=false;
	public $option='';
	public $action='';
	public $table='';
	public $perpage			=	ADMIN_LIMIT_PER_PAGE;
	public $num_pages		=	5;
	public $cur_tag_open 	= 	'&nbsp;<a class="current">';
	public $cur_tag_close 	= 	'</a>';
	public $next_link 		= 	' Next ';
	public $prev_link 		= 	' Previous ';
		
	public $redirect='';
	function __construct()
	{
		parent::__construct();
		// Set globally header and footer that will be default 
		$this->header='admin/includes/header';  
		$this->footer='admin/includes/footer';
		$this->login_url=base_url().'admin/secure/login';
		if($this->session->userdata('login_admin'))
		{
			$this->user_id=$this->session->userdata('user_id');
			$this->user_email=$this->session->userdata('email');
			$this->login_admin=true;
		}
		else
			redirect($this->login_url);
		$this->load->library('form_validation');
		$this->load->library('pagination');
	}
	public function types($offset=0){
		
		$data['option']=$this->option;
		
		$config['total_rows'] = $this->common_model->getOptions($this->option,true, true);
		$config['base_url'] = base_url().'admin/'.strtolower($this->option).'/types/';
		$config['per_page'] = $this->perpage;
		$this->pagination->initialize($config);
		$data['links']=$this->pagination->create_links();
		$data['rows']=$this->common_model->getOptions($this->option, true, false, $offset, $config['per_page']);
		$data['per_page'] = $config['per_page'];
		$data['offset'] =$offset;
		
		$this->view('admin/grid', $data);
	}
	public function form($id=NULL){
		$data=array();
		$data['type']='';
		$data['expert_group']='';
		$data['description']='';
		$data['button_value']='Add New';
		echo $data['type'];
		if($id!=NULL)
		{
			$result=$this->common_model->getOption($id);
			//print_r($result);die;
			if($result)
			{
				$data['type']=$result->type;
				$data['expert_group']=$result->expert_group;
				$data['description']=$result->description;
				$this->action=$this->action.'/'.$result->id;
				$data['button_value']='Update';
				//print_r($data);
			}
			else
				show_404();
			
			$this->form_validation->set_rules('type', 'Type', 'required|max_length[50]');
		}
		else
			$this->form_validation->set_rules('type', 'Type', 'required|max_length[50]|is_unique[expert_resources_roles.type]');
		
		if($this->form_validation->run() == FALSE)
		{
			$data['action']=$this->action;
			$data['heading']=$this->option;
			$data['option']=$this->option;
			$data['ckeditor'] = $this->ckeditor();
			$this->view('admin/option-form', $data);
		}
		else
		{
			$save=array(
				'type'=>ucfirst($this->input->post('type')),
				'expert_group'=>ucfirst($this->input->post('expert_group')),
				'option'=>ucfirst($this->input->post('option')),
				'description'=>$this->input->post('description'),
			);
			if($id!=NULL)
				$save['id']=$id;
			else
				$save['created_at']=$this->current_date;
			$save['modified_at']=$this->current_date;
			//print_r($save);die;
			$affected_id=$this->common_model->save($save, $this->table);
			redirect(base_url().'admin/'.strtolower($this->option).'/types');
		}
	}
	public function delete($id){
		
		$this->common_model->delete($id, $this->table);
		redirect($this->redirect);
	}
	public function updateStatus(){
		$save=array(
			'id'=>$this->input->post('id'),
			'is_active'=>$this->input->post('is_active')
		);
		$affected_id=$this->common_model->save($save, $this->table);
		$response=array(
			'error'=>0,
			'message'=>'Updated successfully'
		);
		echo json_encode($response);
	}
}
class Front_Controller extends Base_Controller
{
	function __construct(){
		parent::__construct();
		$this->header='elements/header';  
		$this->footer='elements/footer';
		$this->load->model(array(''));
		$this->load->helper(array('form_helper'));
		//echo $this->router->fetch_class(); 
		$RestrictedCls = array('users','supplier','events','job','experts','pages');
		$session_data=$this->session->userdata('Users');//print_r($session_data);
		if(isset($session_data) && !in_array($this->router->fetch_class(),$RestrictedCls)){
			redirect('users/dashboard');
		}
		
		/*	
			-Added below section by Deepoo Gupta 
			-Date - Jan-23nd-2016
			-Call below method once for saving options in session 
		*/
		
		//if(!$this->session->userdata('options'))   // Currently I made it comment for development mode. Uncomment it when it live
			$this->collect_options();
	}
	
	/*	
		- Added below section by Deepoo Gupta 
		- Date - Jan-23nd-2016
		- Collect all options once and save it into session so system would not hit repeatedly to db for same 
	*/
	public function collect_options(){
		$this->load->model('common_model');
		$options=$this->common_model->getOptions('All',false);
		$type=array();
		if($options){
			foreach($options as $option){
				$type[$option->option][]=$option;
			}
			$this->session->set_userdata('options', $type);
		}
	}
	
	/*	
		- Added below section by Deepoo Gupta 
		- Date - Jan-23nd-2016
		- Get Option 
	*/
	public function get_option($type){
		$options=$this->session->userdata('options');
		//print_r($options);
		return isset($options[$type])?$options[$type]:array();
	}
	
	public function get_data($id, $table){
		return $this->db->where('id', $id)->get($table)->row();
	}
	
	function getLocationInfoByIp(){
		$client  = @$_SERVER['HTTP_CLIENT_IP'];
		$forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
		$remote  = @$_SERVER['REMOTE_ADDR'];
		$result  = array('country'=>'', 'city'=>'');
		if(filter_var($client, FILTER_VALIDATE_IP)){
			$ip = $client;
		}elseif(filter_var($forward, FILTER_VALIDATE_IP)){
			$ip = $forward;
		}else{
			$ip = $remote;
		}
		$time_zone = getTimeZoneFromIpAddress($ip);
		
		$offset = get_timezone_offset($time_zone,$time_zone);
		$offset_time = time() + $offset;
		return $offset_time;
		//echo(date("TG:i:sz", $offset_time) . "<br />");

		/*
		$ip_data = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=".$ip));    
		//print_r($ip_data);
		if($ip_data && $ip_data->geoplugin_countryName != null){
			$result['country'] = $ip_data->geoplugin_countryName;
			$result['city'] = $ip_data->geoplugin_city;
		}
		return $result;
		*/
	}
}

function getTimeZoneFromIpAddress($clientsIpAddress){
    //$clientsIpAddress = get_client_ip();

    $clientInformation = unserialize(file_get_contents('http://www.geoplugin.net/php.gp?ip='.$clientsIpAddress));

    $clientsLatitude = $clientInformation['geoplugin_latitude'];
    $clientsLongitude = $clientInformation['geoplugin_longitude'];
    $clientsCountryCode = $clientInformation['geoplugin_countryCode'];

    $timeZone = get_nearest_timezone($clientsLatitude, $clientsLongitude, $clientsCountryCode) ;

    return $timeZone;

}

function get_nearest_timezone($cur_lat, $cur_long, $country_code = '') {
    $timezone_ids = ($country_code) ? DateTimeZone::listIdentifiers(DateTimeZone::PER_COUNTRY, $country_code)
        : DateTimeZone::listIdentifiers();

    if($timezone_ids && is_array($timezone_ids) && isset($timezone_ids[0])) {

        $time_zone = '';
        $tz_distance = 0;

        //only one identifier?
        if (count($timezone_ids) == 1) {
            $time_zone = $timezone_ids[0];
        } else {

            foreach($timezone_ids as $timezone_id) {
                $timezone = new DateTimeZone($timezone_id);
                $location = $timezone->getLocation();
                $tz_lat   = $location['latitude'];
                $tz_long  = $location['longitude'];

                $theta    = $cur_long - $tz_long;
                $distance = (sin(deg2rad($cur_lat)) * sin(deg2rad($tz_lat)))
                    + (cos(deg2rad($cur_lat)) * cos(deg2rad($tz_lat)) * cos(deg2rad($theta)));
                $distance = acos($distance);
                $distance = abs(rad2deg($distance));
                // echo '<br />'.$timezone_id.' '.$distance;

                if (!$time_zone || $tz_distance > $distance) {
                    $time_zone   = $timezone_id;
                    $tz_distance = $distance;
                }

            }
        }
        return  $time_zone;
    }
    return 'unknown';
}
function get_timezone_offset($remote_tz, $origin_tz = null) {
    if($origin_tz === null) {
        if(!is_string($origin_tz = date_default_timezone_get())) {
            return false; // A UTC timestamp was returned -- bail out!
        }
    }
    $origin_dtz = new DateTimeZone($origin_tz);
    $remote_dtz = new DateTimeZone($remote_tz);
    $origin_dt = new DateTime("now", $origin_dtz);
    $remote_dt = new DateTime("now", $remote_dtz);
    $offset = $origin_dtz->getOffset($origin_dt) - $remote_dtz->getOffset($remote_dt);
    return $offset;
}
